"""Reset the Horizon ERP accounting ledger from a Horizon single-sheet Excel ledger.

This intentionally replaces the active voucher ledger only. Operational master data
(customers, plots, bookings, installments, etc.) is retained. Existing voucher links
from operational records are nulled before the ledger reset.

Usage:
  python scripts/reset_financial_from_horizon.py 'Horizon Ledger 6 Sep till.xlsx'

The script creates database backup tables before deleting active vouchers.
"""
from __future__ import annotations
import sys, re, hashlib, os
from datetime import datetime, date
from pathlib import Path

from sqlalchemy import select, text, func
from openpyxl import load_workbook

from app.db import SessionLocal
from app.models import (
    Account, Voucher, VoucherLine, Booking, Receipt, Payroll, Commission,
    MigrationBatch, MigrationRow,
)
from app.services.accounting import create_voucher

USER = "Financial Reset / Master Excel"


def norm(x):
    return re.sub(r"\s+", " ", str(x or "").strip())


def parse_date(v):
    if v in (None, ""):
        return None
    if isinstance(v, datetime): return v.date()
    if isinstance(v, date): return v
    s = norm(v)
    for fmt in ("%d-%m-%y", "%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%m-%d-%Y"):
        try: return datetime.strptime(s, fmt).date()
        except ValueError: pass
    return None


def counterparty(paid_by):
    w = norm(paid_by).lower()
    return {
        "salman": "Salman Director Current A/C",
        "humayun": "Humayun Director Current A/C",
        "adnan": "Adnan Director Current A/C",
        "mustafa": "Mustafa Imprest / Payable",
    }.get(w, "Cash on Hand")


def map_row(account, particulars, paid_by, dr, cr):
    a = norm(account).upper()
    p = norm(particulars).upper()
    who = norm(paid_by)
    amount = float(dr or cr or 0)
    is_receipt = float(cr or 0) > 0 and float(dr or 0) == 0
    w = who.lower()
    fund = counterparty(who)
    cash = (
        "Cash Held by Salman" if w == "salman" else
        "Cash Held by Humayun" if w == "humayun" else
        "Cash on Hand"
    )

    if a == "SALE PAYMENT": return cash, "Customer Advances / Plot Sale Receipts", "Auto-mapped sale receipt"
    if a in ("SITE EXPENSES", "SITE EXPENSE"): return "Development Cost - Site Expenses", fund, "Auto-mapped site expense"
    if a == "CONTRACTOR": return "Development Cost - Contractor & Materials", fund, "Auto-mapped contractor/development cost"
    if a == "LAND PAYMENT": return "Land Inventory - Horizon Homes", fund, "Auto-mapped land payment"
    if a == "RUDA": return "RUDA & Government Charges", fund, "Auto-mapped RUDA/government charge"
    if a == "COMMISSION": return "Sales Commission Expense", fund, "Auto-mapped sales commission"
    if a == "GT ROAD OFFICE EXP":
        if "PETTY CASH" in p and w == "mustafa" and is_receipt:
            return "Cash on Hand", "Petty Cash - Mustafa", "Petty cash returned by Mustafa"
        return "Administrative Expenses - GT Road Office", fund, "Auto-mapped GT Road office expense"
    if a in ("ASSESTS", "ASSETS"): return "Site Equipment / Container", fund, "Auto-mapped site asset"
    if a == "BILAL MITTI": return "Development Cost - Bilal Mitti", fund, "Auto-mapped Bilal Mitti development cost"
    if a == "WASEEM MITTI": return "Development Cost - Waseem Mitti", fund, "Auto-mapped Waseem Mitti development cost"
    if a == "ASIM PRINTER": return "Printing & Marketing Expense", fund, "Auto-mapped printing expense"
    if a == "LOAN TO TARA SB": return "Loan Receivable - Sh. Tara", fund, "Auto-mapped Tara loan receivable"
    if a == "HUMAYUN LOAN":
        if "RETURN" in p or "REPAY" in p: return "Loan Payable - Humayun", fund, "Loan repayment to Humayun"
        return "Director Receivable - Humayun", fund, "Auto-mapped Humayun loan/advance"
    if a == "LOAN RETURN":
        for key, acct in (("ADNAN", "Loan Payable - Adnan"), ("HUMAYUN", "Loan Payable - Humayun"),
                          ("QASIM", "Loan Payable - Qasim"), ("SHER", "Loan Payable - Sher Bano"),
                          ("SHAIR", "Loan Payable - Sher Bano")):
            if key in p: return acct, fund, "Auto-mapped loan repayment"
        raise ValueError(f"Loan return beneficiary unclear: {particulars}")
    if a in ("LOAN", "SALMAN LOAN", "ADNAN LOAN"):
        if "INTEREST" in p or "INTREST" in p: return "Finance Cost - Loan Interest", fund, "Auto-mapped loan interest"
        if "RECEIVED" in p or "RECIVED" in p or "RECEIVED LOAN" in p or p.startswith("LOAN FROM"):
            for key, acct in (("HUMAYUN", "Loan Payable - Humayun"), ("ADNAN", "Loan Payable - Adnan"),
                              ("SALMAN", "Loan Payable - Salman"), ("QASIM", "Loan Payable - Qasim"),
                              ("SHER BANO", "Loan Payable - Sher Bano"), ("SHER", "Loan Payable - Sher Bano"),
                              ("ARSHAD", "Loan Payable - Arshad"), ("ZK", "Loan Payable - ZK"), ("WAQAS", "Loan / Advance - Review Required")):
                if key in p: return "Cash on Hand", acct, "Auto-mapped loan received"
        if "TO HUMAYUN" in p: return "Director Receivable - Humayun", fund, "Auto-mapped Humayun loan/advance"
        if "TO SALMAN" in p: return "Director Receivable - Salman", fund, "Auto-mapped Salman loan/advance"
        if "TO ADNAN" in p: return "Director Receivable - Adnan", fund, "Auto-mapped Adnan loan/advance"
        if "ADNAN AGENT" in p: return "Advance / Receivable - Adnan Agent", fund, "Auto-mapped Adnan agent advance"
        if "RETURN" in p and "ADNAN" in p: return "Loan Payable - Adnan", fund, "Loan repayment to Adnan"
        if "RETURN" in p and "HUMAYUN" in p: return "Loan Payable - Humayun", fund, "Loan repayment to Humayun"
        if "RETURN" in p and "QASIM" in p: return "Loan Payable - Qasim", fund, "Loan repayment to Qasim"
        if "RETURN" in p and "AMIR JAVID" in p: return "Loan / Advance - Review Required", fund, "Loan repayment; lender not in chart of accounts"
        if "INTEREST" in p or "INTREST" in p: return "Finance Cost - Loan Interest", fund, "Auto-mapped loan interest"
    if a == "MISC":
        if any(k in p for k in ("REGISTRATION", "DOCUMENT", "STAMP PAPER")): return "Legal, Registration & Tax Expense", fund, "Auto-mapped legal/registration expense"
        if "MAP" in p or "PRINT" in p: return "Printing & Marketing Expense", fund, "Auto-mapped printing/marketing expense"
        if "SOFTWARE" in p: return "Software & IT Expense", fund, "Auto-mapped software/IT expense"
        if "LAPTOP" in p: return "Office Equipment", fund, "Auto-mapped office equipment expense"
        return "Miscellaneous Administrative Expense", fund, "Auto-mapped miscellaneous administrative expense"
    raise ValueError(f"No approved mapping for source account '{account}' / '{particulars}'")


def backup_table(db, name, model):
    # Portable CREATE TABLE AS backup for the active financial tables.
    db.execute(text(f"CREATE TABLE IF NOT EXISTS {name} AS SELECT * FROM {model.__tablename__} WHERE 1=0"))
    db.execute(text(f"DELETE FROM {name}"))
    db.execute(text(f"INSERT INTO {name} SELECT * FROM {model.__tablename__}"))


def main(path):
    path = Path(path)
    if not path.exists(): raise SystemExit(f"Workbook not found: {path}")
    wb = load_workbook(path, read_only=True, data_only=True)
    if "Horizon" not in wb.sheetnames: raise SystemExit("Workbook must contain a Horizon sheet")
    ws = wb["Horizon"]

    source = []
    # The supplied Horizon workbook has 552 transaction rows on rows 4-555.
    # Rows 556+ are a legacy repeated balance/summary area and must not be treated as transactions.
    for r in range(4, 556):
        dt, acct, code, part, paid, dr, cr = [ws.cell(r, c).value for c in range(1, 8)]
        if not any(v not in (None, "") for v in (dt, acct, part, paid, dr, cr)): continue
        try: drf, crf = float(dr or 0), float(cr or 0)
        except Exception: continue
        if drf and crf: raise SystemExit(f"Row {r} contains both DR and CR; refusing silent correction")
        source.append((r, parse_date(dt), norm(acct), norm(part), norm(paid), drf, crf))

    if len(source) != 552:
        raise SystemExit(f"Expected 552 transaction rows from the supplied workbook; found {len(source)}")

    with SessionLocal() as db:
        accounts = {a.name: a for a in db.scalars(select(Account)).all()}
        planned = []
        for r, dt, acct, part, paid, dr, cr in source:
            if not dt: raise SystemExit(f"Row {r}: invalid/missing date")
            debit_acct, credit_acct, note = map_row(acct, part, paid, dr, cr)
            if debit_acct not in accounts: raise SystemExit(f"Row {r}: missing account '{debit_acct}'")
            if credit_acct not in accounts: raise SystemExit(f"Row {r}: missing account '{credit_acct}'")
            amount = round(abs(dr or cr), 2)
            if amount <= 0: raise SystemExit(f"Row {r}: zero amount")
            planned.append((r, dt, acct, part, paid, dr, cr, debit_acct, credit_acct, amount, note))

        # One-time execution guard. The marker is written only after the full migration commits.
        db.execute(text("CREATE TABLE IF NOT EXISTS financial_reset_runs (run_key VARCHAR(100) PRIMARY KEY, completed_at TIMESTAMP, source_hash VARCHAR(64), voucher_count INTEGER)"))
        run_key = "HORIZON_MASTER_LEDGER_2026_09_30"
        already = db.execute(text("SELECT run_key FROM financial_reset_runs WHERE run_key=:k"), {"k": run_key}).first()
        if already:
            print("SKIPPED: financial reset already completed")
            return

        # Back up active accounting data before destructive reset.
        for name, model in (("financial_reset_backup_vouchers", Voucher), ("financial_reset_backup_voucher_lines", VoucherLine),
                            ("financial_reset_backup_migration_batches", MigrationBatch), ("financial_reset_backup_migration_rows", MigrationRow)):
            backup_table(db, name, model)

        # Remove references that would block voucher deletion; operational records remain.
        for model in (Booking, Receipt, Payroll, Commission):
            db.execute(text(f"UPDATE {model.__tablename__} SET posted_voucher_id=NULL" if model is not Payroll else "UPDATE payroll SET paid_voucher_id=NULL"))
        db.execute(text("UPDATE vouchers SET reversed_voucher_id=NULL"))
        db.execute(text("UPDATE migration_rows SET erp_voucher_id=NULL"))

        # Clear the accounting ledger and migration control records.
        db.query(VoucherLine).delete(synchronize_session=False)
        db.query(Voucher).delete(synchronize_session=False)
        db.query(MigrationRow).delete(synchronize_session=False)
        db.query(MigrationBatch).delete(synchronize_session=False)
        db.flush()

        # Recreate the migration control batch and one balanced double-entry journal voucher per source row.
        source_bytes = path.read_bytes()
        source_hash = hashlib.sha256(source_bytes).hexdigest()
        total_amount = round(sum(x[9] for x in planned), 2)
        batch = MigrationBatch(
            batch_no=f"FINRESET-{source_hash[:12]}", file_name=path.name, file_hash=source_hash,
            imported_by=USER, source_rows=len(planned), imported_count=0, skipped_count=0,
            duplicate_count=0, mismatch_count=0, matched_count=0,
            debit_total=total_amount, credit_total=total_amount, status="Importing",
            notes="Controlled financial reset from supplied Horizon master ledger; each source row is converted to a balanced double-entry voucher."
        )
        db.add(batch); db.flush()

        for seq, (r, dt, acct, part, paid, dr, cr, debit_acct, credit_acct, amount, note) in enumerate(planned, 1):
            vno = f"JV-{r-3:04d}"
            key = f"{path.name}|Horizon|{r}|{vno}"
            voucher = create_voucher(db, voucher_date=dt, voucher_type="Journal", party=paid, narration=part,
                lines=[{"account":debit_acct,"debit":amount,"credit":0,"party":paid,"memo":f"Horizon source row {r}"},
                       {"account":credit_acct,"debit":0,"credit":amount,"party":paid,"memo":f"Horizon source row {r}"}],
                user_name=USER, source_module="Master Excel Migration", source_reference=key, status="Posted", voucher_no=vno)
            db.add(MigrationRow(
                batch_id=batch.id, migration_key=key, source_workbook=path.name, source_sheet="Horizon",
                source_row=r, voucher_no=vno, transaction_date=dt, source_account=acct, particulars=part,
                paid_received_by=paid, debit_account=debit_acct, credit_account=credit_acct,
                debit=amount, credit=amount, customer_reference="", plot_no="", party_name=paid,
                reconciliation_status="Matched", mismatch_details=note, erp_voucher_id=voucher.id, posted=True
            ))

        batch.imported_count = len(planned)
        batch.matched_count = len(planned)
        batch.mismatch_count = 0
        batch.status = "Completed"
        db.add(MigrationRow) if False else None
        db.flush()
        db.execute(text("INSERT INTO financial_reset_runs(run_key, completed_at, source_hash, voucher_count) VALUES (:k, CURRENT_TIMESTAMP, :h, :n)"),
                   {"k": run_key, "h": source_hash, "n": len(planned)})
        db.commit()
        print(f"SUCCESS: replaced active financial ledger with {len(planned)} balanced vouchers")
        print(f"Source DR: {sum(x[5] for x in planned):,.2f}; Source CR: {sum(x[6] for x in planned):,.2f}")
        print(f"Posted voucher total: {sum(x[9] for x in planned):,.2f} debit and credit")
        print("Operational customer/plot/booking records were retained; their old posted-voucher links were cleared.")
        print("Backup tables created: financial_reset_backup_vouchers, financial_reset_backup_voucher_lines, financial_reset_backup_migration_batches, financial_reset_backup_migration_rows")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "Horizon Ledger 6 Sep till.xlsx")
