'use strict';

const state = {
  user: null,
  csrf: null,
  route: 'dashboard',
  currentLoader: null,
  installPrompt: null,
  tableSort: { bookings: { by: 'booking_date', dir: 'desc' } },
};

const TABLE_SORT_KEYS = {
  customers: {'Customer':'name','CNIC':'cnic','Mobile':'mobile','Email':'email','Address':'address','Status':'status'},
  plots: {'Plot':'plot_no','Type':'category','Status':'status','Customer':'customer_name','List Price':'list_price','Sale Value':'sale_price','Received':'received','Outstanding':'outstanding'},
  reservations: {'Reservation':'reservation_date','Plot':'plot_no','Customer':'customer_name','Deposit':'amount','Expiry':'expiry_date','Mode':'payment_mode','Status':'status'},
  'payment-plans': {'Plan Code':'code','Plan Name':'name','Category':'category','Size Marla':'size_marla','Status':'active'},
  transfers: {'Transfer':'transfer_no','Plot':'plot_no','Booking':'booking_no','From Customer':'from_customer','To Customer':'to_customer','Dues Verified':'dues_at_transfer','Status':'status'},
  bookings: {'Booking':'booking_no','Plot':'plot_no','Customer':'customer_name','Plan':'payment_plan','Gross Price':'sale_price','Discount':'discount','Net Sale':'net_sale_value','Dealer':'dealer_name','Status':'status'},
  receipts: {'Receipt':'receipt_date','Booking':'booking_no','Customer':'customer_name','Amount':'amount','Mode':'mode','Reference':'reference','Narration':'narration'},
  installments: {'Due Date':'due_date','Booking / Plot':'booking_no','Customer':'customer_name','Type':'due_type','Due':'amount','Paid':'paid','Balance':'balance','Status':'status'},
  leads: {'Lead':'name','Interest':'interest','Source':'source','Budget':'budget','Assigned':'assigned_to','Next Follow-up':'next_followup','Stage':'stage'},
  development: {'Work Package':'code','Contractor':'contractor','Budget':'budget','Committed':'committed_cost','Actual':'actual_cost','Progress':'progress_percent','Status':'status','Target':'target_date'},
  vouchers: {'Voucher':'voucher_date','Party':'party','Narration':'narration','Amount':'amount','Source':'source_module','Status':'status'},
  directorAccounts: {'Code':'code','Ledger Account':'name','Voucher Lines':'lines','Debit':'debit','Credit':'credit','Balance':'balance','Status':'active'},
  financialIntegrity: {'Voucher':'voucher_no','Date':'voucher_date','Party':'party','Amount':'amount','Source':'source_module','Status':'integrity_status'},
  audit: {'Date & Time':'at','User':'user_name','Action':'action','Module':'module','Record':'record_id','Details':'details','IP':'ip_address'},
  dealers: {'Dealer':'name','Plots Sold':'plots_sold','Sales Value':'sales_value','Commission Earned':'commission_earned','Paid':'commission_paid','Payable':'commission_payable','Status':'active'},
  commissions: {'Commission':'commission_date','Dealer / Director':'dealer_name','Booking / Plot':'booking_no','Basis':'basis','Earned':'commission_amount','Paid':'paid_amount','Payable':'payable','Status':'status'},
  expenses: {'Date / Voucher':'expense_date','Expense Account':'account','Party / Paid For':'party','Narration':'narration','Amount':'amount','Source':'source_module','Status':'status'},
  parties: {'Party':'name','Type':'party_type','Mobile':'mobile','Email':'email','Opening Balance':'opening_balance','Status':'active'},
  purchaseOrders: {'Purchase Order':'po_date','Vendor / Contractor':'vendor_name','Description':'description','Amount':'amount','Expected':'expected_date','Status':'status','Approved By':'approved_by'},
  employees: {'Employee':'name','Department':'department','Designation':'designation','Mobile':'mobile','Joining':'joining_date','Salary':'salary','Status':'status'},
  payroll: {'Month':'payroll_month','Employee':'employee_name','Basic':'basic_salary','Allowances':'allowances','Deductions':'deductions','Net Pay':'net_pay','Status':'status'},
  compliance: {'Reference':'reference_no','Subject':'subject','Issue Date':'issue_date','Due Date':'due_date','Responsible':'responsible_person','Status':'status'},
  documents: {'File':'file_name','Module':'module','Record ID':'record_id','Uploaded By':'uploaded_by','Date':'created_at'},
  users: {'User':'full_name','Role':'role','Customer Link':'customer_id','Status':'active','Created':'created_at'},
  migrationRows: {'Source':'source_row','Voucher / Date':'voucher_no','Transaction':'particulars','Debit Account':'debit_account','Credit Account':'credit_account','Debit':'debit','Credit':'credit','Status':'reconciliation_status'},
  whatsappLogs: {'Date / Time':'created_at','Type':'message_type','Mobile':'mobile','Template':'template_name','Status':'status','Sent By':'sent_by','Booking':'booking_id','Installment':'installment_id'},
};

const TABLE_SORT_DEFAULTS = {
  customers:{by:'name',dir:'asc'}, plots:{by:'plot_no',dir:'asc'}, reservations:{by:'reservation_date',dir:'desc'}, bookings:{by:'booking_date',dir:'desc'},
  receipts:{by:'receipt_date',dir:'desc'}, installments:{by:'due_date',dir:'asc'}, leads:{by:'next_followup',dir:'asc'}, development:{by:'code',dir:'asc'},
  vouchers:{by:'voucher_date',dir:'desc'}, directorAccounts:{by:'name',dir:'asc'}, financialIntegrity:{by:'voucher_date',dir:'asc'}, audit:{by:'at',dir:'desc'}, dealers:{by:'name',dir:'asc'},
  commissions:{by:'commission_date',dir:'desc'}, expenses:{by:'expense_date',dir:'desc'}, parties:{by:'party_type',dir:'asc'}, purchaseOrders:{by:'po_date',dir:'desc'},
  employees:{by:'department',dir:'asc'}, payroll:{by:'payroll_month',dir:'desc'}, compliance:{by:'due_date',dir:'asc'}, documents:{by:'created_at',dir:'desc'},
  users:{by:'role',dir:'asc'}, migrationRows:{by:'source_row',dir:'asc'}, whatsappLogs:{by:'created_at',dir:'desc'},
};

function getTableSort(id) {
  if (!state.tableSort[id]) state.tableSort[id] = {...(TABLE_SORT_DEFAULTS[id] || {by:'',dir:'asc'})};
  return state.tableSort[id];
}
function sortUrl(id, url) {
  const sort=getTableSort(id);
  if (!sort.by) return url;
  return `${url}${url.includes('?')?'&':'?'}sort_by=${encodeURIComponent(sort.by)}&sort_dir=${encodeURIComponent(sort.dir)}`;
}

const $ = (s, root = document) => {
  const base = typeof root === 'string' ? document.querySelector(root) : root;
  return base ? base.querySelector(s) : null;
};
const $$ = (s, root = document) => {
  const base = typeof root === 'string' ? document.querySelector(root) : root;
  return base ? [...base.querySelectorAll(s)] : [];
};
const content = $('#content');
const loginView = $('#loginView');
const appView = $('#appView');
const loading = $('#loading');
const toastBox = $('#toast');

const money = (n) => new Intl.NumberFormat('en-PK', { style: 'currency', currency: 'PKR', maximumFractionDigits: 0 }).format(Number(n || 0));
const number = (n, digits = 0) => new Intl.NumberFormat('en-PK', { maximumFractionDigits: digits }).format(Number(n || 0));
const dateText = (d) => d ? new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(`${String(d).slice(0, 10)}T00:00:00`)) : '—';
const esc = (v) => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const slug = (v) => String(v || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const today = () => new Date().toISOString().slice(0, 10);

function setLoading(on) { loading.classList.toggle('hidden', !on); }
function toast(message, type = 'success') {
  toastBox.textContent = message;
  toastBox.className = `toast show ${type}`;
  clearTimeout(toastBox._timer);
  toastBox._timer = setTimeout(() => toastBox.className = 'toast', 3200);
}

async function api(path, options = {}) {
  const opts = { credentials: 'same-origin', ...options };
  opts.headers = { ...(opts.rawBody ? {} : {'Content-Type': 'application/json'}), ...(options.headers || {}) };
  if (opts.method && !['GET', 'HEAD'].includes(opts.method.toUpperCase()) && state.csrf) {
    opts.headers['X-CSRF-Token'] = state.csrf;
  }
  const res = await fetch(`/api${path}`, opts);
  const type = res.headers.get('content-type') || '';
  const data = type.includes('application/json') ? await res.json() : await res.text();
  if (!res.ok) {
    if (res.status === 401 && path !== '/login') showLogin();
    throw new Error(data?.detail || data || `Request failed (${res.status})`);
  }
  return data;
}


// ---------------- WebAuthn / biometric helpers (V22/V24) ----------------
function b64urlToBytes(value){
  const text=String(value||'').replace(/-/g,'+').replace(/_/g,'/');
  const padded=text+'='.repeat((4-text.length%4)%4); const raw=atob(padded);
  return Uint8Array.from(raw,c=>c.charCodeAt(0));
}
function bytesToB64url(value){
  if(value==null)return null; const bytes=value instanceof ArrayBuffer?new Uint8Array(value):new Uint8Array(value.buffer||value);
  let binary=''; bytes.forEach(b=>binary+=String.fromCharCode(b)); return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function prepareCreationOptions(options){
  const p=structuredClone(options); p.challenge=b64urlToBytes(p.challenge); p.user.id=b64urlToBytes(p.user.id);
  (p.excludeCredentials||[]).forEach(x=>x.id=b64urlToBytes(x.id)); return p;
}
function prepareRequestOptions(options){
  const p=structuredClone(options); p.challenge=b64urlToBytes(p.challenge); (p.allowCredentials||[]).forEach(x=>x.id=b64urlToBytes(x.id)); return p;
}
function registrationCredentialJSON(cred){
  return {id:cred.id,rawId:bytesToB64url(cred.rawId),type:cred.type,authenticatorAttachment:cred.authenticatorAttachment,
    response:{clientDataJSON:bytesToB64url(cred.response.clientDataJSON),attestationObject:bytesToB64url(cred.response.attestationObject),transports:cred.response.getTransports?.()||[]},
    clientExtensionResults:cred.getClientExtensionResults?.()||{}};
}
function authenticationCredentialJSON(cred){
  return {id:cred.id,rawId:bytesToB64url(cred.rawId),type:cred.type,authenticatorAttachment:cred.authenticatorAttachment,
    response:{clientDataJSON:bytesToB64url(cred.response.clientDataJSON),authenticatorData:bytesToB64url(cred.response.authenticatorData),signature:bytesToB64url(cred.response.signature),userHandle:cred.response.userHandle?bytesToB64url(cred.response.userHandle):null},
    clientExtensionResults:cred.getClientExtensionResults?.()||{}};
}
function requireWebAuthn(){if(!window.PublicKeyCredential||!navigator.credentials)throw new Error('This browser/device does not support biometric/passkey verification. Use current Chrome, Edge, Safari or a supported mobile browser.');}
async function enrollCustomerBiometric(customerId,label='Customer biometric / passkey'){
  requireWebAuthn(); const settings=await api('/biometrics/settings'); if(!settings.ready)throw new Error(settings.error||'Biometric service is not ready');
  const start=await api(`/biometrics/customers/${customerId}/registration/options`,{method:'POST',body:JSON.stringify({label})});
  const credential=await navigator.credentials.create({publicKey:prepareCreationOptions(start.publicKey)}); if(!credential)throw new Error('Biometric enrollment was cancelled');
  return api(`/biometrics/customers/${customerId}/registration/verify`,{method:'POST',body:JSON.stringify({challenge_id:start.challenge_id,label,credential:registrationCredentialJSON(credential)})});
}
async function verifyCustomerBiometric(customerId,bookingId,purpose){
  requireWebAuthn(); const start=await api('/biometrics/authentication/options',{method:'POST',body:JSON.stringify({customer_id:customerId,booking_id:bookingId,purpose})});
  const credential=await navigator.credentials.get({publicKey:prepareRequestOptions(start.publicKey)}); if(!credential)throw new Error('Biometric verification was cancelled');
  return api('/biometrics/authentication/verify',{method:'POST',body:JSON.stringify({customer_id:customerId,challenge_id:start.challenge_id,credential:authenticationCredentialJSON(credential)})});
}
async function showCustomerBiometric(customer){
  try{
    const data=await api(`/biometrics/customers/${customer.id}`); const rows=data.credentials.length?data.credentials.map(x=>`<tr><td>${esc(x.label)}</td><td>${esc(x.rp_id||'—')}</td><td>${x.active?pill('Active'):pill('Inactive')}</td><td>${x.last_used_at?new Date(x.last_used_at).toLocaleString():'Never'}</td><td>${['Admin','Finance'].includes(state.user.role)?`<button data-biometric-toggle="${x.id}" data-active="${x.active?'1':'0'}">${x.active?'Disable':'Enable'}</button>`:'—'}</td></tr>`).join(''):'<tr><td colspan="5">No biometric/passkey enrolled.</td></tr>';
    openDrawer(`Biometric identity · ${customer.name}`,`<div class="notice info"><b>Privacy-safe biometric verification</b><br>Horizon ERP never receives or stores the customer fingerprint or face image. The phone/PC authenticator verifies the user and the ERP stores only a public passkey credential.</div><div class="actions" style="margin:12px 0"><button id="enrollCustomerBiometric" class="primary">+ Enroll biometric / passkey</button></div><div class="table-wrap"><table><thead><tr><th>Device / Label</th><th>ERP Domain</th><th>Status</th><th>Last Used</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table></div><div class="notice" style="margin-top:12px">For remote/customer use, host Horizon ERP on HTTPS. Localhost works for testing; ordinary HTTP LAN addresses may be rejected by the browser security model.</div>`,true);
    $('#enrollCustomerBiometric')?.addEventListener('click',async()=>{try{setLoading(true);await enrollCustomerBiometric(customer.id,`${customer.name} biometric`);toast('Biometric/passkey enrolled');await showCustomerBiometric(customer);}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
    $$('[data-biometric-toggle]').forEach(b=>b.addEventListener('click',async()=>{try{await api(`/biometrics/credentials/${b.dataset.biometricToggle}`,{method:'PATCH',body:JSON.stringify({active:b.dataset.active!=='1'})});toast('Biometric credential updated');await showCustomerBiometric(customer);}catch(e){toast(e.message,'error')}}));
  }catch(e){toast(e.message,'error')}
}

function showLogin() {
  state.user = null; state.csrf = null;
  appView.classList.add('hidden'); loginView.classList.remove('hidden');
}
function showApp() {
  loginView.classList.add('hidden'); appView.classList.remove('hidden');
}

const NAV = [
  { section: 'Overview', items: [
    { id: 'dashboard', label: 'Executive Dashboard', icon: '▦', roles: ['Admin','Finance','Sales','CRM','Development'] },
    { id: 'project-overview', label: 'Project Overview', icon: '⌖', roles: ['Admin','Finance','Sales','CRM','Development'] },
    { id: 'portal', label: 'My Horizon Account', icon: '⌂', roles: ['Customer'] },
  ]},
  { section: 'Sales & Collections', items: [
    { id: 'plots', label: 'Plot Inventory', icon: '▤', roles: ['Admin','Finance','Sales','CRM','Development'] },
    { id: 'customers', label: 'Customers', icon: '◎', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'reservations', label: 'Reservations', icon: '◫', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'bookings', label: 'Bookings', icon: '◇', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'payment-plans', label: 'Payment Plans', icon: '▦', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'receipts', label: 'Receipts', icon: '▣', roles: ['Admin','Finance','Sales'] },
    { id: 'installments', label: 'Installments & Forecast', icon: '◷', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'receivables', label: 'Receivables & Aging', icon: '₨', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'transfers', label: 'Plot Transfers', icon: '⇆', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'whatsapp', label: 'WhatsApp Notifications', icon: 'W', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'dealers', label: 'Dealers', icon: '♢', roles: ['Admin','Finance','Sales','CRM'] },
    { id: 'commissions', label: 'Commissions', icon: '%', roles: ['Admin','Finance','Sales'] },
  ]},
  { section: 'Operations', items: [
    { id: 'crm', label: 'CRM Pipeline', icon: '◉', roles: ['Admin','Sales','CRM'] },
    { id: 'development', label: 'Development Control', icon: '△', roles: ['Admin','Finance','Development'] },
    { id: 'procurement', label: 'Procurement', icon: '▱', roles: ['Admin','Finance','Development'] },
    { id: 'hr', label: 'HR & Payroll', icon: '♙', roles: ['Admin','Finance'] },
    { id: 'compliance', label: 'RUDA & Compliance', icon: '⚑', roles: ['Admin','Finance','Development'] },
    { id: 'documents', label: 'Document Register', icon: '▧', roles: ['Admin','Finance','Sales','CRM','Development'] },
  ]},
  { section: 'Financial Management', items: [
    { id: 'finance', label: 'Finance & Vouchers', icon: '₨', roles: ['Admin','Finance'] },
    { id: 'financial-integrity', label: 'Financial Integrity', icon: '✓', roles: ['Admin','Finance'] },
    { id: 'reports', label: 'Reports & Statements', icon: '▥', roles: ['Admin','Finance'] },
    { id: 'migration', label: 'Data Migration & Reconciliation', icon: '⇄', roles: ['Admin','Finance'] },
    { id: 'account-cleanup', label: 'Account Cleanup & Mapping', icon: '≋', roles: ['Admin','Finance'] },
    { id: 'expenses', label: 'Expense Register', icon: '↘', roles: ['Admin','Finance'] },
    { id: 'parties', label: 'Parties & Contractors', icon: '◌', roles: ['Admin','Finance','Development'] },
    { id: 'audit', label: 'Audit Trail', icon: '✓', roles: ['Admin','Finance','Sales','CRM','Development'] },
  ]},
  { section: 'System', items: [
    { id: 'users', label: 'Users & Roles', icon: '⌘', roles: ['Admin'] },
    { id: 'settings', label: 'Settings & Deployment', icon: '⚙', roles: ['Admin','Finance','Sales','CRM','Development','Customer'] },
  ]},
];

function buildNav() {
  const role = state.user.role;
  $('#nav').innerHTML = NAV.map(section => {
    const items = section.items.filter(i => i.roles.includes(role));
    if (!items.length) return '';
    return `<div class="nav-section">${esc(section.section)}</div>${items.map(i => `<button class="nav-item" data-route="${i.id}"><span class="nav-icon">${i.icon}</span><span>${esc(i.label)}</span></button>`).join('')}`;
  }).join('');
  $$('[data-route]').forEach(btn => btn.addEventListener('click', () => navigate(btn.dataset.route)));
}

function navigate(route) {
  location.hash = route;
  if (window.innerWidth <= 820) closeSidebar();
}

const TITLES = {
  dashboard: ['Executive Dashboard', 'Live finance, sales, CRM and development overview'],
  'project-overview': ['Horizon Homes Project Overview', 'Land, KMZ boundary, planning area, inventory, sales and development in one management view'],
  portal: ['My Horizon Account', 'Plots, receipts and installment statement'],
  plots: ['Plot Inventory', 'Real-time availability, reservation and sales position'],
  customers: ['Customer Master', 'Central customer records and contact information'],
  reservations: ['Plot Reservations', 'Controlled reservations, deposits and releases'],
  bookings: ['Sales Bookings', 'Posted plot sales and approved amendments'],
  'payment-plans': ['Payment Plan Templates', 'Upload and manage multiple customized collection schedules'],
  receipts: ['Receipts & Collections', 'Customer collections with automatic accounting'],
  installments: ['Installments & Forecast', 'Dues, overdue aging and expected collections'],
  receivables: ['Receivables & Aging', 'Current-month dues, overdue categories and future receivable forecasting'],
  transfers: ['Plot Transfers', 'Dues-clear ownership transfers with configurable biometric verification'],
  whatsapp: ['WhatsApp Notifications', 'Booking confirmations, due reminders and API delivery logs'],
  dealers: ['Dealer Management', 'Sales performance, ledgers and commission payable'],
  commissions: ['Commission Management', 'Calculate, approve, post and settle commissions'],
  crm: ['CRM Pipeline', 'Leads, follow-ups and conversion control'],
  development: ['Development Control', 'Budget, actual cost and physical progress'],
  procurement: ['Procurement', 'Vendors, purchase orders and approval status'],
  hr: ['HR & Payroll', 'Employees, salaries and posted payroll payments'],
  compliance: ['RUDA & Compliance', 'Notices, approvals, due dates and responsibility'],
  documents: ['Document Register', 'Customer, project and compliance document links'],
  finance: ['Financial Management', 'Vouchers, ledgers and statutory statements'],
  'financial-integrity': ['Financial Integrity', 'Duplicate control, balanced totals and audit-safe financial corrections'],
  reports: ['Reports & Statements', 'Date-filtered day book, account statements and exports'],
  migration: ['Data Migration & Reconciliation', 'Master Excel validation, control totals and exception reporting'],
  'account-cleanup': ['Account Cleanup & Mapping', 'Consolidate duplicate ledger names without losing the audit trail'],
  expenses: ['Expense Register', 'Company and director-paid expenses with automatic posting'],
  parties: ['Parties & Contractors', 'Vendors, dealers, contractors and directors'],
  audit: ['Audit Trail', 'User activity and transaction history'],
  users: ['Users & Roles', 'Access control and customer portal accounts'],
  settings: ['Settings & Deployment', 'Mobile installation, security and hosting guidance'],
};

async function loadRoute() {
  let route = location.hash.replace('#', '') || (state.user?.role === 'Customer' ? 'portal' : 'dashboard');
  const allowed = NAV.flatMap(s => s.items).find(i => i.id === route && i.roles.includes(state.user.role));
  if (!allowed) route = state.user.role === 'Customer' ? 'portal' : 'dashboard';
  state.route = route;
  $$('[data-route]').forEach(x => x.classList.toggle('active', x.dataset.route === route));
  const [title, subtitle] = TITLES[route] || [route, ''];
  $('#pageTitle').textContent = title; $('#pageSubtitle').textContent = subtitle;
  content.innerHTML = `<div class="empty-state"><div class="spinner" style="margin:auto;border-color:#ddd;border-top-color:#111827"></div></div>`;
  try {
    const loaders = { dashboard: loadDashboard, 'project-overview': loadProjectOverview, portal: loadPortal, plots: loadPlots, customers: loadCustomers, reservations: loadReservations, bookings: loadBookings, 'payment-plans': loadPaymentPlans, receipts: loadReceipts, installments: loadInstallments, receivables: loadReceivables, transfers: loadTransfers, whatsapp: loadWhatsApp, dealers: loadDealers, commissions: loadCommissions, crm: loadCRM, development: loadDevelopment, procurement: loadProcurement, hr: loadHR, compliance: loadCompliance, documents: loadDocuments, finance: loadFinance, 'financial-integrity': loadFinancialIntegrity, reports: loadReports, migration: loadMigration, 'account-cleanup': loadAccountCleanup, expenses: loadExpenses, parties: loadParties, audit: loadAudit, users: loadUsers, settings: loadSettings };
    state.currentLoader = loaders[route];
    await state.currentLoader();
  } catch (e) {
    content.innerHTML = `<div class="notice">${esc(e.message)}</div>`;
    toast(e.message, 'error');
  }
}

function pageHead(title, description, actions = '') {
  return `<div class="page-head"><div><h2>${esc(title)}</h2><p>${esc(description)}</p></div><div class="actions">${actions}</div></div>`;
}
function kpi(label, value, foot = '', accent = false) {
  return `<div class="kpi-card ${accent ? 'accent' : ''}"><div class="kpi-label">${esc(label)}</div><div class="kpi-value">${value}</div><div class="kpi-foot">${esc(foot)}</div></div>`;
}
function pill(status) { return `<span class="status-pill status-${slug(status)}">${esc(status || '—')}</span>`; }
function progress(value) { const n = Math.max(0, Math.min(100, Number(value || 0))); return `<div class="progress-label"><div class="progress"><i style="width:${n}%"></i></div><span>${number(n,1)}%</span></div>`; }

function _tableSortValue(item, key) {
  const value=item?.[key];
  if (value == null || value === '') return '';
  if (typeof value === 'number') return value;
  if (typeof value === 'boolean') return value ? 1 : 0;
  const text=String(value).trim();
  if (/^-?[\d,.]+$/.test(text)) return Number(text.replace(/,/g,''));
  if (/^\d{4}-\d{2}-\d{2}/.test(text)) { const n=Date.parse(text); if(!Number.isNaN(n)) return n; }
  return text.toLocaleLowerCase();
}
function _compareTableRows(a,b,key,dir) {
  const av=_tableSortValue(a,key), bv=_tableSortValue(b,key);
  if (av === bv) return 0;
  if (av === '') return 1;
  if (bv === '') return -1;
  const result=(typeof av==='number' && typeof bv==='number') ? av-bv : String(av).localeCompare(String(bv),undefined,{numeric:true,sensitivity:'base'});
  return dir==='desc' ? -result : result;
}
function renderTable({ id, columns, items, total, page = 1, size = 25, query = '', onSearch, onPage, sortBy = '', sortDir = '', onSort }) {
  const remembered=getTableSort(id);
  const activeSortBy=sortBy || remembered.by || '';
  const activeSortDir=(sortDir || remembered.dir || 'asc') === 'desc' ? 'desc' : 'asc';
  if (activeSortBy) state.tableSort[id]={by:activeSortBy,dir:activeSortDir};
  let displayItems=[...(items||[])];
  // Small/non-paginated tables are sorted locally; paginated tables are sorted server-side through sortUrl().
  if (activeSortBy && Number(total||0) <= displayItems.length) displayItems.sort((a,b)=>_compareTableRows(a,b,activeSortBy,activeSortDir));
  const rows = displayItems.length ? displayItems.map(item => `<tr>${columns.map(c => `<td>${c.render ? c.render(item) : esc(item[c.key])}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${columns.length}"><div class="empty-state"><b>No records found</b><span>Try changing your search or add a new record.</span></div></td></tr>`;
  const pages = Math.max(1, Math.ceil(total / size));
  const headers = columns.map(c => {
    const key = c.sortKey || TABLE_SORT_KEYS[id]?.[c.label] || c.key || '';
    const canSort = !!key && !['Actions','Link'].includes(c.label);
    if (!canSort) return `<th>${esc(c.label)}</th>`;
    const active = activeSortBy === key;
    const arrow = active ? (activeSortDir === 'asc' ? '▲' : '▼') : '↕';
    const ariaSort = active ? (activeSortDir === 'asc' ? 'ascending' : 'descending') : 'none';
    return `<th class="sortable-th ${active ? 'sorted' : ''}" aria-sort="${ariaSort}"><button type="button" class="sort-header" data-table-sort="${esc(id)}" data-sort-key="${esc(key)}" title="Sort by ${esc(c.label)}"><span>${esc(c.label)}</span><span class="sort-indicator" aria-hidden="true">${arrow}</span></button></th>`;
  }).join('');
  const html = `<div class="table-panel">
    <div class="table-toolbar"><div class="search-box"><input id="${id}Search" value="${esc(query)}" placeholder="Search records…"></div><div class="table-meta">${number(total)} records · Click any heading to sort</div></div>
    <div class="table-wrap"><table><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table></div>
    <div class="pagination"><span>Page ${page} of ${pages}</span><div><button id="${id}Prev" ${page <= 1 ? 'disabled' : ''}>Previous</button><button id="${id}Next" ${page >= pages ? 'disabled' : ''}>Next</button></div></div>
  </div>`;
  setTimeout(() => {
    const input = $(`#${id}Search`); let timer;
    input?.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => onSearch?.(input.value), 350); });
    $(`#${id}Prev`)?.addEventListener('click', () => onPage?.(page - 1));
    $(`#${id}Next`)?.addEventListener('click', () => onPage?.(page + 1));
    $$(`[data-table-sort="${id}"]`).forEach(btn => btn.addEventListener('click', () => {
      const key = btn.dataset.sortKey;
      const nextDir = activeSortBy === key ? (activeSortDir === 'asc' ? 'desc' : 'asc') : 'asc';
      state.tableSort[id]={by:key,dir:nextDir};
      if (onSort) onSort(key,nextDir);
      else if (Number(total||0) <= displayItems.length && state.currentLoader) state.currentLoader();
      else onSearch?.(query);
    }));
  });
  return html;
}

function actionButtons(buttons) {
  return `<div class="row-actions">${buttons.map(b => `<button data-action="${b.action}" data-id="${b.id}" title="${esc(b.title || b.label)}">${esc(b.label)}</button>`).join('')}</div>`;
}

// ---------------- Modal forms ----------------
function openModal({ title, eyebrow = 'DATA ENTRY', fields = [], values = {}, submitText = 'Save', onSubmit }) {
  $('#modalTitle').textContent = title; $('#modalEyebrow').textContent = eyebrow; $('#modalSubmit').textContent = submitText;
  $('#modalBody').innerHTML = fields.map(f => fieldHtml(f, values[f.name])).join('');
  $('#modal').classList.remove('hidden');
  $('#modalForm').onsubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget); const payload = {};
    fields.forEach(f => {
      if (f.type === 'checkbox') payload[f.name] = formData.get(f.name) === 'on';
      else payload[f.name] = formData.get(f.name) ?? '';
    });
    try { setLoading(true); await onSubmit(payload); closeModal(); toast('Saved successfully'); await state.currentLoader?.(); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };
  setTimeout(() => $('#modalBody input:not([type=hidden]), #modalBody select, #modalBody textarea')?.focus(), 30);
}
function fieldHtml(f, value) {
  const val = value ?? f.value ?? '';
  const full = f.full ? 'full' : '';
  if (f.type === 'checkbox') return `<label class="checkbox-field ${full}"><input type="checkbox" name="${f.name}" ${val ? 'checked' : ''}><span>${esc(f.label)}</span></label>`;
  const common = `name="${f.name}" ${f.required ? 'required' : ''} ${f.readonly ? 'readonly' : ''}`;
  let control;
  if (f.type === 'select') control = `<select ${common}>${(f.options || []).map(o => { const ov = typeof o === 'object' ? o.value : o; const ol = typeof o === 'object' ? o.label : o; return `<option value="${esc(ov)}" ${String(ov) === String(val) ? 'selected' : ''}>${esc(ol)}</option>`; }).join('')}</select>`;
  else if (f.type === 'textarea') control = `<textarea ${common} placeholder="${esc(f.placeholder || '')}">${esc(val)}</textarea>`;
  else control = `<input type="${f.type || 'text'}" ${common} value="${esc(val)}" placeholder="${esc(f.placeholder || '')}" ${f.step ? `step="${f.step}"` : ''} ${f.min != null ? `min="${f.min}"` : ''} ${f.max != null ? `max="${f.max}"` : ''}>`;
  return `<label class="form-field ${full}"><span>${esc(f.label)}${f.required ? ' *' : ''}</span>${control}${f.help ? `<small>${esc(f.help)}</small>` : ''}</label>`;
}
function closeModal() { $('#modal').classList.add('hidden'); $('#modalForm').onsubmit = null; }
$$('[data-close-modal]').forEach(x => x.addEventListener('click', closeModal));

function openDrawer(title, html, wide=false) { const d=$('#drawer'); $('#drawerTitle').textContent = title; $('#drawerBody').innerHTML = html; d.classList.toggle('report-wide', !!wide); d.classList.remove('hidden'); }
function closeDrawer() { const d=$('#drawer'); d.classList.add('hidden'); d.classList.remove('report-wide'); }
$$('[data-close-drawer]').forEach(x => x.addEventListener('click', closeDrawer));

function openReportWorkspace(title, html) {
  const w=$('#reportWorkspace');
  $('#reportWorkspaceTitle').textContent=title;
  $('#reportWorkspaceBody').innerHTML=html;
  w.classList.remove('hidden');
  document.body.classList.add('report-open');
  requestAnimationFrame(()=>$('#reportWorkspaceBody')?.scrollTo({top:0,left:0,behavior:'instant'}));
}
function closeReportWorkspace(){
  $('#reportWorkspace').classList.add('hidden');
  $('#reportWorkspaceBody').innerHTML='';
  document.body.classList.remove('report-open');
}
$$('[data-close-report]').forEach(x=>x.addEventListener('click',closeReportWorkspace));
document.addEventListener('keydown',e=>{ if(e.key==='Escape' && !$('#reportWorkspace').classList.contains('hidden')) closeReportWorkspace(); });

// ---------------- Universal table sorting ----------------
// renderTable() uses safe server-side sorting for paginated business tables. This helper
// adds local header sorting to every remaining plain HTML table (reports, portal tables,
// mapping tables, preview tables, etc.) so every ERP window behaves consistently.
function _domSortValue(text) {
  let value=String(text ?? '').replace(/\s+/g,' ').trim();
  if (!value || value==='—') return {kind:3,value:''};
  const negative=/^\(.*\)$/.test(value) || /^-/.test(value);
  const numeric=value.replace(/\b(PKR|Rs\.?|Rupees?)\b/gi,'').replace(/[,%()]/g,'').replace(/\s/g,'');
  if (/^-?\d+(?:\.\d+)?$/.test(numeric)) {
    const n=Number(numeric); return {kind:0,value:negative && n>0 ? -n : n};
  }
  const iso=value.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return {kind:1,value:Number(`${iso[1]}${iso[2]}${iso[3]}`)};
  const dmy=value.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
  if (dmy) return {kind:1,value:Number(`${dmy[3]}${String(dmy[2]).padStart(2,'0')}${String(dmy[1]).padStart(2,'0')}`)};
  const parsed=Date.parse(value);
  if (!Number.isNaN(parsed) && /\d/.test(value) && /[A-Za-z]{3}|[\/-]/.test(value)) return {kind:1,value:parsed};
  return {kind:2,value:value.toLocaleLowerCase()};
}
function _compareDomValues(a,b) {
  if (a.kind!==b.kind) return a.kind-b.kind;
  if (typeof a.value==='number' && typeof b.value==='number') return a.value-b.value;
  return String(a.value).localeCompare(String(b.value),undefined,{numeric:true,sensitivity:'base'});
}
function decorateDomTables(root=document) {
  $$('table',root).forEach(table=>{
    if (table.dataset.universalSortReady==='1') return;
    table.dataset.universalSortReady='1';
    const headers=$$('thead th',table);
    headers.forEach((th,index)=>{
      if (th.querySelector('.sort-header')) return; // renderTable() already owns this header.
      const label=th.textContent.trim();
      if (!label || /^(actions?|link)$/i.test(label)) return;
      th.dataset.domSortIndex=String(index);
      th.classList.add('dom-sortable-th');
      th.tabIndex=0;
      th.title=`Sort by ${label}`;
      const indicator=document.createElement('span');
      indicator.className='dom-sort-indicator'; indicator.textContent='↕'; indicator.setAttribute('aria-hidden','true');
      th.appendChild(indicator);
    });
  });
}
function sortDomTable(th) {
  const table=th.closest('table'); if(!table) return;
  const index=Number(th.dataset.domSortIndex); if(!Number.isInteger(index)) return;
  const previous=Number(table.dataset.domSortIndex);
  const dir=(previous===index && table.dataset.domSortDir==='asc')?'desc':'asc';
  table.dataset.domSortIndex=String(index); table.dataset.domSortDir=dir;
  $$('thead th[data-dom-sort-index]',table).forEach(h=>{
    h.classList.toggle('sorted',h===th);
    const i=$('.dom-sort-indicator',h); if(i) i.textContent=h===th?(dir==='asc'?'▲':'▼'):'↕';
    h.setAttribute('aria-sort',h===th?(dir==='asc'?'ascending':'descending'):'none');
  });
  $$('tbody',table).forEach(body=>{
    const rows=$$('tr',body).filter(row=>row.children.length>index && !row.querySelector('.empty-state'));
    const decorated=rows.map((row,pos)=>({row,pos,value:_domSortValue(row.children[index]?.textContent||'')}));
    decorated.sort((a,b)=>{const c=_compareDomValues(a.value,b.value); return (dir==='desc'?-c:c)||a.pos-b.pos;});
    decorated.forEach(x=>body.appendChild(x.row));
  });
}
document.addEventListener('click',event=>{
  const th=event.target.closest?.('th[data-dom-sort-index]');
  if (th && !event.target.closest('button,a,input,select,textarea')) sortDomTable(th);
});
document.addEventListener('keydown',event=>{
  const th=event.target.closest?.('th[data-dom-sort-index]');
  if (th && (event.key==='Enter'||event.key===' ')) { event.preventDefault(); sortDomTable(th); }
});
let _decorateTablesFrame=0;
const _tableObserver=new MutationObserver(()=>{
  if (_decorateTablesFrame) return;
  _decorateTablesFrame=requestAnimationFrame(()=>{_decorateTablesFrame=0;decorateDomTables(document);});
});
_tableObserver.observe(document.body,{childList:true,subtree:true});
decorateDomTables(document);

// ---------------- Dashboard ----------------
async function loadDashboard() {
  const data = await api('/dashboard'); const k = data.kpis;
  const max = Math.max(1, ...data.monthly_collections.flatMap(x => [x.expected, x.actual]));
  const totalMix = data.plot_mix.reduce((s,x)=>s+x.value,0) || 1;
  const av = data.plot_mix[0]?.value || 0, rs = data.plot_mix[1]?.value || 0;
  const pct1 = av / totalMix * 100, pct2 = (av + rs) / totalMix * 100;
  content.innerHTML = `${pageHead('Management overview', 'Financial and operational KPIs updated from posted transactions.', `<button class="secondary" data-route="receipts">View collections</button><button class="primary" data-route="plots">Open plot inventory</button>`)}
  <div class="kpi-grid">
    ${kpi('Total Sales Value', money(k.sales_value), `${number(k.booked_sold)} booked / sold plots`, true)}
    ${kpi('Collections Received', money(k.received), `${money(k.this_month_receipts)} received this month`)}
    ${kpi('Customer Receivables', money(k.outstanding), `${money(k.overdue)} overdue`)}
    ${kpi('Available Inventory', number(k.available), `${number(k.reserved)} reserved · ${number(k.total_plots)} total`)}
    ${kpi('Open CRM Leads', number(k.open_leads), 'Active opportunities requiring follow-up')}
    ${kpi('Development Progress', `${number(k.development_progress,1)}%`, `${money(k.development_actual)} actual cost`)}
    ${kpi('Development Budget', money(k.development_budget), `${money(k.development_budget-k.development_actual)} balance`)}
    ${kpi('Current Month Collection', money(k.this_month_receipts), 'Actual receipts posted in this month')}
  </div>
  <div class="dashboard-grid">
    <section class="panel"><div class="panel-head"><h3>Expected vs actual collections</h3><div class="legend"><span><i class="expected"></i>Expected</span><span><i class="actual"></i>Actual</span></div></div><div class="panel-body"><div class="bar-chart">${data.monthly_collections.map(x => `<div class="bar-group"><div class="bar-pair"><div class="bar" style="height:${Math.max(2,x.expected/max*100)}%" title="Expected ${money(x.expected)}"></div><div class="bar actual" style="height:${Math.max(2,x.actual/max*100)}%" title="Actual ${money(x.actual)}"></div></div><label>${esc(x.month)}</label></div>`).join('')}</div></div></section>
    <section class="panel"><div class="panel-head"><h3>Plot portfolio</h3><span>Current status</span></div><div class="panel-body"><div class="donut-wrap"><div class="donut" style="background:conic-gradient(#16845b 0 ${pct1}%,#d77a1f ${pct1}% ${pct2}%,#2866d8 ${pct2}% 100%)"><div class="donut-center"><b>${number(totalMix)}</b><span>Total plots</span></div></div></div><div class="mix-list">${data.plot_mix.map((x,i)=>`<div class="mix-row"><i style="background:${['#16845b','#d77a1f','#2866d8'][i]}"></i><span>${esc(x.label)}</span><b>${number(x.value)}</b></div>`).join('')}</div></div></section>
  </div>`;
  $$('[data-route]').forEach(btn => btn.addEventListener('click', () => navigate(btn.dataset.route)));
}

// ---------------- Customers ----------------
async function loadCustomers(page = 1, q = '') {
  const data = await api(sortUrl('customers', `/customers?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const canEdit = ['Admin','Finance','Sales','CRM'].includes(state.user.role);
  const columns = [
    {label:'Customer', render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.code)}</span>`},
    {label:'CNIC', key:'cnic'}, {label:'Mobile', key:'mobile'}, {label:'Email', key:'email'},
    {label:'Address', render:r=>`<span title="${esc(r.address)}">${esc((r.address||'').slice(0,35))}${(r.address||'').length>35?'…':''}</span>`},
    {label:'Status', render:r=>pill(r.status)},
    {label:'Actions', render:r=>canEdit?actionButtons([{action:'edit-customer',id:r.id,label:'Edit'},{action:'biometric-customer',id:r.id,label:'Biometric'}]):'—'}
  ];
  content.innerHTML = `${pageHead('Customer master', 'Maintain verified customer records used throughout sales, receipts and documents.', canEdit?'<button id="addCustomer" class="primary">+ Add customer</button>':'')}${renderTable({id:'customers',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadCustomers(1,v),onPage:p=>loadCustomers(p,q)})}`;
  $('#addCustomer')?.addEventListener('click', () => customerForm());
  $$('[data-action="edit-customer"]').forEach(btn => btn.addEventListener('click', () => customerForm(data.items.find(x=>x.id==btn.dataset.id))));
  $$('[data-action="biometric-customer"]').forEach(btn => btn.addEventListener('click', () => showCustomerBiometric(data.items.find(x=>x.id==btn.dataset.id))));
}
function customerForm(item={}) {
  openModal({title:item.id?'Edit customer':'Add customer',fields:[
    {name:'name',label:'Customer name',required:true,value:item.name},{name:'father_name',label:'Father / husband name',value:item.father_name},
    {name:'cnic',label:'CNIC',value:item.cnic,placeholder:'35202-0000000-0'},{name:'mobile',label:'Mobile',value:item.mobile},
    {name:'email',label:'Email',type:'email',value:item.email},{name:'status',label:'Status',type:'select',options:['Active','Inactive','Blocked'],value:item.status||'Active'},
    {name:'address',label:'Address',type:'textarea',full:true,value:item.address},{name:'version',label:'',type:'hidden',value:item.version||1}
  ],values:item,onSubmit:p=>api(item.id?`/customers/${item.id}`:'/customers',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})});
}

// ---------------- Plots ----------------
async function loadPlots(page=1,q='',status='') {
  const data = await api(sortUrl('plots', `/plots?page=${page}&size=25&q=${encodeURIComponent(q)}&status=${encodeURIComponent(status)}`));
  const columns=[
    {label:'Plot',render:r=>`<strong>${esc(r.plot_no)}</strong><span class="subtext">${esc(r.chz_no||'No CHZ')}</span>`},
    {label:'Type',render:r=>`${esc(r.category)}<span class="subtext">${number(r.size_marla,2)} Marla · ${esc(r.block||'—')}</span>`},
    {label:'Status',render:r=>pill(r.status)}, {label:'Customer',render:r=>esc(r.customer_name||'—')},
    {label:'List Price',render:r=>`<span class="money">${money(r.list_price)}</span>`}, {label:'Sale Value',render:r=>`<span class="money">${money(r.sale_price)}</span>`},
    {label:'Received',render:r=>`<span class="money positive">${money(r.received)}</span>`},{label:'Outstanding',render:r=>`<span class="money ${r.outstanding>0?'negative':''}">${money(r.outstanding)}</span>`},
    {label:'Actions',render:r=>actionButtons([{action:'edit-plot',id:r.id,label:'Edit'},...(r.status==='Available'?[{action:'reserve-plot',id:r.id,label:'Reserve'}]:[])])}
  ];
  content.innerHTML=`${pageHead('Plot inventory','Edit master details directly; financial values update only through controlled transactions.','<button id="addPlot" class="secondary">+ Add plot</button><button id="reservePlot" class="primary">Reserve a plot</button>')}
  <div class="actions" style="margin-bottom:12px"><button class="secondary plot-filter" data-status="">All</button>${['Available','Reserved','Booked','Sold'].map(s=>`<button class="secondary plot-filter" data-status="${s}">${s}</button>`).join('')}</div>
  ${renderTable({id:'plots',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadPlots(1,v,status),onPage:p=>loadPlots(p,q,status)})}`;
  $('#addPlot').addEventListener('click',()=>plotForm()); $('#reservePlot').addEventListener('click',()=>reservationForm());
  $$('.plot-filter').forEach(b=>b.addEventListener('click',()=>loadPlots(1,q,b.dataset.status)));
  $$('[data-action="edit-plot"]').forEach(btn=>btn.addEventListener('click',()=>plotForm(data.items.find(x=>x.id==btn.dataset.id))));
  $$('[data-action="reserve-plot"]').forEach(btn=>btn.addEventListener('click',()=>reservationForm(Number(btn.dataset.id))));
}
function plotForm(item={}) {
  openModal({title:item.id?'Edit plot master':'Add plot',eyebrow:'PLOT MASTER',fields:[
    {name:'plot_no',label:'Plot number',required:true,value:item.plot_no,readonly:!!item.id},{name:'chz_no',label:'CHZ / file number',value:item.chz_no},
    {name:'block',label:'Block',value:item.block},{name:'category',label:'Category',type:'select',options:['Residential','Commercial'],value:item.category||'Residential'},
    {name:'size_marla',label:'Size (Marla)',type:'number',step:'0.01',required:true,value:item.size_marla},{name:'list_price',label:'Current list price',type:'number',step:'0.01',value:item.list_price,help:'This is the marketing/list price. Booked sale value cannot be edited here.'},
    {name:'remarks',label:'Remarks',type:'textarea',full:true,value:item.remarks},{name:'version',label:'',type:'hidden',value:item.version||1}
  ],values:item,onSubmit:p=>{if(item.id)delete p.plot_no;return api(item.id?`/plots/${item.id}`:'/plots',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})}});
}

async function getOptions(endpoint, valueKey='id', labelFn=x=>x.name) {
  const data=await api(`${endpoint}${endpoint.includes('?')?'&':'?'}page=1&size=100`); return (data.items||data).map(x=>({value:x[valueKey],label:labelFn(x),raw:x}));
}
async function reservationForm(plotId='') {
  setLoading(true);
  try{
    const [plots,customers]=await Promise.all([getOptions('/plots?status=Available','id',x=>`${x.plot_no} · ${x.category} · ${number(x.size_marla,2)} Marla`),getOptions('/customers','id',x=>`${x.name} · ${x.code}`)]);
    openModal({title:'Reserve plot',eyebrow:'CONTROLLED TRANSACTION',submitText:'Post reservation',fields:[
      {name:'plot_id',label:'Available plot',type:'select',required:true,options:plots,value:plotId},{name:'customer_id',label:'Customer',type:'select',required:true,options:customers},
      {name:'reservation_date',label:'Reservation date',type:'date',required:true,value:today()},{name:'expiry_date',label:'Expiry date',type:'date'},
      {name:'amount',label:'Reservation deposit',type:'number',step:'0.01',value:0,help:'No accounting entry is created when the amount is zero.'},{name:'payment_mode',label:'Payment mode',type:'select',options:['Cash','Bank','Cheque','Online','Transfer'],value:'Cash'},
      {name:'refundable',label:'Refundable deposit',type:'checkbox',value:true},{name:'reference',label:'Payment reference'},
      {name:'dealer_name',label:'Dealer / salesperson'},{name:'remarks',label:'Remarks',type:'textarea',full:true}
    ],onSubmit:p=>api('/reservations',{method:'POST',body:JSON.stringify(p)})});
  }finally{setLoading(false)}
}

// ---------------- Reservations ----------------
async function loadReservations(page=1,q='') {
  const data=await api(sortUrl('reservations', `/reservations?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const columns=[
    {label:'Reservation',render:r=>`<strong>${esc(r.reservation_no)}</strong><span class="subtext">${dateText(r.reservation_date)}</span>`},
    {label:'Plot',render:r=>`<strong>${esc(r.plot_no)}</strong>`},{label:'Customer',key:'customer_name'},{label:'Deposit',render:r=>money(r.amount)},
    {label:'Expiry',render:r=>dateText(r.expiry_date)},{label:'Mode',key:'payment_mode'},{label:'Status',render:r=>pill(r.status)},
    {label:'Actions',render:r=>r.status==='Active'?actionButtons([{action:'convert-booking',id:r.id,label:'Book'},{action:'release-reservation',id:r.id,label:'Release'}]):'—'}
  ];
  content.innerHTML=`${pageHead('Plot reservations','Reservation deposits are posted to a liability until conversion or refund.','<button id="addReservation" class="primary">+ New reservation</button>')}${renderTable({id:'reservations',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadReservations(1,v),onPage:p=>loadReservations(p,q)})}`;
  $('#addReservation').addEventListener('click',()=>reservationForm());
  $$('[data-action="release-reservation"]').forEach(btn=>btn.addEventListener('click',()=>openModal({title:'Release reservation',eyebrow:'REFUND / RELEASE',submitText:'Release',fields:[{name:'reason',label:'Reason',type:'textarea',full:true,required:true}],onSubmit:p=>api(`/reservations/${btn.dataset.id}/release`,{method:'POST',body:JSON.stringify(p)})})));
  $$('[data-action="convert-booking"]').forEach(btn=>btn.addEventListener('click',()=>bookingForm(Number(btn.dataset.id))));
}

// ---------------- Bookings ----------------
async function loadBookings(page=1,q='',sortBy=null,sortDir=null) {
  const remembered = state.tableSort.bookings || { by: 'booking_date', dir: 'desc' };
  const activeSortBy = sortBy || remembered.by || 'booking_date';
  const activeSortDir = ['asc','desc'].includes(sortDir) ? sortDir : (remembered.dir || 'desc');
  state.tableSort.bookings = { by: activeSortBy, dir: activeSortDir };
  const data=await api(`/bookings?page=${page}&size=25&q=${encodeURIComponent(q)}&sort_by=${encodeURIComponent(activeSortBy)}&sort_dir=${encodeURIComponent(activeSortDir)}`);
  const columns=[
    {label:'Booking',sortKey:'booking_no',render:r=>`<strong>${esc(r.booking_no)}</strong><span class="subtext">${dateText(r.booking_date)}</span>`},
    {label:'Plot',key:'plot_no',sortKey:'plot_no'},{label:'Customer',key:'customer_name',sortKey:'customer_name'},{label:'Plan',key:'payment_plan',sortKey:'payment_plan'},
    {label:'Gross Price',sortKey:'sale_price',render:r=>money(r.sale_price)},{label:'Discount',sortKey:'discount',render:r=>money(r.discount)},{label:'Net Sale',sortKey:'net_sale_value',render:r=>`<strong>${money(r.net_sale_value)}</strong>`},
    {label:'Dealer',sortKey:'dealer_name',render:r=>esc(r.dealer_name||'—')},{label:'Status',sortKey:'status',render:r=>pill(r.status)},
    {label:'Actions',render:r=>actionButtons([{action:'edit-booking',id:r.id,label:'Edit'},{action:'client-file',id:r.id,label:'Client file'},{action:'amend-sale',id:r.id,label:'Price'},{action:'booking-commission',id:r.id,label:'Commission'},{action:'booking-whatsapp',id:r.id,label:'WhatsApp'}])}
  ];
  content.innerHTML=`${pageHead('Sales bookings','Posted bookings automatically update inventory, receivables and installment schedules. Click any sortable column heading to order all booking records.','<button id="addBooking" class="primary">+ New booking</button>')}${renderTable({id:'bookings',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,sortBy:activeSortBy,sortDir:activeSortDir,onSearch:v=>loadBookings(1,v,activeSortBy,activeSortDir),onPage:p=>loadBookings(p,q,activeSortBy,activeSortDir),onSort:(key,dir)=>loadBookings(1,q,key,dir)})}`;
  $('#addBooking').addEventListener('click',()=>bookingForm());
  $$('[data-action="edit-booking"]').forEach(btn=>{const item=data.items.find(x=>x.id==btn.dataset.id);btn.addEventListener('click',()=>bookingEditForm(item).catch(e=>toast(e.message,'error')));});
  $$('[data-action="amend-sale"]').forEach(btn=>{const item=data.items.find(x=>x.id==btn.dataset.id);btn.addEventListener('click',()=>openModal({title:`Amend sale value · ${item.booking_no}`,eyebrow:'FINANCE APPROVAL',submitText:'Post price amendment',fields:[
    {name:'current_value',label:'Current net sale value',readonly:true,value:item.net_sale_value},{name:'new_net_value',label:'Correct net sale value',type:'number',step:'0.01',required:true,value:item.net_sale_value},
    {name:'reason',label:'Reason and approval reference',type:'textarea',full:true,required:true,help:'Creates an adjustment voucher; the posted booking voucher is not overwritten.'}
  ],onSubmit:p=>api(`/bookings/${item.id}/amend-sale`,{method:'POST',body:JSON.stringify(p)})}))});
  $$('[data-action="booking-commission"]').forEach(btn=>{const item=data.items.find(x=>x.id==btn.dataset.id);btn.addEventListener('click',()=>commissionForm(item.id));});
  $$('[data-action="booking-whatsapp"]').forEach(btn=>btn.addEventListener('click',()=>openWhatsAppMessage('booking',Number(btn.dataset.id))));
  $$('[data-action="client-file"]').forEach(btn=>btn.addEventListener('click',()=>openClientFile(Number(btn.dataset.id)).catch(e=>toast(e.message,'error'))));
}
async function openClientFile(bookingId){
  const d=await api(`/bookings/${bookingId}/client-file`), f=d.file;
  openModal({title:`Client file · ${d.booking.booking_no}`,eyebrow:'EDITABLE / PRINTABLE CLIENT DOCUMENT SET',submitText:'Save client file',fields:[
    {name:'file_no',label:'File number',readonly:true,value:f.file_no},{name:'status',label:'Status',type:'select',options:['Draft','Issued','Revised'],value:f.status},
    {name:'booking_acknowledgment',label:'Booking acknowledgment',type:'textarea',full:true,required:true,value:f.booking_acknowledgment},
    {name:'payment_acknowledgment',label:'Final / down-payment acknowledgment',type:'textarea',full:true,required:true,value:f.payment_acknowledgment},
    {name:'terms_and_conditions',label:'Terms & conditions',type:'textarea',full:true,required:true,value:f.terms_and_conditions},
    {name:'notes',label:'Internal / client-file notes',type:'textarea',full:true,value:f.notes||''},{name:'version',label:'',type:'hidden',value:f.version}
  ],onSubmit:async p=>{const r=await api(`/client-files/${f.id}`,{method:'PATCH',body:JSON.stringify(p)});window.open(r.pdf_url,'_blank','noopener');return r}});
}
async function paymentPlanOptions(){
  const data=await api('/payment-plans?page=1&size=100&sort_by=code&sort_dir=asc');
  return [
    {value:'builtin:Full Paid',label:'Built-in · Full Paid'},
    {value:'builtin:14-Month Installment',label:'Built-in · 14-Month Installment'},
    ...data.items.filter(x=>x.active).map(x=>({value:`tpl:${x.id}`,label:`${x.code} · ${x.name}${x.size_marla?` · ${x.size_marla} Marla`:''}`}))
  ];
}
function parsePlanChoice(value){
  const v=String(value||'');
  if(v.startsWith('tpl:')) return {plan_template_id:Number(v.slice(4)),payment_plan:''};
  return {plan_template_id:0,payment_plan:v.replace(/^builtin:/,'')||'Full Paid'};
}
async function bookingEditForm(item){
  const planOptions=await paymentPlanOptions();
  const currentValue=item.plan_template_id?`tpl:${item.plan_template_id}`:`builtin:${item.payment_plan}`;
  openModal({title:`Edit booking details · ${item.booking_no}`,eyebrow:'AUDIT-SAFE BOOKING EDIT',submitText:'Save booking details',fields:[
    {name:'booking_no_display',label:'Booking number',readonly:true,value:item.booking_no},{name:'plot_display',label:'Plot',readonly:true,value:item.plot_no},
    {name:'customer_display',label:'Customer',readonly:true,value:item.customer_name},{name:'booking_date',label:'Booking date',type:'date',required:true,value:item.booking_date,help:'Changing this date automatically recalculates confirmation, installment, bulk-payment and possession due dates.'},
    {name:'date_change_reason',label:'Booking date change reason / approval reference',type:'textarea',full:true,help:'Required only when the booking date is changed. The correction is saved in the Audit Trail.'},
    {name:'payment_plan_choice',label:'Payment plan',type:'select',options:planOptions,value:currentValue,required:true,help:'Uploaded plans regenerate the installment schedule and reapply all existing receipts.'},
    {name:'dealer_name',label:'Dealer / salesperson',value:item.dealer_name||'',full:true},
    {name:'gross_display',label:'Gross sale price',readonly:true,value:item.sale_price},{name:'discount_display',label:'Discount',readonly:true,value:item.discount},
    {name:'net_display',label:'Net sale value',readonly:true,value:item.net_sale_value},{name:'version',label:'',type:'hidden',value:item.version},
    {name:'control_note',label:'Booking-date control',type:'textarea',readonly:true,full:true,value:'Customer, plot and posted sale values remain locked. A booking-date correction reschedules customer dues and preserves all receipts by reallocating them to the regenerated schedule. The original posted accounting voucher date remains unchanged; use Finance reversal/repost only if the accounting posting date also requires correction.'}
  ],onSubmit:p=>{const plan=parsePlanChoice(p.payment_plan_choice);return api(`/bookings/${item.id}`,{method:'PATCH',body:JSON.stringify({...plan,booking_date:p.booking_date,date_change_reason:p.date_change_reason,dealer_name:p.dealer_name,version:p.version})})}});
}

async function bookingForm(reservationId='') {
  setLoading(true);
  try{
    const [plotsData,customers,reservationsData,planOptions]=await Promise.all([api('/plots?page=1&size=100'),getOptions('/customers','id',x=>`${x.name} · ${x.code}`),api('/reservations?page=1&size=100'),paymentPlanOptions()]);
    const validPlots=plotsData.items.filter(x=>['Available','Reserved'].includes(x.status)).map(x=>({value:x.id,label:`${x.plot_no} · ${x.status} · ${money(x.list_price)}`,raw:x}));
    const activeReservations=reservationsData.items.filter(x=>x.status==='Active').map(x=>({value:x.id,label:`${x.reservation_no} · Plot ${x.plot_no} · ${x.customer_name}`,raw:x}));
    const selected=activeReservations.find(x=>Number(x.value)===Number(reservationId));
    openModal({title:'Create sales booking',eyebrow:'POSTED SALES TRANSACTION',submitText:'Post booking',fields:[
      {name:'reservation_id',label:'Reservation (optional)',type:'select',options:[{value:'',label:'No reservation'},...activeReservations],value:reservationId},
      {name:'plot_id',label:'Plot',type:'select',required:true,options:validPlots,value:selected?.raw?.plot_id||''},
      {name:'customer_id',label:'Customer',type:'select',required:true,options:customers,value:selected?.raw?.customer_id||''},
      {name:'booking_date',label:'Booking date',type:'date',required:true,value:today()},{name:'sale_price',label:'Gross sale price',type:'number',step:'0.01',required:true},
      {name:'discount',label:'Approved discount',type:'number',step:'0.01',value:0},{name:'payment_plan_choice',label:'Payment plan',type:'select',options:planOptions,value:'builtin:14-Month Installment',help:'Choose a built-in plan or any uploaded customized plan.'},
      {name:'dealer_name',label:'Dealer / salesperson',full:true}
    ],onSubmit:p=>{const plan=parsePlanChoice(p.payment_plan_choice);delete p.payment_plan_choice;return api('/bookings',{method:'POST',body:JSON.stringify({...p,...plan})})}});
  }finally{setLoading(false)}
}


// ---------------- Payment Plan Templates ----------------
async function loadPaymentPlans(page=1,q='',sortBy=null,sortDir=null){
  const remembered=state.tableSort['payment-plans']||{by:'code',dir:'asc'}; const by=sortBy||remembered.by||'code'; const dir=sortDir||remembered.dir||'asc'; state.tableSort['payment-plans']={by,dir};
  const data=await api(`/payment-plans?page=${page}&size=25&q=${encodeURIComponent(q)}&sort_by=${encodeURIComponent(by)}&sort_dir=${encodeURIComponent(dir)}`);
  const columns=[
    {label:'Plan Code',sortKey:'code',render:r=>`<strong>${esc(r.code)}</strong><span class="subtext">${esc(r.source_filename||'Manual')}</span>`},
    {label:'Plan Name',sortKey:'name',render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.description||'')}</span>`},
    {label:'Category',key:'category',sortKey:'category'},{label:'Size Marla',sortKey:'size_marla',render:r=>r.size_marla?number(r.size_marla):'Any'},
    {label:'Schedule Lines',render:r=>number(r.line_count)},{label:'Bookings Using',render:r=>number(r.used_count)},{label:'Status',sortKey:'active',render:r=>pill(r.active?'Active':'Inactive')},
    {label:'Actions',render:r=>actionButtons([{action:'view-plan',id:r.id,label:'View'},{action:'edit-plan',id:r.id,label:'Edit'}])}
  ];
  const controls='<a class="secondary button-link" href="/api/payment-plans-template.xlsx">Download Excel Template</a><button id="uploadPaymentPlan" class="secondary">Upload Plan File</button>';
  content.innerHTML=`${pageHead('Payment plan templates','Upload one or many customized plans from the Horizon Excel template. Fixed, percentage and final-balance lines are supported.',controls)}${renderTable({id:'payment-plans',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,sortBy:by,sortDir:dir,onSearch:v=>loadPaymentPlans(1,v,by,dir),onPage:p=>loadPaymentPlans(p,q,by,dir),onSort:(k,d)=>loadPaymentPlans(1,q,k,d)})}<input id="paymentPlanFile" type="file" accept=".xlsx,.csv" class="hidden">`;
  $('#uploadPaymentPlan')?.addEventListener('click',()=>$('#paymentPlanFile')?.click());
  $('#paymentPlanFile')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;const fd=new FormData();fd.append('file',file);try{setLoading(true);const r=await api('/payment-plans/upload',{method:'POST',body:fd,rawBody:true});toast(`${r.plans} payment plan(s) imported`);await loadPaymentPlans();}catch(err){toast(err.message,'error')}finally{setLoading(false);e.target.value=''}});
  $$('[data-action="view-plan"]').forEach(btn=>btn.addEventListener('click',async()=>{try{const d=await api(`/payment-plans/${btn.dataset.id}`);openDrawer(`${d.plan.code} · ${d.plan.name}`,`<div class="notice info"><b>Schedule validation</b><br>Fixed = exact rupees, Percent = % of booking net sale, Balance = remaining amount. At booking time the schedule must equal the net sale value.</div><div class="table-wrap"><table><thead><tr><th>Due No</th><th>Due Type</th><th>Offset Months</th><th>Amount Type</th><th>Value</th><th>Remarks</th></tr></thead><tbody>${d.lines.map(x=>`<tr><td>${x.due_no}</td><td>${esc(x.due_type)}</td><td>${x.offset_months}</td><td>${esc(x.amount_type)}</td><td>${x.amount_type==='Percent'?number(x.amount_value)+'%':x.amount_type==='Balance'?'Remaining':money(x.amount_value)}</td><td>${esc(x.remarks||'')}</td></tr>`).join('')}</tbody></table></div>`,true)}catch(e){toast(e.message,'error')}}));
  $$('[data-action="edit-plan"]').forEach(btn=>{const item=data.items.find(x=>x.id==btn.dataset.id);btn.addEventListener('click',()=>openModal({title:`Edit payment plan · ${item.code}`,eyebrow:'PLAN CONTROL',fields:[{name:'name',label:'Plan name',value:item.name,required:true},{name:'category',label:'Category',type:'select',options:['All','Residential','Commercial'],value:item.category},{name:'size_marla',label:'Size Marla (0 = any)',type:'number',step:'0.01',value:item.size_marla||0},{name:'active',label:'Active for new bookings',type:'checkbox',value:item.active},{name:'description',label:'Description',type:'textarea',full:true,value:item.description||''},{name:'version',label:'',type:'hidden',value:item.version}],onSubmit:p=>api(`/payment-plans/${item.id}`,{method:'PATCH',body:JSON.stringify(p)})}))});
}

// ---------------- Plot Transfers ----------------
async function loadTransfers(page=1,q='',sortBy=null,sortDir=null){
  const remembered=state.tableSort.transfers||{by:'transfer_date',dir:'desc'};const by=sortBy||remembered.by;const dir=sortDir||remembered.dir;state.tableSort.transfers={by,dir};
  const data=await api(`/transfers?page=${page}&size=25&q=${encodeURIComponent(q)}&sort_by=${encodeURIComponent(by)}&sort_dir=${encodeURIComponent(dir)}`);
  const columns=[{label:'Transfer',sortKey:'transfer_no',render:r=>`<strong>${esc(r.transfer_no)}</strong><span class="subtext">${dateText(r.transfer_date)}</span>`},{label:'Plot',key:'plot_no',sortKey:'plot_no'},{label:'Booking',key:'booking_no',sortKey:'booking_no'},{label:'From Customer',key:'from_customer',sortKey:'from_customer'},{label:'To Customer',key:'to_customer',sortKey:'to_customer'},{label:'Dues Verified',sortKey:'dues_at_transfer',render:r=>`<strong class="money positive">${money(r.dues_at_transfer)}</strong>`},{label:'Status',sortKey:'status',render:r=>`${pill(r.status)}<span class="subtext">${r.biometric_count?`${r.biometric_count} biometric verification(s)`:'Legacy / no biometric record'}</span>`},{label:'Approved By',key:'approved_by'}];
  content.innerHTML=`${pageHead('Plot transfers','A plot cannot be transferred while any sale or installment dues remain outstanding. Historical receipts remain preserved against the original transaction.','<button id="newTransfer" class="primary">+ New Transfer</button>')}${renderTable({id:'transfers',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,sortBy:by,sortDir:dir,onSearch:v=>loadTransfers(1,v,by,dir),onPage:p=>loadTransfers(p,q,by,dir),onSort:(k,d)=>loadTransfers(1,q,k,d)})}`;
  $('#newTransfer')?.addEventListener('click',()=>plotTransferForm());
}
async function plotTransferForm(){
  setLoading(true);try{
    const [eligibility,customerData,biometricSettings]=await Promise.all([api('/transfers/eligibility'),api('/customers?page=1&size=100'),api('/biometrics/settings')]);
    const eligible=eligibility.items.filter(x=>x.eligible),blocked=eligibility.items.filter(x=>!x.eligible),customers=customerData.items.filter(x=>x.status==='Active');
    if(!eligible.length){toast('No plots are currently eligible for transfer. All remaining dues must be cleared first.','error');return;}
    const mode=eligibility.biometric_transfer_mode||biometricSettings.transfer_mode||'Both Parties'; let fromToken='',toToken='';
    const bookingOptions=eligible.map(x=>`<option value="${x.booking_id}">Plot ${esc(x.plot_no)} · ${esc(x.customer_name)} · PAID / CLEAR</option>`).join('');
    const customerOptions=customers.map(x=>`<option value="${x.id}">${esc(x.name)} · ${esc(x.code)}</option>`).join('');
    openDrawer('Transfer fully-paid plot',`<div class="notice success"><b>Transfer controls</b><br>Outstanding dues must be zero. Biometric mode: <b>${esc(mode)}</b>. No dues override is provided.</div>
      ${!biometricSettings.ready&&mode!=='Disabled'?`<div class="notice danger"><b>Biometric service not ready:</b> ${esc(biometricSettings.error||'Configure WebAuthn')}</div>`:''}
      <div class="form-grid" style="margin-top:14px"><label class="form-field"><span>Eligible plot / booking *</span><select id="trBooking">${bookingOptions}</select><small>${blocked.length} booking(s) blocked by remaining dues.</small></label><label class="form-field"><span>Transfer to customer *</span><select id="trCustomer"><option value="">Select receiving customer</option>${customerOptions}</select></label><label class="form-field"><span>Transfer date *</span><input id="trDate" type="date" value="${today()}"></label><label class="form-field full"><span>Transfer reason / approval reference *</span><textarea id="trReason" placeholder="Transfer application / approval reference"></textarea></label></div>
      <div class="biometric-transfer-grid" style="margin-top:16px"><section class="report-card"><h3>1. Current owner biometric</h3><p id="fromBioName">Select plot</p><div id="fromBioState" class="notice">Not verified</div><div class="actions"><button id="enrollFromBio" class="secondary">Enroll</button><button id="verifyFromBio" class="primary">Verify biometric</button></div></section>
      ${mode==='Both Parties'?`<section class="report-card"><h3>2. New owner biometric</h3><p id="toBioName">Select receiving customer</p><div id="toBioState" class="notice">Not verified</div><div class="actions"><button id="enrollToBio" class="secondary">Enroll</button><button id="verifyToBio" class="primary">Verify biometric</button></div></section>`:''}</div>
      <div class="notice" style="margin-top:14px"><b>System rule:</b> The final transfer rechecks the outstanding balance and validates fresh biometric tokens tied to this exact booking and customer. Verification tokens expire automatically.</div><div class="actions" style="margin-top:16px;justify-content:flex-end"><button id="completeBiometricTransfer" class="primary">Complete transfer</button></div>`,true);
    const current=()=>eligible.find(x=>String(x.booking_id)===String($('#trBooking')?.value));
    const receiving=()=>customers.find(x=>String(x.id)===String($('#trCustomer')?.value));
    const resetBio=()=>{fromToken='';toToken='';const c=current(),r=receiving();if($('#fromBioName'))$('#fromBioName').textContent=c?`${c.customer_name} · Plot ${c.plot_no}`:'Select plot';if($('#fromBioState')){$('#fromBioState').textContent=mode==='Disabled'?'Biometric disabled by Admin':'Not verified';$('#fromBioState').className='notice'}if($('#toBioName'))$('#toBioName').textContent=r?r.name:'Select receiving customer';if($('#toBioState')){$('#toBioState').textContent='Not verified';$('#toBioState').className='notice'}};
    $('#trBooking')?.addEventListener('change',resetBio);$('#trCustomer')?.addEventListener('change',resetBio);resetBio();
    const enrollSide=async side=>{const c=side==='from'?current():receiving();if(!c)throw new Error(side==='from'?'Select a plot first':'Select the receiving customer first');const customerId=side==='from'?c.customer_id:c.id;await enrollCustomerBiometric(customerId,`${side==='from'?'Outgoing':'Incoming'} owner transfer biometric`);toast('Biometric/passkey enrolled successfully')};
    $('#enrollFromBio')?.addEventListener('click',async()=>{try{setLoading(true);await enrollSide('from')}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
    $('#enrollToBio')?.addEventListener('click',async()=>{try{setLoading(true);await enrollSide('to')}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
    $('#verifyFromBio')?.addEventListener('click',async()=>{try{const c=current();if(!c)throw new Error('Select a plot first');setLoading(true);const v=await verifyCustomerBiometric(c.customer_id,c.booking_id,'plot_transfer_outgoing');fromToken=v.verification_token;$('#fromBioState').textContent=`Verified · valid ${v.expires_in_minutes} min`;$('#fromBioState').className='notice success';toast(`${v.customer} verified`)}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
    $('#verifyToBio')?.addEventListener('click',async()=>{try{const c=current(),r=receiving();if(!c||!r)throw new Error('Select the plot and receiving customer first');if(r.id===c.customer_id)throw new Error('Receiving customer must be different from current owner');setLoading(true);const v=await verifyCustomerBiometric(r.id,c.booking_id,'plot_transfer_incoming');toToken=v.verification_token;$('#toBioState').textContent=`Verified · valid ${v.expires_in_minutes} min`;$('#toBioState').className='notice success';toast(`${v.customer} verified`)}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
    $('#completeBiometricTransfer')?.addEventListener('click',async()=>{try{const c=current(),r=receiving(),reason=$('#trReason')?.value.trim();if(!c||!r)throw new Error('Select the plot and receiving customer');if(r.id===c.customer_id)throw new Error('Receiving customer must be different from current owner');if(!reason)throw new Error('Enter transfer reason / approval reference');if(mode!=='Disabled'&&!fromToken)throw new Error('Verify the current owner biometric before transfer');if(mode==='Both Parties'&&!toToken)throw new Error('Verify the new owner biometric before transfer');setLoading(true);const result=await api('/transfers',{method:'POST',body:JSON.stringify({booking_id:c.booking_id,to_customer_id:r.id,transfer_date:$('#trDate')?.value||today(),reason,from_biometric_token:fromToken,to_biometric_token:toToken})});closeDrawer();toast(`${result.transfer_no}: Plot ${result.plot_no} transferred`);await loadTransfers()}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
  }finally{setLoading(false)}
}

// ---------------- Receipts ----------------
async function loadReceipts(page=1,q='') {
  const data=await api(sortUrl('receipts', `/receipts?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const columns=[
    {label:'Receipt',render:r=>`<strong>${esc(r.receipt_no)}</strong><span class="subtext">${dateText(r.receipt_date)}</span>`},
    {label:'Booking',render:r=>`${esc(r.booking_no)}<span class="subtext">Plot ${esc(r.plot_no)}</span>`},{label:'Customer',key:'customer_name'},
    {label:'Amount',render:r=>`<strong class="money positive">${money(r.amount)}</strong>`},{label:'Mode',key:'mode'},{label:'Reference',key:'reference'},{label:'Narration',render:r=>esc((r.narration||'').slice(0,45))}
  ];
  content.innerHTML=`${pageHead('Customer receipts','Every posted receipt updates cash/bank, customer receivable, plot balance and installments.','<button id="addReceipt" class="primary">+ Post receipt</button>')}${renderTable({id:'receipts',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadReceipts(1,v),onPage:p=>loadReceipts(p,q)})}`;
  $('#addReceipt').addEventListener('click',()=>receiptForm());
}
async function receiptForm(){
  setLoading(true);try{
    const data=await api('/bookings?page=1&size=100');
    const options=data.items.filter(x=>x.status==='Posted').map(x=>({value:x.id,label:`${x.booking_no} · Plot ${x.plot_no} · ${x.customer_name} · ${money(x.net_sale_value)}`}));
    openModal({title:'Post customer receipt',eyebrow:'COLLECTION TRANSACTION',submitText:'Post receipt',fields:[
      {name:'booking_id',label:'Booking',type:'select',required:true,options},{name:'receipt_date',label:'Receipt date',type:'date',required:true,value:today()},
      {name:'amount',label:'Amount received',type:'number',step:'0.01',required:true},{name:'mode',label:'Payment mode',type:'select',options:['Cash','Bank','Cheque','Online','Transfer'],value:'Cash'},
      {name:'reference',label:'Bank / cheque reference'},{name:'narration',label:'Narration',type:'textarea',full:true}
    ],onSubmit:p=>api('/receipts',{method:'POST',body:JSON.stringify(p)})});
  }finally{setLoading(false)}
}

// ---------------- Installments ----------------
async function loadInstallments(page=1,q='') {
  const [data,forecast,aging]=await Promise.all([api(sortUrl('installments', `/installments?page=${page}&size=25&q=${encodeURIComponent(q)}`)),api('/forecast'),api('/receivables/overview')]);
  const columns=[
    {label:'Due Date',render:r=>dateText(r.due_date)},{label:'Booking / Plot',render:r=>`<strong>${esc(r.booking_no)}</strong><span class="subtext">Plot ${esc(r.plot_no)}</span>`},
    {label:'Customer',key:'customer_name'},{label:'Type',key:'due_type'},{label:'Due',render:r=>money(r.amount)},{label:'Paid',render:r=>money(r.paid)},
    {label:'Balance',render:r=>`<strong class="${r.balance>0?'negative':'positive'}">${money(r.balance)}</strong>`},{label:'Status',render:r=>pill(r.status)},
    {label:'Actions',render:r=>r.balance>0?actionButtons([{action:'due-whatsapp',id:r.id,label:'WhatsApp'}]):'—'}
  ];
  const max=Math.max(1,...forecast.items.map(x=>Math.max(x.expected,x.actual)));
  content.innerHTML=`${pageHead('Installments and collection forecast','Expected amounts are cash collection forecasts, not accounting revenue.','<button id="openReceivables" class="primary">Receivables & Aging</button><button id="printForecast" class="secondary">Print report</button>')}
  <div class="kpi-grid">${kpi(`Due through ${aging.month_label}`,money(aging.summary.due_through_current_month),'All unpaid scheduled dues through current month')}${kpi('Overdue as of today',money(aging.summary.overdue_as_of_date),`${aging.summary.overdue_plots} plots with overdue amounts`,aging.summary.overdue_as_of_date>0)}${kpi('Booking overdue',money(aging.summary.booking_overdue),'Booking / down-payment balance')}${kpi('Confirmation overdue',money(aging.summary.confirmation_overdue),'Confirmation balance')}</div>
  <section class="panel" style="margin-bottom:16px"><div class="panel-head"><h3>Next 12 months expected vs actual</h3><div class="legend"><span><i class="expected"></i>Expected</span><span><i class="actual"></i>Actual</span></div></div><div class="panel-body"><div class="bar-chart">${forecast.items.map(x=>`<div class="bar-group"><div class="bar-pair"><div class="bar" style="height:${Math.max(2,x.expected/max*100)}%" title="${money(x.expected)}"></div><div class="bar actual" style="height:${Math.max(2,x.actual/max*100)}%" title="${money(x.actual)}"></div></div><label>${esc(x.month)}</label></div>`).join('')}</div></div></section>
  ${renderTable({id:'installments',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadInstallments(1,v),onPage:p=>loadInstallments(p,q)})}`;
  $('#printForecast').addEventListener('click',()=>window.print());
  $('#openReceivables')?.addEventListener('click',()=>navigate('receivables'));
  $$('[data-action="due-whatsapp"]').forEach(btn=>btn.addEventListener('click',()=>openWhatsAppMessage('due',Number(btn.dataset.id))));
}


function addMonthsIso(months){
  const d=new Date(); d.setHours(12,0,0,0); d.setMonth(d.getMonth()+months); return d.toISOString().slice(0,10);
}

function simpleReceivableTable(columns,items){
  const rows=items.length?items.map(r=>`<tr>${columns.map(c=>`<td>${c.render?c.render(r):esc(r[c.key])}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${columns.length}"><div class="empty-state"><b>No receivables found</b><span>Change the date range or filter.</span></div></td></tr>`;
  return `<div class="table-panel"><div class="table-toolbar"><div class="table-meta">${number(items.length)} rows · Click any heading to sort</div></div><div class="table-wrap"><table><thead><tr>${columns.map(c=>`<th>${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div></div>`;
}
function receivableForecastColumns(groupBy){
  if(groupBy==='plot') return [
    {label:'Plot',key:'plot_no',sortKey:'plot_no'},{label:'Booking',key:'booking_no',sortKey:'booking_no'},{label:'Customer',key:'customer_name',sortKey:'customer_name'},
    {label:'Booking Due',render:r=>money(r.booking_due),sortKey:'booking_due'},{label:'Confirmation',render:r=>money(r.confirmation_due),sortKey:'confirmation_due'},
    {label:'Monthly',render:r=>money(r.monthly_due),sortKey:'monthly_due'},{label:'Other',render:r=>money(r.other_due),sortKey:'other_due'},
    {label:'Forecast Receivable',render:r=>`<strong>${money(r.receivable)}</strong>`,sortKey:'receivable'},{label:'Items',key:'installments',sortKey:'installments'}
  ];
  return [
    {label:groupBy==='year'?'Year':'Month',key:'label',sortKey:'key'},{label:'Forecast Receivable',render:r=>`<strong>${money(r.receivable)}</strong>`,sortKey:'receivable'},
    {label:'Plots',key:'plots',sortKey:'plots'},{label:'Items',key:'installments',sortKey:'installments'},
    {label:'Booking Due',render:r=>money(r.booking_due),sortKey:'booking_due'},{label:'Confirmation',render:r=>money(r.confirmation_due),sortKey:'confirmation_due'},
    {label:'Monthly',render:r=>money(r.monthly_due),sortKey:'monthly_due'},{label:'Other',render:r=>money(r.other_due),sortKey:'other_due'}
  ];
}
async function loadReceivables(){
  const overview=await api('/receivables/overview');
  const defaultFrom=today(), defaultTo=addMonthsIso(12);
  const overdueColumns=[
    {label:'Plot',key:'plot_no',sortKey:'plot_no'},{label:'Booking',key:'booking_no',sortKey:'booking_no'},{label:'Customer',key:'customer_name',sortKey:'customer_name'},
    {label:'Booking Overdue',render:r=>money(r.booking_overdue),sortKey:'booking_overdue'},{label:'Confirmation Overdue',render:r=>money(r.confirmation_overdue),sortKey:'confirmation_overdue'},
    {label:'Installment Overdue',render:r=>money(r.installment_overdue),sortKey:'installment_overdue'},{label:'Other Overdue',render:r=>money(r.other_overdue),sortKey:'other_overdue'},
    {label:'Total Overdue',render:r=>`<strong class="${r.total_overdue>0?'negative':''}">${money(r.total_overdue)}</strong>`,sortKey:'total_overdue'},
    {label:`Due Through ${overview.month_label}`,render:r=>money(r.due_through_month),sortKey:'due_through_month'},{label:'Total Outstanding',render:r=>money(r.total_outstanding),sortKey:'total_outstanding'}
  ];
  const overdueItems=overview.plots.filter(x=>x.total_outstanding>0);
  content.innerHTML=`${pageHead('Receivables & aging','Check overdue amounts through the current month and forecast future receivables by date, plot, month or year.','<button id="printReceivables" class="secondary">Print</button>')}
  <div class="kpi-grid">${kpi(`Due through ${overview.month_label}`,money(overview.summary.due_through_current_month),`Cut-off: ${dateText(overview.month_end)}`,true)}${kpi('Overdue as of today',money(overview.summary.overdue_as_of_date),`${overview.summary.overdue_plots} plots overdue`,overview.summary.overdue_as_of_date>0)}${kpi('Booking overdue',money(overview.summary.booking_overdue),'Booking / down payment')}${kpi('Confirmation overdue',money(overview.summary.confirmation_overdue),'Confirmation dues')}${kpi('Current month due',money(overview.summary.current_month_due),overview.month_label)}${kpi('Total outstanding',money(overview.summary.total_outstanding),'All remaining scheduled receivables')}</div>
  <section class="panel" style="margin-bottom:16px"><div class="panel-head"><div><h3>Future receivable forecast</h3><p>Enter any future date range and group the scheduled unpaid amount by month, year or plot.</p></div></div><div class="panel-body">
    <div class="filter-bar"><label>From<input id="rfFrom" type="date" value="${defaultFrom}"></label><label>To<input id="rfTo" type="date" value="${defaultTo}"></label>
    <label>View By<select id="rfGroup"><option value="month">By Month</option><option value="year">By Year</option><option value="plot">By Plot</option></select></label>
    <label>Due Type<select id="rfCategory"><option>All</option><option>Booking / Down Payment</option><option>Confirmation</option><option>Monthly Installment</option><option>Bulk Payment</option><option>Possession</option><option>Full Payment</option><option>Other</option></select></label>
    <button id="runReceivableForecast" class="primary">Run Forecast</button><button id="exportReceivableCsv" class="secondary">Export CSV</button></div>
    <div id="receivableForecastOutput"><div class="empty-state"><b>Loading forecast…</b></div></div>
  </div></section>
  <section class="panel" style="margin-bottom:12px"><div class="panel-head"><div><h3>Plot-wise overdue & outstanding</h3><p>Booking, confirmation, installment and other overdue balances are separated for collection follow-up.</p></div><span>${number(overdueItems.length)} plots</span></div></section>
  ${simpleReceivableTable(overdueColumns,overdueItems)}`;
  const run=async()=>{
    try{
      setLoading(true);
      const from=$('#rfFrom').value,to=$('#rfTo').value,group=$('#rfGroup').value,category=$('#rfCategory').value;
      if(!from||!to) throw new Error('Enter both From and To dates');
      const q=new URLSearchParams({from_date:from,to_date:to,group_by:group,category});
      const r=await api(`/receivables/report?${q.toString()}`);
      const cols=receivableForecastColumns(group);
      $('#receivableForecastOutput').innerHTML=`<div class="kpi-grid" style="margin-top:14px">${kpi('Forecast Receivable',money(r.summary.receivable),`${dateText(r.from_date)} to ${dateText(r.to_date)}`,true)}${kpi('Scheduled Items',number(r.summary.installments),'Unpaid schedule lines')}${kpi('Plots',number(r.summary.plots),'Plots included')}</div>${simpleReceivableTable(cols,r.items)}`;
      decorateDomTables($('#receivableForecastOutput'));
    }catch(e){toast(e.message,'error')}finally{setLoading(false)}
  };
  $('#runReceivableForecast').addEventListener('click',run);
  $('#exportReceivableCsv').addEventListener('click',()=>{
    const q=new URLSearchParams({from_date:$('#rfFrom').value,to_date:$('#rfTo').value,group_by:$('#rfGroup').value,category:$('#rfCategory').value});
    window.location=`/api/receivables/export.csv?${q.toString()}`;
  });
  $('#printReceivables').addEventListener('click',()=>window.print());
  await run();
}

async function openWhatsAppMessage(kind,id){
  try{
    const preview=await api(kind==='booking'?`/whatsapp/bookings/${id}/preview`:`/whatsapp/installments/${id}/preview`);
    openDrawer(kind==='booking'?'Booking WhatsApp notification':'Payment due WhatsApp notification',`
      <div class="notice"><b>Customer:</b> ${esc(preview.customer)} · <b>Mobile:</b> ${esc(preview.mobile||'Not available')}</div>
      <div class="panel" style="margin-top:12px"><div class="panel-head"><h3>Message preview</h3><span>${preview.api_enabled?'API enabled':'API not enabled'}</span></div><div class="panel-body"><pre class="message-preview">${esc(preview.message)}</pre></div></div>
      <div class="actions" style="margin-top:14px"><button id="sendWhatsappApi" class="primary" ${preview.api_enabled?'':'disabled'}>Send through WhatsApp API</button><button id="openWhatsappWeb" class="secondary">Open in WhatsApp</button></div>
      ${preview.api_enabled?'':'<div class="notice" style="margin-top:12px">Configure Meta WhatsApp Cloud API from WhatsApp Notifications → Configure API. The Open in WhatsApp button works as a manual fallback.</div>'}`);
    $('#openWhatsappWeb')?.addEventListener('click',()=>window.open(preview.wa_link,'_blank','noopener'));
    $('#sendWhatsappApi')?.addEventListener('click',async()=>{if(!confirm('Send this customer notification through the configured WhatsApp Business API?'))return;try{setLoading(true);const r=await api(kind==='booking'?`/whatsapp/bookings/${id}/send`:`/whatsapp/installments/${id}/send`,{method:'POST',body:'{}'});toast(`WhatsApp ${r.status}`);closeDrawer();}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
  }catch(e){toast(e.message,'error')}
}

// ---------------- WhatsApp Notifications ----------------
async function loadWhatsApp(page=1,q=''){
  const [cfg,logs]=await Promise.all([api('/whatsapp/settings'),api(sortUrl('whatsappLogs',`/whatsapp/logs?page=${page}&size=25&q=${encodeURIComponent(q)}`))]);
  const canConfigure=['Admin','Finance'].includes(state.user.role);
  const columns=[
    {label:'Date / Time',render:r=>r.created_at?new Date(r.created_at).toLocaleString():'—'},
    {label:'Type',key:'message_type'},{label:'Mobile',key:'mobile'},{label:'Template',key:'template_name'},
    {label:'Booking',render:r=>r.booking_id?`#${r.booking_id}`:'—'},{label:'Installment',render:r=>r.installment_id?`#${r.installment_id}`:'—'},
    {label:'Status',render:r=>pill(r.status)},{label:'Sent By',key:'sent_by'},
    {label:'Details',render:r=>r.error_message?`<span class="negative" title="${esc(r.error_message)}">${esc(r.error_message.slice(0,45))}${r.error_message.length>45?'…':''}</span>`:esc(r.provider_message_id||'—')}
  ];
  const actions=`${canConfigure?'<button id="configureWhatsapp" class="primary">Configure API</button>':''}<button id="testWhatsapp" class="secondary" ${canConfigure?'':'disabled'}>Test API</button><button id="bulkDueWhatsapp" class="secondary">Send due reminders</button>`;
  content.innerHTML=`${pageHead('WhatsApp notifications','Send controlled booking confirmations and installment due reminders through Meta WhatsApp Cloud API.',actions)}
    <div class="kpi-grid">${kpi('API Status',cfg.enabled?'Enabled':'Disabled',cfg.enabled?'Customer API sending is active':'Manual WhatsApp fallback remains available',cfg.enabled)}${kpi('Phone Number ID',cfg.phone_number_id||'Not configured',cfg.phone_id_source||'')}${kpi('Access Token',cfg.token_configured?'Configured':'Missing',cfg.token_source||'')}${kpi('Auto Booking',cfg.auto_booking?'On':'Off','Automatic booking confirmation')}</div>
    <div class="notice" style="margin-bottom:16px"><b>Meta template parameters:</b> Booking template = Customer, Booking No., Plot No., Sale Value, Received, Outstanding. Due template = Customer, Plot No., Due Type, Due Date, Due Amount, Total Outstanding. Templates must be approved in WhatsApp Manager with the same parameter order.</div>
    ${renderTable({id:'whatsappLogs',columns,items:logs.items,total:logs.total,page:logs.page,size:logs.size,query:q,onSearch:v=>loadWhatsApp(1,v),onPage:p=>loadWhatsApp(p,q)})}`;
  $('#configureWhatsapp')?.addEventListener('click',()=>whatsappConfigForm(cfg));
  $('#testWhatsapp')?.addEventListener('click',()=>whatsappTestForm());
  $('#bulkDueWhatsapp')?.addEventListener('click',()=>whatsappBulkDueForm());
}
function whatsappConfigForm(cfg){
  openModal({title:'WhatsApp Business API configuration',eyebrow:'META CLOUD API',submitText:'Save integration',fields:[
    {name:'enabled',label:'Enable WhatsApp API',type:'checkbox',value:cfg.enabled},{name:'auto_booking',label:'Automatically send booking confirmation after a new booking',type:'checkbox',value:cfg.auto_booking},
    {name:'api_version',label:'Graph API version',value:cfg.api_version||'v23.0',required:true},{name:'phone_number_id',label:'WhatsApp Phone Number ID',value:cfg.phone_number_id||'',required:true},
    {name:'access_token',label:'Access token',type:'password',help:`${cfg.token_configured?'A token is already configured. Leave blank to keep it.':'Paste the permanent/system-user access token. For production, WHATSAPP_ACCESS_TOKEN environment variable is preferred.'}`},
    {name:'default_country_code',label:'Default country code',value:cfg.default_country_code||'92',help:'Pakistan = 92. Customer mobile numbers beginning with 0 are converted automatically.'},
    {name:'language_code',label:'Template language code',value:cfg.language_code||'en_US'},{name:'booking_template',label:'Approved booking template name',value:cfg.booking_template||'horizon_booking_confirmation',required:true},
    {name:'due_template',label:'Approved due reminder template name',value:cfg.due_template||'horizon_payment_due',required:true}
  ],values:cfg,onSubmit:p=>api('/whatsapp/settings',{method:'POST',body:JSON.stringify(p)})});
}
function whatsappTestForm(){
  openModal({title:'Test WhatsApp API',eyebrow:'LIVE API TEST',submitText:'Send test template',fields:[
    {name:'mobile',label:'Test mobile number',required:true,placeholder:'+923001234567'},{name:'template_type',label:'Template',type:'select',options:['Booking','Due'],value:'Booking'}
  ],onSubmit:p=>api('/whatsapp/test',{method:'POST',body:JSON.stringify(p)})});
}
function whatsappBulkDueForm(){
  openModal({title:'Send installment due reminders',eyebrow:'BULK WHATSAPP CONTROL',submitText:'Send reminders',fields:[
    {name:'days_ahead',label:'Include dues up to (days ahead)',type:'number',min:0,max:60,value:0,help:'0 = due today and overdue. Use e.g. 3 to include dues in the next three days.'},
    {name:'max_messages',label:'Maximum messages in this batch',type:'number',min:1,max:100,value:50},{name:'force',label:'Allow resend even if a reminder was sent within the last 20 hours',type:'checkbox',value:false}
  ],onSubmit:async p=>{const r=await api('/whatsapp/due-reminders/send',{method:'POST',body:JSON.stringify(p)});toast(`${r.sent.length} sent · ${r.failed.length} failed · ${r.skipped.length} skipped`);return r;}});
}


// ---------------- Horizon Homes Project Overview ----------------
function areaDisplay(totalMarla, digits=2) {
  const total=Number(totalMarla||0);
  const kanal=Math.floor(total/20 + 1e-9);
  const marla=total-(kanal*20);
  return `${kanal} K ${number(marla,digits)} M`;
}
function areaKanal(totalMarla, digits=3) { return `${number(Number(totalMarla||0)/20,digits)} K`; }
function boundarySvg(coords) {
  const pts=(coords||[]).map(p=>[Number(p[0]),Number(p[1])]).filter(p=>Number.isFinite(p[0])&&Number.isFinite(p[1]));
  if(pts.length<3) return `<div class="empty-state">No boundary geometry is available.</div>`;
  const minLon=Math.min(...pts.map(p=>p[0])), maxLon=Math.max(...pts.map(p=>p[0]));
  const minLat=Math.min(...pts.map(p=>p[1])), maxLat=Math.max(...pts.map(p=>p[1]));
  const width=860,height=430,pad=34;
  const dx=Math.max(maxLon-minLon,1e-9),dy=Math.max(maxLat-minLat,1e-9);
  const scale=Math.min((width-pad*2)/dx,(height-pad*2)/dy);
  const project=([lon,lat])=>[pad+(lon-minLon)*scale, height-pad-(lat-minLat)*scale];
  const path=pts.map((p,i)=>`${i?'L':'M'} ${project(p)[0].toFixed(1)} ${project(p)[1].toFixed(1)}`).join(' ')+' Z';
  const vertices=pts.map((p,i)=>{const [x,y]=project(p);return `<g><circle class="boundary-dot" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5"></circle><text class="boundary-label" x="${(x+8).toFixed(1)}" y="${(y-8).toFixed(1)}">${i+1}</text></g>`}).join('');
  return `<svg class="boundary-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Horizon Homes KMZ project boundary"><rect class="boundary-bg" x="1" y="1" width="${width-2}" height="${height-2}" rx="18"></rect><path class="boundary-shape" d="${path}"></path>${vertices}<text class="boundary-north" x="${width-70}" y="48">N ↑</text></svg>`;
}
function coordinatesText(coords){return (coords||[]).map(p=>`${Number(p[0]).toFixed(12)}, ${Number(p[1]).toFixed(12)}`).join('\n')}
function parseCoordinatesText(text){
  const rows=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  const points=rows.map((row,i)=>{const parts=row.split(/[\s,]+/).filter(Boolean);if(parts.length<2)throw new Error(`Boundary line ${i+1} must contain longitude and latitude`);const lon=Number(parts[0]),lat=Number(parts[1]);if(!Number.isFinite(lon)||!Number.isFinite(lat))throw new Error(`Boundary line ${i+1} contains an invalid coordinate`);return [lon,lat]});
  if(points.length<3) throw new Error('At least three boundary points are required');
  return points;
}
function projectCheckCard(check){
  const cls=String(check.level||'Info').toLowerCase()==='review'?'warning':'info';
  return `<div class="project-check ${cls}"><b>${esc(check.title)}</b><span>${esc(check.detail)}</span></div>`;
}
async function loadProjectOverview(){
  const d=await api('/project-overview');
  const p=d.project,k=d.kpis;
  const status=k.plot_status||{}, cat=k.plot_category||{};
  const areaDiff=Number(p.kmz_source_area_marla||0)-Number(p.legal_area_marla||0);
  const actions=`<button id="editProjectAreas" class="primary">Edit project / areas</button><button id="editProjectBoundary" class="secondary">Edit boundary</button><button id="importProjectKmz" class="secondary">Import KMZ</button><input id="projectKmzInput" type="file" accept=".kmz,application/vnd.google-earth.kmz" class="hidden"><button id="resetProjectBoundary" class="secondary">Reset source KMZ</button>`;
  content.innerHTML=`${pageHead('Horizon Homes project overview','Source-controlled project profile built from the deed, final submission layout and KMZ boundary. Editable ERP areas remain separate from source/legal values.',actions)}
    <div class="project-source-banner"><div><b>Source-controlled area</b><span>Deed: ${areaDisplay(p.legal_area_marla)} · Layout: ${areaDisplay(p.layout_area_marla)} · Original KMZ: ${areaKanal(p.kmz_source_area_marla)} · ERP controlled: ${areaDisplay(p.official_area_marla)}</span></div><span class="status-pill status-active">${esc(p.status)}</span></div>
    <div class="kpi-grid project-kpis">
      ${kpi('ERP Controlled Area',areaDisplay(p.official_area_marla),'Editable with reason / audit trail',true)}
      ${kpi('Original KMZ Area',areaKanal(p.kmz_source_area_marla),`${number(p.kmz_source_area_sqm,0)} m² · ${areaDiff>=0?'+':''}${number(areaDiff,2)} marla vs deed`)}
      ${kpi('Total Plot Inventory',number(k.plots_total),`${number(cat.Residential||0)} residential · ${number(cat.Commercial||0)} commercial`)}
      ${kpi('Booked / Available',`${number(status.Booked||0)} / ${number(status.Available||0)}`,`${number(status.Reserved||0)} reserved`)}
      ${kpi('Net Sales',money(k.total_sales),'Posted / active bookings')}
      ${kpi('Collections',money(k.total_collections),`Outstanding ${money(k.total_outstanding)}`)}
      ${kpi('Recorded Land Cost',money(k.land_recorded_cost),`Against deed consideration ${money(p.land_consideration)}`)}
      ${kpi('Development Progress',`${number(k.development_progress,1)}%`,`Actual ${money(k.development_actual)} · Budget ${money(k.development_budget)}`)}
    </div>
    <div class="project-two-col">
      <section class="report-card project-map-card">
        <div class="section-title-row"><div><div class="eyebrow">KMZ BOUNDARY</div><h3>Project boundary</h3><p>Current editable ERP boundary. Original KMZ geometry is retained separately for reset and audit comparison.</p></div><div class="boundary-area-box"><small>Current measured area</small><b>${areaKanal(p.kmz_current_area_marla)}</b><span>${number(p.kmz_current_area_sqm,0)} m²</span></div></div>
        ${boundarySvg(p.boundary)}
        <div class="map-meta"><span><b>${p.boundary.length}</b> vertices</span><span><b>${number(p.marla_sqft,0)}</b> sq ft / marla standard</span><span><b>${number(Math.abs(Number(p.kmz_current_area_marla)-Number(p.official_area_marla)),2)}</b> marla boundary-to-ERP difference</span></div>
      </section>
      <section class="report-card project-plan-card">
        <div class="section-title-row"><div><div class="eyebrow">FINAL SUBMISSION</div><h3>Layout plan</h3><p>Planning reference supplied in the uploaded final submission.</p></div><div class="actions"><button id="openLayoutPdf" class="secondary">Open PDF</button></div></div>
        <a href="/api/project-overview/source/layout" target="_blank" rel="noopener"><img class="layout-plan-preview" src="/api/project-overview/source/layout-preview" alt="Horizon Homes final submission layout plan"></a>
      </section>
    </div>
    <div class="project-two-col">
      <section class="report-card"><div class="eyebrow">PLANNING AREA</div><h3>Land-use distribution</h3>
        <div class="landuse-grid">
          <div><span>Residential</span><b>${areaKanal(p.residential_area_marla,2)}</b><small>${number((p.residential_area_marla/p.layout_area_marla)*100,2)}%</small></div>
          <div><span>Commercial</span><b>${areaKanal(p.commercial_area_marla,2)}</b><small>${number((p.commercial_area_marla/p.layout_area_marla)*100,2)}%</small></div>
          <div><span>Public Building (Sponsor)</span><b>${areaKanal(p.public_building_area_marla,2)}</b><small>${number((p.public_building_area_marla/p.layout_area_marla)*100,2)}%</small></div>
          <div><span>Roads & Parking</span><b>${areaKanal(p.roads_parking_area_marla,2)}</b><small>${number((p.roads_parking_area_marla/p.layout_area_marla)*100,2)}%</small></div>
        </div>
        <div class="project-total-line"><span>Planning total</span><b>${areaKanal(p.residential_area_marla+p.commercial_area_marla+p.public_building_area_marla+p.roads_parking_area_marla,2)}</b><span>Layout total ${areaKanal(p.layout_area_marla,2)}</span></div>
      </section>
      <section class="report-card"><div class="eyebrow">LAND AGREEMENT</div><h3>Legal & commercial summary</h3>
        <dl class="project-detail-list">
          <div><dt>Developer</dt><dd>${esc(p.developer)}</dd></div><div><dt>Mouza</dt><dd>${esc(p.mouza)}</dd></div>
          <div><dt>Khasra Nos.</dt><dd>${esc(p.khasra_numbers)}</dd></div><div><dt>Khewat Nos.</dt><dd>${esc(p.khewat_numbers)}</dd></div>
          <div><dt>Khatooni Nos.</dt><dd>${esc(p.khatooni_numbers)}</dd></div><div><dt>Land rate</dt><dd>${money(p.land_rate_per_marla)} / marla</dd></div>
          <div><dt>Agreed consideration</dt><dd>${money(p.land_consideration)}</dd></div><div><dt>Profit share</dt><dd>${number(p.landowner_profit_share,0)}% landowners · ${number(p.developer_profit_share,0)}% developer</dd></div>
          <div class="wide"><dt>Landowners</dt><dd>${p.landowners.map(esc).join(', ')}</dd></div>
          <div class="wide"><dt>Deed location</dt><dd>${esc(p.deed_location)}</dd></div><div class="wide"><dt>Layout location</dt><dd>${esc(p.layout_location)}</dd></div>
        </dl>
      </section>
    </div>
    <section class="report-card"><div class="section-title-row"><div><div class="eyebrow">SOURCE CHECKS</div><h3>Verification queue</h3></div></div><div class="project-checks">${(d.checks||[]).map(projectCheckCard).join('')||'<div class="notice">No source differences are currently flagged.</div>'}</div></section>
    <section class="report-card"><div class="section-title-row"><div><div class="eyebrow">SOURCE DOCUMENTS</div><h3>Project source pack</h3></div></div>
      <div class="source-doc-grid">${(d.sources||[]).map(x=>`<a class="source-doc" href="/api/project-overview/source/${encodeURIComponent(x.key)}" ${x.key==='layout'?'target="_blank"':''}><b>${esc(x.name)}</b><span>${esc(x.note)}</span><small>${esc(x.type)}</small></a>`).join('')}</div>
    </section>
    <section class="report-card"><div class="eyebrow">CHANGE HISTORY</div><h3>Area & boundary revisions</h3>${d.revisions?.length?`<div class="table-wrap"><table><thead><tr><th>Date</th><th>Change</th><th>User</th><th>Old ERP Area</th><th>New ERP Area</th><th>Reason</th></tr></thead><tbody>${d.revisions.map(r=>`<tr><td>${esc(r.changed_at?new Date(r.changed_at).toLocaleString('en-GB'):'—')}</td><td>${esc(r.change_type)}</td><td>${esc(r.changed_by)}</td><td>${areaDisplay(r.old_official_area_marla)}</td><td>${areaDisplay(r.new_official_area_marla)}</td><td>${esc(r.reason)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">No project-area revisions yet.</div>'}</section>`;

  $('#openLayoutPdf')?.addEventListener('click',()=>window.open('/api/project-overview/source/layout','_blank','noopener'));
  $('#editProjectAreas')?.addEventListener('click',()=>openProjectAreaEditor(p));
  $('#editProjectBoundary')?.addEventListener('click',()=>openProjectBoundaryEditor(p));
  $('#resetProjectBoundary')?.addEventListener('click',async()=>{if(!confirm('Reset the current editable boundary to the original uploaded KMZ polygon? The revision will be logged.'))return;try{setLoading(true);await api('/project-overview/boundary/reset',{method:'POST',body:JSON.stringify({reason:'Reset current boundary to original source KMZ',update_official_area:false})});toast('Boundary reset to original source KMZ');await loadProjectOverview()}catch(e){toast(e.message,'error')}finally{setLoading(false)}});
  $('#importProjectKmz')?.addEventListener('click',()=>$('#projectKmzInput')?.click());
  $('#projectKmzInput')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;if(!confirm(`Import ${file.name} as the current project boundary? The original KMZ remains retained for audit.`)){e.target.value='';return}const fd=new FormData();fd.append('file',file);try{setLoading(true);const res=await fetch('/api/project-overview/kmz',{method:'POST',credentials:'same-origin',headers:{'X-CSRF-Token':state.csrf},body:fd});const data=await res.json();if(!res.ok)throw new Error(data.detail||'KMZ import failed');toast('KMZ imported and boundary recalculated');await loadProjectOverview()}catch(err){toast(err.message,'error')}finally{setLoading(false);e.target.value=''}});
}
function openProjectAreaEditor(p){
  const rem=v=>Number(v||0)%20, kan=v=>Math.floor(Number(v||0)/20);
  openModal({title:'Edit project area & planning controls',eyebrow:'AUDIT-CONTROLLED PROJECT MASTER',submitText:'Save project update',fields:[
    {name:'official_kanal',label:'ERP controlled area - Kanal',type:'number',step:'1',min:0,value:kan(p.official_area_marla),required:true},{name:'official_marla',label:'ERP controlled area - Marla',type:'number',step:'0.01',min:0,max:19.99,value:number(rem(p.official_area_marla),2),required:true},
    {name:'marla_sqft',label:'Area standard - sq ft per marla',type:'number',step:'0.01',min:1,value:p.marla_sqft,required:true,help:'The supplied final-submission layout states 1 Marla = 225 sq ft. Changing this recalculates measured KMZ marlas; the original coordinates remain unchanged.'},
    {name:'residential_kanal',label:'Residential area - Kanal',type:'number',step:'0.01',min:0,value:number(p.residential_area_marla/20,2)},{name:'commercial_kanal',label:'Commercial area - Kanal',type:'number',step:'0.01',min:0,value:number(p.commercial_area_marla/20,2)},
    {name:'public_kanal',label:'Public building (Sponsor) area - Kanal',type:'number',step:'0.01',min:0,value:number(p.public_building_area_marla/20,2)},{name:'roads_kanal',label:'Roads & parking area - Kanal',type:'number',step:'0.01',min:0,value:number(p.roads_parking_area_marla/20,2)},
    {name:'land_rate_per_marla',label:'Land rate per marla',type:'number',step:'1',min:0,value:p.land_rate_per_marla},{name:'land_consideration',label:'Land consideration',type:'number',step:'1',min:0,value:p.land_consideration},
    {name:'landowner_profit_share',label:'Landowner profit share %',type:'number',step:'0.01',min:0,max:100,value:p.landowner_profit_share},{name:'developer_profit_share',label:'Developer profit share %',type:'number',step:'0.01',min:0,max:100,value:p.developer_profit_share},
    {name:'status',label:'Project status',type:'select',options:['Active','Planning','Development','On Hold','Completed'],value:p.status},{name:'notes',label:'Management notes',type:'textarea',full:true,value:p.notes},
    {name:'reason',label:'Reason / approval reference',type:'textarea',full:true,required:true,placeholder:'Explain why the ERP-controlled area or project master is being changed.'},{name:'version',label:'',type:'hidden',value:p.version}
  ],onSubmit:x=>api('/project-overview',{method:'PATCH',body:JSON.stringify({
    official_area_marla:Number(x.official_kanal||0)*20+Number(x.official_marla||0),marla_sqft:Number(x.marla_sqft||225),
    residential_area_marla:Number(x.residential_kanal||0)*20,commercial_area_marla:Number(x.commercial_kanal||0)*20,public_building_area_marla:Number(x.public_kanal||0)*20,roads_parking_area_marla:Number(x.roads_kanal||0)*20,
    land_rate_per_marla:Number(x.land_rate_per_marla||0),land_consideration:Number(x.land_consideration||0),landowner_profit_share:Number(x.landowner_profit_share||0),developer_profit_share:Number(x.developer_profit_share||0),status:x.status,notes:x.notes,reason:x.reason,version:Number(x.version)
  })})});
}
function openProjectBoundaryEditor(p){
  openModal({title:'Edit KMZ / project boundary',eyebrow:'GEOMETRY CONTROL',submitText:'Save boundary',fields:[
    {name:'coordinates',label:'Boundary coordinates - one longitude, latitude pair per line',type:'textarea',full:true,required:true,value:coordinatesText(p.boundary),help:'Use decimal degrees in longitude, latitude order. The polygon closes automatically.'},
    {name:'update_official_area',label:'Also set ERP controlled area to the newly computed boundary area',type:'checkbox',value:false},
    {name:'reason',label:'Reason / survey reference',type:'textarea',full:true,required:true,placeholder:'Example: Revised survey coordinates received from town planner.'},{name:'version',label:'',type:'hidden',value:p.version}
  ],onSubmit:x=>api('/project-overview/boundary',{method:'POST',body:JSON.stringify({coordinates:parseCoordinatesText(x.coordinates),update_official_area:!!x.update_official_area,reason:x.reason,version:Number(x.version)})})});
}

// ---------------- CRM ----------------
async function loadCRM(page=1,q='') {
  const data=await api(sortUrl('leads', `/leads?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const columns=[
    {label:'Lead',render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.lead_no)} · ${esc(r.mobile)}</span>`},{label:'Interest',key:'interest'},
    {label:'Source',key:'source'},{label:'Budget',render:r=>money(r.budget)},{label:'Assigned',key:'assigned_to'},{label:'Next Follow-up',render:r=>dateText(r.next_followup)},
    {label:'Stage',render:r=>pill(r.stage)},{label:'Actions',render:r=>actionButtons([{action:'edit-lead',id:r.id,label:'Edit'},{action:'followup',id:r.id,label:'Follow-up'}])}
  ];
  content.innerHTML=`${pageHead('CRM pipeline','Capture every inquiry, assign ownership and control the next follow-up date.','<button id="addLead" class="primary">+ Add lead</button>')}${renderTable({id:'leads',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadCRM(1,v),onPage:p=>loadCRM(p,q)})}`;
  $('#addLead').addEventListener('click',()=>leadForm());
  $$('[data-action="edit-lead"]').forEach(btn=>btn.addEventListener('click',()=>leadForm(data.items.find(x=>x.id==btn.dataset.id))));
  $$('[data-action="followup"]').forEach(btn=>{const item=data.items.find(x=>x.id==btn.dataset.id);btn.addEventListener('click',()=>openModal({title:`Follow-up: ${item.name}`,eyebrow:'CRM ACTIVITY',fields:[
    {name:'activity_type',label:'Activity',type:'select',options:['Call','WhatsApp','Meeting','Site Visit','Email']},{name:'stage',label:'Updated stage',type:'select',options:['New','Contacted','Qualified','Visit Scheduled','Negotiation','Won','Lost'],value:item.stage},
    {name:'next_followup',label:'Next follow-up',type:'date'},{name:'outcome',label:'Outcome / notes',type:'textarea',full:true,required:true}
  ],onSubmit:p=>api(`/leads/${item.id}/activities`,{method:'POST',body:JSON.stringify(p)})}))});
}
function leadForm(item={}){
  openModal({title:item.id?'Edit lead':'Add CRM lead',eyebrow:'CRM MASTER',fields:[
    {name:'name',label:'Lead name',required:true,value:item.name},{name:'mobile',label:'Mobile',required:true,value:item.mobile},{name:'source',label:'Source',type:'select',options:['Walk-in','Facebook','Instagram','WhatsApp','Dealer','Referral','Website','Other'],value:item.source||'Walk-in'},
    {name:'interest',label:'Interest',type:'select',options:['3 Marla Residential','5 Marla Residential','Commercial'],value:item.interest||'3 Marla Residential'},
    {name:'budget',label:'Budget',type:'number',step:'0.01',value:item.budget},{name:'stage',label:'Stage',type:'select',options:['New','Contacted','Qualified','Visit Scheduled','Negotiation','Won','Lost'],value:item.stage||'New'},
    {name:'assigned_to',label:'Assigned to',value:item.assigned_to},{name:'next_followup',label:'Next follow-up',type:'date',value:item.next_followup},
    {name:'remarks',label:'Remarks',type:'textarea',full:true,value:item.remarks},{name:'version',label:'',type:'hidden',value:item.version||1}
  ],values:item,onSubmit:p=>api(item.id?`/leads/${item.id}`:'/leads',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})});
}

// ---------------- Development ----------------
async function loadDevelopment(page=1,q=''){
  const data=await api(sortUrl('development', `/development?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const totalBudget=data.items.reduce((s,x)=>s+Number(x.budget||0),0), totalActual=data.items.reduce((s,x)=>s+Number(x.actual_cost||0),0), avg=data.items.length?data.items.reduce((s,x)=>s+Number(x.progress_percent||0),0)/data.items.length:0;
  const columns=[
    {label:'Work Package',render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.code)} · ${esc(r.category)}</span>`},{label:'Contractor',render:r=>esc(r.contractor||'—')},
    {label:'Budget',render:r=>money(r.budget)},{label:'Committed',render:r=>money(r.committed_cost)},{label:'Actual',render:r=>money(r.actual_cost)},
    {label:'Progress',render:r=>progress(r.progress_percent)},{label:'Status',render:r=>pill(r.status)},{label:'Target',render:r=>dateText(r.target_date)},
    {label:'Actions',render:r=>actionButtons([{action:'edit-dev',id:r.id,label:'Edit'},{action:'update-dev',id:r.id,label:'Progress'}])}
  ];
  content.innerHTML=`${pageHead('Development control','Track physical progress, contractors, budgets, commitments and actual costs.','<button id="addDev" class="primary">+ Add work package</button>')}
  <div class="kpi-grid">${kpi('Development Budget',money(totalBudget),'Visible work packages')}${kpi('Actual Cost',money(totalActual),`${number(totalBudget?totalActual/totalBudget*100:0,1)}% of budget`)}${kpi('Average Progress',`${number(avg,1)}%`,'Physical progress')}${kpi('Budget Balance',money(totalBudget-totalActual),'Budget less actual')}</div>
  ${renderTable({id:'development',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadDevelopment(1,v),onPage:p=>loadDevelopment(p,q)})}`;
  $('#addDev').addEventListener('click',()=>developmentForm());
  $$('[data-action="edit-dev"]').forEach(btn=>btn.addEventListener('click',()=>developmentForm(data.items.find(x=>x.id==btn.dataset.id))));
  $$('[data-action="update-dev"]').forEach(btn=>{const item=data.items.find(x=>x.id==btn.dataset.id);btn.addEventListener('click',()=>openModal({title:`Progress update: ${item.name}`,eyebrow:'SITE UPDATE',submitText:'Post update',fields:[
    {name:'update_date',label:'Update date',type:'date',value:today(),required:true},{name:'progress_percent',label:'Cumulative progress %',type:'number',min:0,max:100,step:'0.1',value:item.progress_percent,required:true},
    {name:'actual_cost_increment',label:'New actual cost',type:'number',step:'0.01',value:0},{name:'photo_url',label:'Photo / document URL'},
    {name:'description',label:'Work completed / site observations',type:'textarea',full:true,required:true}
  ],onSubmit:p=>api(`/development/${item.id}/updates`,{method:'POST',body:JSON.stringify(p)})}))});
}
function developmentForm(item={}){
  openModal({title:item.id?'Edit work package':'Add development work package',eyebrow:'DEVELOPMENT MASTER',fields:[
    {name:'code',label:'Code',value:item.code,readonly:!!item.id},{name:'name',label:'Work package name',required:true,value:item.name},
    {name:'category',label:'Category',type:'select',options:['Roads','Utilities','Sewerage','Electrification','Landscape','Buildings','Other'],value:item.category||'Roads'},
    {name:'contractor',label:'Contractor',value:item.contractor},{name:'budget',label:'Budget',type:'number',step:'0.01',value:item.budget},{name:'committed_cost',label:'Committed cost',type:'number',step:'0.01',value:item.committed_cost},
    {name:'actual_cost',label:'Actual cost',type:'number',step:'0.01',value:item.actual_cost},{name:'progress_percent',label:'Progress %',type:'number',min:0,max:100,step:'0.1',value:item.progress_percent},
    {name:'status',label:'Status',type:'select',options:['Planned','In Progress','On Hold','Completed'],value:item.status||'Planned'},{name:'start_date',label:'Start date',type:'date',value:item.start_date},
    {name:'target_date',label:'Target date',type:'date',value:item.target_date},{name:'remarks',label:'Remarks',type:'textarea',full:true,value:item.remarks},{name:'version',label:'',type:'hidden',value:item.version||1}
  ],values:item,onSubmit:p=>api(item.id?`/development/${item.id}`:'/development',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})});
}

// ---------------- Finance ----------------
async function loadFinance(page=1,q=''){
  const [vouchers,tb,pl,bs]=await Promise.all([api(sortUrl('vouchers', `/vouchers?page=${page}&size=25&q=${encodeURIComponent(q)}`)),api('/reports/trial-balance'),api('/reports/profit-loss'),api('/reports/balance-sheet')]);
  const columns=[
    {label:'Voucher',render:r=>`<strong>${esc(r.voucher_no)}</strong><span class="subtext">${dateText(r.voucher_date)} · ${esc(r.voucher_type)}</span>`},{label:'Party',render:r=>esc(r.party||'—')},
    {label:'Narration',render:r=>esc((r.narration||'').slice(0,45))},{label:'Amount',render:r=>`<strong>${money(r.amount)}</strong>`},{label:'Source',key:'source_module'},
    {label:'Status',render:r=>pill(r.status)},{label:'Actions',render:r=>actionButtons([{action:'view-voucher',id:r.id,label:'View'},...(r.status==='Posted'?[{action:'reverse-voucher',id:r.id,label:'Reverse'}]:[])])}
  ];
  content.innerHTML=`${pageHead('Finance and statutory reports','Posted vouchers are immutable and corrected through reversal or adjustment.','<button id="openFinancialIntegrity" class="secondary">Financial Integrity</button><button id="newVoucher" class="primary">+ New voucher</button>')}
  <div class="kpi-grid">${kpi('Total Income',money(pl.total_income),'Profit & Loss')}${kpi('Total Expense',money(pl.total_expense),'Profit & Loss')}${kpi('Net Profit / (Loss)',money(pl.net_profit),'Current posted records',pl.net_profit>=0)}${kpi('Trial Balance Difference',money(tb.totals.debit-tb.totals.credit),'Must remain zero')}</div>
  <div class="report-grid" style="margin-bottom:16px"><button class="report-card" data-report="trial-balance"><h3>Trial Balance</h3><p>Account-wise debit, credit and balance.</p><span class="primary">Open report</span></button><button class="report-card" data-report="profit-loss"><h3>Profit & Loss</h3><p>Income, expenses and net result.</p><span class="primary">Open report</span></button><button class="report-card" data-report="balance-sheet"><h3>Balance Sheet</h3><p>Assets, liabilities and equity.</p><span class="primary">Open report</span></button></div>
  ${renderTable({id:'vouchers',columns,items:vouchers.items,total:vouchers.total,page:vouchers.page,size:vouchers.size,query:q,onSearch:v=>loadFinance(1,v),onPage:p=>loadFinance(p,q)})}`;
  $('#openFinancialIntegrity')?.addEventListener('click',()=>navigate('financial-integrity'));
  $('#newVoucher').addEventListener('click',openVoucherModal);
  $$('[data-report]').forEach(b=>b.addEventListener('click',()=>showReport(b.dataset.report)));
  $$('[data-action="view-voucher"]').forEach(b=>b.addEventListener('click',()=>showVoucher(Number(b.dataset.id))));
  $$('[data-action="reverse-voucher"]').forEach(b=>b.addEventListener('click',()=>openModal({title:'Reverse posted voucher',eyebrow:'AUDIT-CONTROLLED CORRECTION',submitText:'Post reversal',fields:[{name:'reason',label:'Reason for reversal',type:'textarea',full:true,required:true}],onSubmit:p=>api(`/vouchers/${b.dataset.id}/reverse`,{method:'POST',body:JSON.stringify(p)})})));
}
async function loadFinancialIntegrity(){
  const [summary,dups]=await Promise.all([api('/financial-integrity/summary'),api('/financial-integrity/duplicates')]);
  const rows=[];
  (dups.items||[]).forEach(g=>(g.items||[]).forEach(v=>rows.push({...v,group_signature:g.signature,keep_id:g.recommended_keep_id,keep_no:g.recommended_keep_no,integrity_status:v.recommended_keep?'KEEP':(v.can_auto_reverse?'DUPLICATE':'SOURCE-LINKED')})));
  const columns=[
    {label:'Voucher',render:r=>`<strong>${esc(r.voucher_no)}</strong><span class="subtext">${esc(r.voucher_type)}</span>`},
    {label:'Date',key:'voucher_date',render:r=>dateText(r.voucher_date)},
    {label:'Party',key:'party',render:r=>esc(r.party||'—')},
    {label:'Narration',render:r=>esc((r.narration||'').slice(0,52))},
    {label:'Amount',key:'amount',render:r=>`<strong>${money(r.amount)}</strong>`},
    {label:'Source',key:'source_module',render:r=>`${esc(r.source_module||'—')}${r.linked_source?`<span class="subtext">Linked: ${esc(r.linked_source)} ${esc(r.linked_reference)}</span>`:''}`},
    {label:'Status',key:'integrity_status',render:r=>pill(r.integrity_status)},
    {label:'Actions',render:r=>r.recommended_keep?'<span class="subtext">Recommended original</span>':(r.can_auto_reverse?actionButtons([{action:'reverse-exact-duplicate',id:r.id,label:'Reverse Duplicate'}]):'<span class="subtext">Correct source transaction first</span>')}
  ];
  content.innerHTML=`${pageHead('Financial Integrity Control','Every posted correction uses reversal so Trial Balance, P&L, Balance Sheet, income and expense totals recalculate from the same journal.','<button id="refreshIntegrity" class="secondary">Recheck</button>')}
    <div class="notice"><b>Control policy:</b> Posted vouchers are never hard-deleted. Draft vouchers may be deleted. Posted errors and exact duplicates are reversed with an audit trail. If a voucher is linked to a Booking, Receipt, Payroll or Commission, direct removal is blocked until the source transaction is corrected so operational and financial totals cannot drift apart.</div>
    <div class="kpi-grid">${kpi('Journal Debit',money(summary.trial_balance_debit),'All effective posted/reversed entries')}${kpi('Journal Credit',money(summary.trial_balance_credit),'Must equal debit')}${kpi('TB Difference',money(summary.trial_balance_difference),'Must remain zero',Math.abs(summary.trial_balance_difference)<.01)}${kpi('Balance Sheet Difference',money(summary.balance_sheet_difference),'Must remain zero',Math.abs(summary.balance_sheet_difference)<.01)}</div>
    <div class="kpi-grid">${kpi('Income',money(summary.income),'Profit & Loss')}${kpi('Expenses',money(summary.expense),'Profit & Loss')}${kpi('Net Profit / (Loss)',money(summary.net_profit),'Recalculated from journal',summary.net_profit>=0)}${kpi('Exact Duplicate Rows',number(summary.duplicate_rows),`${number(summary.duplicate_groups)} groups · ${money(summary.duplicate_value)} potential duplicate value`)}</div>
    <div class="panel" style="margin-bottom:16px"><div class="panel-head"><h3>Integrity status</h3><span>${pill(summary.status)}</span></div><div class="panel-body"><p>All statutory statements and the Expense Register are calculated from the same voucher lines. A reversal immediately changes the related account balances, P&L, Trial Balance and Balance Sheet on refresh.</p></div></div>
    ${rows.length?renderTable({id:'financialIntegrity',columns,items:rows,total:rows.length,page:1,size:Math.max(25,rows.length)}):'<div class="notice"><b>No exact duplicate posted vouchers detected.</b> The journal is still checked for debit/credit and Balance Sheet equality.</div>'}`;
  $('#refreshIntegrity')?.addEventListener('click',()=>loadFinancialIntegrity());
  $$('[data-action="reverse-exact-duplicate"]').forEach(btn=>btn.addEventListener('click',()=>{
    const row=rows.find(x=>Number(x.id)===Number(btn.dataset.id)); if(!row)return;
    openModal({title:'Reverse exact duplicate',eyebrow:'FINANCIAL INTEGRITY CONTROL',submitText:'Reverse duplicate',fields:[
      {name:'keep',label:'Voucher to keep',value:`${row.keep_no}`,disabled:true,full:true},
      {name:'duplicate',label:'Duplicate voucher to reverse',value:`${row.voucher_no}`,disabled:true,full:true},
      {name:'reason',label:'Reason / approval reference',type:'textarea',required:true,full:true,value:`Exact duplicate of ${row.keep_no}`}
    ],onSubmit:async p=>{if(!confirm(`Reverse ${row.voucher_no} as a duplicate of ${row.keep_no}? This will post an equal and opposite reversal and update all financial reports.`))throw new Error('Cancelled');return api(`/financial-integrity/duplicates/${row.id}/reverse`,{method:'POST',body:JSON.stringify({keep_voucher_id:row.keep_id,reason:p.reason})})}});
  }));
}

async function showVoucher(id){
  setLoading(true);try{const d=await api(`/vouchers/${id}`);const v=d.voucher;openDrawer(v.voucher_no,`<div class="notice">Posted vouchers cannot be directly edited. Reverse and re-post for corrections.</div><div class="panel-body"><p><b>Date:</b> ${dateText(v.voucher_date)}</p><p><b>Type:</b> ${esc(v.voucher_type)}</p><p><b>Party:</b> ${esc(v.party||'—')}</p><p><b>Narration:</b> ${esc(v.narration)}</p></div><div class="table-panel"><div class="table-wrap"><table><thead><tr><th>Account</th><th>Debit</th><th>Credit</th><th>Plot</th></tr></thead><tbody>${d.lines.map(x=>`<tr><td>${esc(x.code)} · ${esc(x.account)}</td><td>${money(x.debit)}</td><td>${money(x.credit)}</td><td>${esc(x.plot_no||'—')}</td></tr>`).join('')}</tbody></table></div></div>`);}finally{setLoading(false)}}
function reportExportButtons(type, fromDate='', toDate=''){
  const href=(format)=>{const q=new URLSearchParams({type,format});if(fromDate)q.set('from_date',fromDate);if(toDate)q.set('to_date',toDate);return `/api/reports/statutory-export?${q.toString()}`};
  return `<div class="report-actions">
    <a class="report-action pdf" href="${href('pdf')}" download>Export PDF</a>
    <a class="report-action excel" href="${href('xlsx')}" download>Export Excel</a>
    <a class="report-action csv" href="${href('csv')}" download>Export CSV</a>
    <button class="report-action print" id="printStatutory">Print</button>
  </div>`
}
async function downloadBlob(url, fallbackName='Horizon_Report'){
  const res = await fetch(url,{credentials:'same-origin',cache:'no-store'});
  if(!res.ok){
    let msg=`Export failed (${res.status})`;
    try{const data=await res.json(); msg=data.detail||msg;}catch(_e){}
    throw new Error(msg);
  }
  const blob=await res.blob();
  const disposition=res.headers.get('content-disposition')||'';
  const match=disposition.match(/filename\*?=(?:UTF-8''|")?([^";]+)/i);
  const filename=match?decodeURIComponent(match[1].replace(/"/g,'').trim()):fallbackName;
  const objectUrl=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=objectUrl; a.download=filename; a.style.display='none';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(objectUrl),1500);
  return filename;
}
async function downloadStatutory(type,format,fromDate='',toDate=''){
  const q=new URLSearchParams({type,format}); if(fromDate) q.set('from_date',fromDate); if(toDate) q.set('to_date',toDate);
  const ext=format==='xlsx'?'xlsx':format;
  setLoading(true);
  try{const name=await downloadBlob(`/api/reports/statutory-export?${q.toString()}`,`Horizon_${type}.${ext}`);toast(`Downloaded ${name}`);}
  catch(e){toast(e.message,'error');}
  finally{setLoading(false);}
}
function reportFilterBar(type,fromDate='',toDate=''){
  const isBS=type==='balance-sheet';
  return `<div class="report-toolbar">
    <div class="report-period-controls">
      ${isBS?'':`<label><span>From date</span><input id="reportFrom" type="date" value="${esc(fromDate)}"></label>`}
      <label><span>${isBS?'As at date':'To date'}</span><input id="reportTo" type="date" value="${esc(toDate)}"></label>
      <button id="applyReportFilter" class="primary">Apply period</button>
      <button id="clearReportFilter" class="secondary">All dates</button>
    </div>
    ${reportExportButtons(type,fromDate,toDate)}
  </div>`
}
function reportMetric(label,value,foot='',tone=''){
  return `<div class="report-metric ${tone}"><span>${esc(label)}</span><strong>${value}</strong><small>${esc(foot)}</small></div>`;
}
function reportHeader(kicker,title,period){
  return `<div class="report-document-head"><div><span>${esc(kicker)}</span><h3>${esc(title)}</h3><p>Crescent Horizon Developers (Pvt.) Limited · Horizon Homes</p></div><div class="report-period">${esc(period)}</div></div>`;
}
function reportEmpty(message){ return `<tr><td colspan="5"><div class="report-empty">${esc(message)}</div></td></tr>`; }
function reportTable(title,rows,columns,totals=[]){
  const body=rows.length?rows.map(row=>`<tr>${columns.map(c=>`<td class="${c.numeric?'num':''} ${c.className||''}">${c.render?c.render(row):esc(row[c.key]??'')}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${columns.length}"><div class="report-empty">No activity for the selected period.</div></td></tr>`;
  const foot=totals.length?`<tfoot>${totals.map(t=>`<tr class="report-total-row"><td colspan="${Math.max(1,columns.length-1)}">${esc(t.label)}</td><td class="num ${t.tone||''}">${money(t.value)}</td></tr>`).join('')}</tfoot>`:'';
  return `<section class="report-section"><div class="report-section-title"><h4>${esc(title)}</h4><span>${number(rows.length)} lines</span></div><div class="report-table-wrap"><table class="report-table"><thead><tr>${columns.map(c=>`<th class="${c.numeric?'num':''}">${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${body}</tbody>${foot}</table></div></section>`;
}
function trialBalanceStatement(active,totals){
  const diff=Number(totals.debit)-Number(totals.credit);
  return `<section class="report-section"><div class="report-section-title"><h4>Account balances</h4><span>${number(active.length)} accounts with activity</span></div><div class="report-table-wrap"><table class="report-table trial-report-table"><thead><tr><th>Code</th><th>Account</th><th class="num">Debit</th><th class="num">Credit</th><th class="num">Net balance</th></tr></thead><tbody>${active.length?active.map(x=>`<tr><td>${esc(x.code)}</td><td class="account-col"><strong>${esc(x.account)}</strong><span class="report-subtext">${esc(x.type)}</span></td><td class="num">${money(x.debit)}</td><td class="num">${money(x.credit)}</td><td class="num"><span class="${Number(x.balance)<0?'negative':''}">${money(x.balance)}</span></td></tr>`).join(''):`<tr><td colspan="5"><div class="report-empty">No activity for the selected period.</div></td></tr>`}</tbody><tfoot><tr><td colspan="2">TOTAL</td><td class="num">${money(totals.debit)}</td><td class="num">${money(totals.credit)}</td><td class="num ${Math.abs(diff)<.01?'positive':'negative'}">${money(diff)}</td></tr></tfoot></table></div></section>`;
}
function profitLossStatement(d){
  const income=d.income.filter(x=>Math.abs(Number(x.amount||0))>0.005);
  const expenses=d.expenses.filter(x=>Math.abs(Number(x.amount||0))>0.005);
  const columns=[{label:'Code',key:'code'},{label:'Account',key:'account',className:'account-col'},{label:'Amount',key:'amount',numeric:true,render:x=>money(x.amount)}];
  return `${reportTable('Income',income,columns,[{label:'Total income',value:d.total_income}])}${reportTable('Expenses',expenses,columns,[{label:'Total expenses',value:d.total_expense}])}<div class="report-grand-total"><span>NET PROFIT / (LOSS)</span><strong class="${d.net_profit<0?'negative':'positive'}">${money(d.net_profit)}</strong></div>`;
}
function balanceSheetStatement(d){
  const cols=[{label:'Code',key:'code'},{label:'Account',key:'account',className:'account-col'},{label:'Amount',key:'amount',numeric:true,render:x=>money(x.amount)}];
  const assets=d.groups.Asset.filter(x=>Math.abs(Number(x.amount||0))>0.005);
  const liabilities=d.groups.Liability.filter(x=>Math.abs(Number(x.amount||0))>0.005);
  const equity=d.groups.Equity.filter(x=>Math.abs(Number(x.amount||0))>0.005);
  return `${reportTable('Assets',assets,cols,[{label:'Total assets',value:d.totals.Asset}])}${reportTable('Liabilities',liabilities,cols,[{label:'Total liabilities',value:d.totals.Liability}])}${reportTable('Equity',equity,cols,[{label:'Total equity',value:d.totals.Equity}])}<div class="report-grand-total split"><div><span>TOTAL ASSETS</span><strong>${money(d.totals.Asset)}</strong></div><div><span>LIABILITIES + EQUITY</span><strong>${money(d.totals.LiabilitiesAndEquity)}</strong></div><div><span>DIFFERENCE</span><strong class="${Math.abs(d.totals.Difference)<0.01?'positive':'negative'}">${money(d.totals.Difference)}</strong></div></div>`;
}
async function showReport(type, fromDate='', toDate=''){
  setLoading(true);try{
    const qp=new URLSearchParams(); if(fromDate) qp.set('from_date',fromDate); if(toDate) qp.set('to_date',toDate); const suffix=qp.toString()?`?${qp.toString()}`:'';
    let body='', title='Financial Report';
    if(type==='trial-balance'){
      const d=await api('/reports/trial-balance'+suffix);
      const active=d.items.filter(x=>Math.abs(Number(x.debit||0))+Math.abs(Number(x.credit||0))>0.005);
      const diff=Number(d.totals.debit)-Number(d.totals.credit);
      const period=fromDate||toDate?`${fromDate?dateText(fromDate):'Beginning'} — ${toDate?dateText(toDate):'Today'}`:'All posted transactions';
      title='Trial Balance';
      body=`${reportFilterBar(type,fromDate,toDate)}${reportHeader('STATUTORY REPORT','Trial Balance',period)}<div class="report-metrics three">${reportMetric('Total Debit',money(d.totals.debit),'Posted journal')}${reportMetric('Total Credit',money(d.totals.credit),'Posted journal')}${reportMetric('Difference',money(diff),'Must remain zero',Math.abs(diff)<.01?'ok':'bad')}</div>${trialBalanceStatement(active,d.totals)}`;
    } else if(type==='profit-loss'){
      const d=await api('/reports/profit-loss'+suffix);
      const period=fromDate||toDate?`${fromDate?dateText(fromDate):'Beginning'} — ${toDate?dateText(toDate):'Today'}`:'All posted transactions';
      title='Profit & Loss';
      body=`${reportFilterBar(type,fromDate,toDate)}${reportHeader('STATEMENT OF PROFIT OR LOSS','Profit & Loss',period)}<div class="report-metrics three">${reportMetric('Income',money(d.total_income),'Recognised revenue')}${reportMetric('Expenses',money(d.total_expense),'Posted expenses')}${reportMetric('Net Profit / (Loss)',money(d.net_profit),'Current period',d.net_profit>=0?'ok':'bad')}</div>${profitLossStatement(d)}<div class="report-note"><b>Accounting note:</b> Customer collections posted to Customer Advances remain balance-sheet liabilities until the underlying plot sale is formally recognised.</div>`;
    } else if(type==='balance-sheet'){
      const d=await api('/reports/balance-sheet'+suffix);
      const period=toDate?`As at ${dateText(toDate)}`:'As at latest posted transaction';
      title='Balance Sheet';
      body=`${reportFilterBar(type,fromDate,toDate)}${reportHeader('STATEMENT OF FINANCIAL POSITION','Balance Sheet',period)}<div class="report-metrics four">${reportMetric('Assets',money(d.totals.Asset),'Balance Sheet')}${reportMetric('Liabilities',money(d.totals.Liability),'Balance Sheet')}${reportMetric('Equity incl. result',money(d.totals.Equity),'Current P&L included')}${reportMetric('Difference',money(d.totals.Difference),'Must remain zero',Math.abs(d.totals.Difference)<.01?'ok':'bad')}</div>${balanceSheetStatement(d)}`;
    } else throw new Error('Unknown report type');
    openReportWorkspace(title,body);
    const apply=$('#applyReportFilter'), clear=$('#clearReportFilter');
    if(apply) apply.onclick=()=>showReport(type,$('#reportFrom')?.value||'', $('#reportTo')?.value||'');
    if(clear) clear.onclick=()=>showReport(type,'','');
    $('#printStatutory')?.addEventListener('click',()=>window.print());
  }catch(err){toast(err.message,'error'); throw err;}finally{setLoading(false)}
}

async function openVoucherModal(){
  setLoading(true);try{
    const d=await api('/accounts');const accounts=d.items.filter(x=>x.active).map(x=>({value:x.name,label:`${x.code} · ${x.name}`}));
    $('#modalTitle').textContent='Create accounting voucher';$('#modalEyebrow').textContent='DOUBLE-ENTRY TRANSACTION';$('#modalSubmit').textContent='Post voucher';
    $('#modalBody').innerHTML=`${fieldHtml({name:'voucher_date',label:'Voucher date',type:'date',required:true},today())}${fieldHtml({name:'voucher_type',label:'Voucher type',type:'select',options:['Journal','Payment','Receipt','Contra','Adjustment']},'Journal')}${fieldHtml({name:'party',label:'Party'},'')}${fieldHtml({name:'narration',label:'Narration',type:'textarea',full:true,required:true},'')}<div class="line-items"><table><thead><tr><th>Account</th><th>Debit</th><th>Credit</th><th></th></tr></thead><tbody id="voucherLines"></tbody></table><div class="line-add"><button type="button" id="addVoucherLine" class="secondary">+ Add line</button></div></div>`;
    const addLine=(preset={})=>{const tr=document.createElement('tr');tr.innerHTML=`<td><select class="line-account">${accounts.map(o=>`<option value="${esc(o.value)}" ${o.value===preset.account?'selected':''}>${esc(o.label)}</option>`).join('')}</select></td><td><input class="line-debit" type="number" step="0.01" value="${preset.debit||0}"></td><td><input class="line-credit" type="number" step="0.01" value="${preset.credit||0}"></td><td><button type="button" class="danger remove-line">×</button></td>`;$('#voucherLines').appendChild(tr);$('.remove-line',tr).addEventListener('click',()=>tr.remove())};
    addLine();addLine();$('#addVoucherLine').onclick=()=>addLine();$('#modal').classList.remove('hidden');
    $('#modalForm').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.currentTarget);const lines=$$('#voucherLines tr').map(tr=>({account:$('.line-account',tr).value,debit:$('.line-debit',tr).value,credit:$('.line-credit',tr).value}));try{setLoading(true);await api('/vouchers',{method:'POST',body:JSON.stringify({voucher_date:fd.get('voucher_date'),voucher_type:fd.get('voucher_type'),party:fd.get('party'),narration:fd.get('narration'),status:'Posted',lines})});closeModal();toast('Voucher posted');await loadFinance()}catch(err){toast(err.message,'error')}finally{setLoading(false)}};
  }finally{setLoading(false)}
}

// ---------------- V13 Account Cleanup & Mapping ----------------
async function loadAccountCleanup(){
  const d=await api('/account-cleanup');
  const activeMappings=d.mappings.filter(x=>x.active);
  const directorAccounts=d.accounts.filter(a=>/humayun|salman/i.test(a.name));
  const protectedAccounts=directorAccounts.filter(a=>/cash held|director receivable|loan payable/i.test(a.name));
  const inactiveAliases=directorAccounts.filter(a=>!a.active && !/cash held|director receivable|loan payable/i.test(a.name));
  const columns=[
    {label:'Code',key:'code'},
    {label:'Ledger Account',render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.type)} · ${esc(r.statement)}</span>`},
    {label:'Voucher Lines',render:r=>number(r.lines)},
    {label:'Debit',render:r=>money(r.debit)},
    {label:'Credit',render:r=>money(r.credit)},
    {label:'Balance',render:r=>money(r.balance)},
    {label:'Status',render:r=>pill(r.active?'Active':'Mapped / Inactive')}
  ];
  content.innerHTML=`${pageHead('Account cleanup & mapping','Standardize duplicate ledger names while preserving original vouchers and audit history.','<button id="newAccountMapping" class="primary">+ Map duplicate account</button>')}
  <div class="kpi-grid">${kpi('Active Mappings',number(activeMappings.length),'Alias accounts consolidated')}${kpi('Protected Director Accounts',number(protectedAccounts.length),'Cash held / receivable / loan remain separate')}${kpi('Inactive Aliases',number(inactiveAliases.length),'Hidden from new transactions')}${kpi('Accounting Control','Audit Safe','Voucher values are unchanged')}</div>
  <div class="notice"><b>Director account policy:</b> Cash Held by Salman/Humayun remains a company asset. Director Receivable and Loan Payable remain separate. Only duplicate <b>Director Current Account</b> names are consolidated.</div>
  <section class="panel" style="margin-top:16px"><div class="panel-head"><h3>Director ledger structure</h3><span>Current consolidated view</span></div>${renderTable({id:'directorAccounts',columns,items:directorAccounts,total:directorAccounts.length,page:1,size:100,query:'',onSearch:()=>loadAccountCleanup(),onPage:()=>loadAccountCleanup()})}</section>
  <section class="panel" style="margin-top:16px"><div class="panel-head"><h3>Account alias mappings</h3><span>Historical trace retained</span></div><div class="table-wrap"><table><thead><tr><th>Legacy / Alias Account</th><th>Master Account</th><th>Moved Lines</th><th>Mapped By</th><th>Status</th><th>Action</th></tr></thead><tbody>${d.mappings.length?d.mappings.map(m=>`<tr><td><strong>${esc(m.alias_name)}</strong></td><td>${esc(m.master_name)}</td><td>${number(m.moved_lines)}</td><td>${esc(m.mapped_by||'—')}<span class="subtext">${m.mapped_at?new Date(m.mapped_at).toLocaleString():''}</span></td><td>${pill(m.active?'Active Mapping':'Restored')}</td><td>${m.active?`<button class="secondary" data-action="restore-account-map" data-id="${m.id}">Restore</button>`:'—'}</td></tr>`).join(''):`<tr><td colspan="6"><div class="empty-state"><b>No mappings recorded</b></div></td></tr>`}</tbody></table></div></section>`;
  $('#newAccountMapping')?.addEventListener('click',()=>openAccountMapping(d.accounts));
  $$('[data-action="restore-account-map"]').forEach(b=>b.addEventListener('click',async()=>{
    if(!confirm('Restore this legacy account mapping? Voucher lines originally moved by this mapping will return to the legacy account.')) return;
    setLoading(true);try{await api(`/account-cleanup/${b.dataset.id}/restore`,{method:'POST',body:'{}'});toast('Account mapping restored');await loadAccountCleanup()}catch(e){toast(e.message,'error')}finally{setLoading(false)}
  }));
}
function openAccountMapping(accounts){
  const active=accounts.filter(a=>a.active);
  const aliases=accounts.filter(a=>a.active);
  const opts=x=>x.map(a=>({value:String(a.id),label:`${a.code} · ${a.name} (${a.type})`}));
  openModal({title:'Map duplicate ledger account',eyebrow:'CHART OF ACCOUNTS CONTROL',submitText:'Consolidate account',fields:[
    {name:'alias_account_id',label:'Duplicate / legacy account',type:'select',options:opts(aliases),required:true},
    {name:'master_account_id',label:'Master account to keep',type:'select',options:opts(active),required:true},
    {name:'reason',label:'Reason',type:'textarea',full:true,value:'Duplicate ledger name consolidation; preserve historical vouchers and audit trail.',required:true}
  ],onSubmit:async p=>{if(!confirm('This will move all voucher lines from the duplicate account to the selected master account and deactivate the duplicate for future entries. Continue?'))throw new Error('Mapping cancelled');return api('/account-cleanup/map',{method:'POST',body:JSON.stringify(p)})}});
}

// ---------------- Audit ----------------
async function loadAudit(page=1,q=''){
  const data=await api(sortUrl('audit', `/audit?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const columns=[{label:'Date & Time',render:r=>new Date(r.at).toLocaleString()},{label:'User',key:'user_name'},{label:'Action',render:r=>pill(r.action.replaceAll('_',' '))},{label:'Module',key:'module'},{label:'Record',key:'record_id'},{label:'Details',render:r=>`<span title="${esc(r.details)}">${esc((r.details||'').slice(0,65))}${(r.details||'').length>65?'…':''}</span>`},{label:'IP',key:'ip_address'}];
  content.innerHTML=`${pageHead('Audit trail','Every login, master edit and financial transaction is recorded.','<button onclick="window.print()" class="secondary">Print</button>')}${renderTable({id:'audit',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadAudit(1,v),onPage:p=>loadAudit(p,q)})}`;
}

// ---------------- Customer Portal ----------------
async function loadPortal(){
  const d=await api('/customer/portal');
  content.innerHTML=`<div class="portal-hero"><div><div class="eyebrow">HORIZON HOMES CUSTOMER PORTAL</div><h2>Welcome, ${esc(d.customer.name)}</h2><p>${esc(d.customer.code)} · ${esc(d.customer.mobile||'Mobile not recorded')}</p></div><div class="portal-balance"><span>Total outstanding</span><b>${money(d.summary.outstanding)}</b></div></div>
  <div class="kpi-grid">${kpi('Total Sale Value',money(d.summary.total_sale_value),'Your booked plots')}${kpi('Total Paid',money(d.summary.received),'Posted receipts')}${kpi('Outstanding',money(d.summary.outstanding),'Remaining balance')}${kpi('Plots',number(d.plots.length),'Linked to your account')}</div>
  <div class="dashboard-grid"><section class="panel"><div class="panel-head"><h3>My plots</h3><span>Live balance</span></div><div class="table-wrap"><table><thead><tr><th>Plot</th><th>Size</th><th>Status</th><th>Sale Value</th><th>Paid</th><th>Outstanding</th></tr></thead><tbody>${d.plots.map(x=>`<tr><td><strong>${esc(x.plot_no)}</strong><span class="subtext">${esc(x.chz_no||'')}</span></td><td>${number(x.size_marla,2)} Marla</td><td>${pill(x.status)}</td><td>${money(x.sale_price)}</td><td>${money(x.received)}</td><td>${money(x.outstanding)}</td></tr>`).join('')}</tbody></table></div></section>
  <section class="panel"><div class="panel-head"><h3>Recent receipts</h3><span>${d.receipts.length} receipts</span></div><div class="panel-body">${d.receipts.slice(0,6).map(x=>`<div class="notification-item"><b>${esc(x.receipt_no)} · ${money(x.amount)}</b><p>${dateText(x.receipt_date)} · ${esc(x.mode)} · ${esc(x.reference||'No reference')}</p></div>`).join('')||'<div class="empty-state">No receipts available.</div>'}</div></section></div>
  <section class="table-panel" style="margin-top:16px"><div class="panel-head"><h3>Installment schedule</h3><span>Paid, due and overdue</span></div><div class="table-wrap"><table><thead><tr><th>Due Date</th><th>Type</th><th>Amount</th><th>Paid</th><th>Balance</th><th>Status</th></tr></thead><tbody>${d.installments.map(x=>`<tr><td>${dateText(x.due_date)}</td><td>${esc(x.due_type)}</td><td>${money(x.amount)}</td><td>${money(x.paid)}</td><td>${money(x.balance)}</td><td>${pill(x.status)}</td></tr>`).join('')}</tbody></table></div></section>`;
}



// ---------------- V11 Dealers ----------------
async function loadDealers(page=1,q=''){
  const data=await api(sortUrl('dealers', `/dealers?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const columns=[
    {label:'Dealer',render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.code)} · ${esc(r.mobile||'No mobile')}</span>`},
    {label:'Plots Sold',render:r=>number(r.plots_sold)},{label:'Sales Value',render:r=>`<strong>${money(r.sales_value)}</strong>`},
    {label:'Commission Earned',render:r=>money(r.commission_earned)},{label:'Paid',render:r=>money(r.commission_paid)},
    {label:'Payable',render:r=>`<strong class="negative">${money(r.commission_payable)}</strong>`},{label:'Status',render:r=>pill(r.active?'Active':'Inactive')},
    {label:'Actions',render:r=>actionButtons([{action:'edit-dealer',id:r.id,label:'Edit'},{action:'dealer-statement',id:r.id,label:'Statement'}])}
  ];
  const totals=data.items.reduce((a,x)=>({sales:a.sales+Number(x.sales_value||0),earned:a.earned+Number(x.commission_earned||0),paid:a.paid+Number(x.commission_paid||0)}),{sales:0,earned:0,paid:0});
  content.innerHTML=`${pageHead('Dealer management','Dealer profiles, sales performance and commission position.','<button id="addDealer" class="primary">+ Add dealer</button>')}
  <div class="kpi-grid">${kpi('Dealer Sales',money(totals.sales),'Current filtered page')}${kpi('Commission Earned',money(totals.earned),'Calculated/approved')}${kpi('Commission Paid',money(totals.paid),'Settled amount')}${kpi('Commission Payable',money(totals.earned-totals.paid),'Outstanding')}</div>
  ${renderTable({id:'dealers',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadDealers(1,v),onPage:p=>loadDealers(p,q)})}`;
  $('#addDealer').addEventListener('click',()=>partyForm({party_type:'Dealer'}));
  $$('[data-action="edit-dealer"]').forEach(b=>b.addEventListener('click',()=>partyForm(data.items.find(x=>x.id==b.dataset.id))));
  $$('[data-action="dealer-statement"]').forEach(b=>b.addEventListener('click',()=>{const d=data.items.find(x=>x.id==b.dataset.id); location.hash='reports'; setTimeout(()=>toast(`Select the dealer account/party for ${d.name}`),500)}));
}

// ---------------- V11 Commissions ----------------
async function loadCommissions(page=1,q='',from='',to=''){
  const data=await api(sortUrl('commissions', `/commissions?page=${page}&size=25&q=${encodeURIComponent(q)}&from_date=${from}&to_date=${to}`));
  const totals=data.items.reduce((a,x)=>({earned:a.earned+Number(x.commission_amount||0),paid:a.paid+Number(x.paid_amount||0)}),{earned:0,paid:0});
  const columns=[
    {label:'Commission',render:r=>`<strong>${esc(r.commission_no)}</strong><span class="subtext">${dateText(r.commission_date)} · ${esc(r.commission_type)}</span>`},
    {label:'Dealer / Director',key:'dealer_name'},{label:'Booking / Plot',render:r=>`${esc(r.booking_no||'—')}<span class="subtext">Plot ${esc(r.plot_no||'—')}</span>`},
    {label:'Basis',render:r=>`${esc(r.basis)}<span class="subtext">${money(r.base_amount)} × ${number(r.rate_percent,2)}%</span>`},
    {label:'Earned',render:r=>`<strong>${money(r.commission_amount)}</strong>`},{label:'Paid',render:r=>money(r.paid_amount)},{label:'Payable',render:r=>money(r.payable)},
    {label:'Status',render:r=>pill(r.status)},{label:'Actions',render:r=>actionButtons([{action:'edit-commission',id:r.id,label:'Edit'},...(r.status==='Pending'?[{action:'approve-commission',id:r.id,label:'Approve'}]:[])])}
  ];
  content.innerHTML=`${pageHead('Commission management','Dealer and director commissions with approval and accounting control.','<button id="addCommission" class="primary">+ Add commission</button><button id="syncCommission" class="secondary">Sync dealer commissions</button>')}
  <div class="filter-bar"><label>From<input id="commFrom" type="date" value="${esc(from)}"></label><label>To<input id="commTo" type="date" value="${esc(to)}"></label><button id="applyComm" class="secondary">Apply</button></div>
  <div class="kpi-grid">${kpi('Commission Earned',money(totals.earned),'Current filtered page')}${kpi('Commission Paid',money(totals.paid),'Current filtered page')}${kpi('Commission Payable',money(totals.earned-totals.paid),'Outstanding')}${kpi('Standard Dealer Rate','2%','Net sale value')}</div>
  ${renderTable({id:'commissions',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadCommissions(1,v,from,to),onPage:p=>loadCommissions(p,q,from,to)})}`;
  $('#applyComm').addEventListener('click',()=>loadCommissions(1,q,$('#commFrom').value,$('#commTo').value));
  $('#addCommission').addEventListener('click',()=>commissionForm());
  $('#syncCommission').addEventListener('click',async()=>{try{const r=await api('/commissions/sync',{method:'POST',body:'{}'});toast(`${r.created} dealer commission records generated`);loadCommissions()}catch(e){toast(e.message,'error')}});
  $$('[data-action="edit-commission"]').forEach(b=>{const r=data.items.find(x=>x.id==b.dataset.id);b.addEventListener('click',()=>openModal({title:`Edit ${r.commission_no}`,eyebrow:'COMMISSION CONTROL',fields:[
    {name:'dealer_name',label:'Dealer / director',value:r.dealer_name,required:true},{name:'commission_type',label:'Type',type:'select',options:['Dealer','Director','Sales Staff'],value:r.commission_type},
    {name:'basis',label:'Calculation basis',type:'select',options:['Net Sale Value','Gross Sale Value','Collection','Fixed Amount'],value:r.basis},{name:'base_amount',label:'Base amount',type:'number',step:'0.01',value:r.base_amount},
    {name:'rate_percent',label:'Rate %',type:'number',step:'0.01',value:r.rate_percent},{name:'commission_amount',label:'Commission amount',type:'number',step:'0.01',value:r.commission_amount,required:true},
    {name:'paid_amount',label:'Paid amount',type:'number',step:'0.01',value:r.paid_amount},{name:'status',label:'Status',type:'select',options:['Draft','Pending','Approved','Partially Paid','Paid','Held','Cancelled'],value:r.status},
    {name:'approved_by',label:'Approved by',value:r.approved_by},{name:'remarks',label:'Remarks',type:'textarea',full:true,value:r.remarks},{name:'version',label:'',type:'hidden',value:r.version}
  ],onSubmit:p=>api(`/commissions/${r.id}`,{method:'PATCH',body:JSON.stringify(p)})}))});
  $$('[data-action="approve-commission"]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Approve and post this commission to accounts?'))return;const r=await api(`/commissions/${b.dataset.id}/approve`,{method:'POST',body:'{}'});toast(`Approved · ${r.voucher_no}`);loadCommissions(page,q,from,to)}));
}

async function commissionForm(prefillBookingId=''){
  setLoading(true);
  try{
    const [bookingData,partyData]=await Promise.all([api('/bookings?page=1&size=100'),api('/parties?page=1&size=100')]);
    const bookings=bookingData.items.filter(x=>['Posted','Active','Booked'].includes(x.status));
    const selected=bookings.find(x=>Number(x.id)===Number(prefillBookingId))||bookings[0];
    const partyNames=[...new Set([
      ...partyData.items.filter(x=>['Dealer','Director'].includes(x.party_type)).map(x=>x.name),
      ...bookings.map(x=>x.dealer_name).filter(Boolean)
    ])].sort();
    const options=bookings.map(x=>({value:String(x.id),label:`${x.booking_no} · Plot ${x.plot_no} · ${x.customer_name} · ${money(x.net_sale_value)}`}));
    openModal({title:'Add commission against sold plot',eyebrow:'COMMISSION ENTRY',submitText:'Create pending commission',fields:[
      {name:'booking_id',label:'Existing booking / sold plot',type:'select',options,required:true,value:selected?.id||''},
      {name:'commission_date',label:'Commission date',type:'date',required:true,value:selected?.booking_date||today()},
      {name:'dealer_name',label:'Dealer / director',type:'select',options:[{value:'',label:'Select party'},...partyNames],required:true,value:selected?.dealer_name||''},
      {name:'commission_type',label:'Commission type',type:'select',options:['Dealer','Director','Sales Staff'],value:'Dealer'},
      {name:'basis',label:'Calculation basis',type:'select',options:['Net Sale Value','Gross Sale Value','Collection','Fixed Amount'],value:'Net Sale Value'},
      {name:'base_amount',label:'Base amount',type:'number',step:'0.01',value:selected?.net_sale_value||0,required:true},
      {name:'rate_percent',label:'Rate %',type:'number',step:'0.01',value:2,required:true},
      {name:'commission_amount',label:'Commission amount',type:'number',step:'0.01',value:selected?Math.round(Number(selected.net_sale_value||0)*.02*100)/100:0,required:true},
      {name:'status',label:'Initial status',type:'select',options:['Pending','Draft'],value:'Pending'},
      {name:'remarks',label:'Remarks / approval reference',type:'textarea',full:true}
    ],onSubmit:p=>api('/commissions',{method:'POST',body:JSON.stringify(p)})});
    const body=$('#modalBody');
    const bookingSelect=$('[name="booking_id"]',body), typeSelect=$('[name="commission_type"]',body), basisSelect=$('[name="basis"]',body);
    const baseInput=$('[name="base_amount"]',body), rateInput=$('[name="rate_percent"]',body), amountInput=$('[name="commission_amount"]',body), partySelect=$('[name="dealer_name"]',body);
    const recalc=()=>{
      const b=bookings.find(x=>String(x.id)===String(bookingSelect?.value)); if(!b) return;
      const basis=basisSelect?.value||'Net Sale Value';
      let base=Number(baseInput?.value||0);
      if(basis==='Net Sale Value') base=Number(b.net_sale_value||0);
      else if(basis==='Gross Sale Value') base=Number(b.sale_price||0);
      else if(basis==='Collection') base=Number(b.received||0);
      if(basis!=='Fixed Amount' && baseInput) baseInput.value=base.toFixed(2);
      const rate=Number(rateInput?.value||0);
      if(amountInput && basis!=='Fixed Amount') amountInput.value=(base*rate/100).toFixed(2);
    };
    bookingSelect?.addEventListener('change',()=>{const b=bookings.find(x=>String(x.id)===String(bookingSelect.value)); if(b){if(partySelect && b.dealer_name && [...partySelect.options].some(o=>o.value===b.dealer_name)) partySelect.value=b.dealer_name; $('[name="commission_date"]',body).value=b.booking_date||today();} recalc();});
    typeSelect?.addEventListener('change',()=>{if(rateInput) rateInput.value=typeSelect.value==='Director'?'0.5':typeSelect.value==='Dealer'?'2':'0'; recalc();});
    basisSelect?.addEventListener('change',recalc); rateInput?.addEventListener('input',recalc); baseInput?.addEventListener('input',()=>{if(basisSelect?.value==='Fixed Amount' && amountInput) amountInput.value=baseInput.value; else recalc();});
    recalc();
  }finally{setLoading(false);}
}

// ---------------- V11 Reporting Centre ----------------
async function loadReports(){
  const accounts=await api('/accounts');
  content.innerHTML=`${pageHead('Reports & statements','Professional date-filtered reporting with Excel, PDF, CSV and print export.','')}
  <div class="report-tabs"><button class="active" data-rtype="day-book">Day Book</button><button data-rtype="account-statement">Account Statement</button><button data-rtype="receipts-payments">Receipts & Payments</button><button data-rtype="general-ledger">General Ledger</button></div>
  <div class="filter-bar"><label>From<input id="reportFrom" type="date"></label><label>To<input id="reportTo" type="date"></label><label>Account<select id="reportAccount"><option value="">All accounts</option>${accounts.items.filter(a=>a.active).map(a=>`<option value="${a.id}">${esc(a.code)} · ${esc(a.name)}</option>`).join('')}</select></label><button id="runReport" class="primary">Run report</button><button id="printReport" class="secondary">Print</button><button data-export="xlsx" class="secondary">Export Excel</button><button data-export="pdf" class="secondary">Export PDF</button><button data-export="csv" class="secondary">Export CSV</button></div><div id="reportOutput"><div class="empty-state"><b>Select filters and run the report</b><span>Date filters are optional.</span></div></div>`;
  let type='day-book'; $$('[data-rtype]').forEach(b=>b.addEventListener('click',()=>{$$('[data-rtype]').forEach(x=>x.classList.remove('active'));b.classList.add('active');type=b.dataset.rtype;run()}));
  const url=()=>`type=${type}&from_date=${$('#reportFrom').value}&to_date=${$('#reportTo').value}&account_id=${$('#reportAccount').value}`;
  async function run(){const d=await api(`/reports/centre?${url()}`);$('#reportOutput').innerHTML=`<div class="kpi-grid">${kpi('Transactions',number(d.summary.transactions),'Filtered vouchers')}${kpi('Total Debit',money(d.summary.total_debit),'Filtered lines')}${kpi('Total Credit',money(d.summary.total_credit),'Filtered lines')}${kpi('Closing Balance',money(d.summary.closing_balance),'Debit minus credit')}</div><div class="table-panel"><div class="table-wrap"><table><thead><tr><th>Date</th><th>Voucher</th><th>Account</th><th>Particular</th><th>Debit</th><th>Credit</th><th>Running Balance</th></tr></thead><tbody>${d.items.map(r=>`<tr><td>${dateText(r.date)}</td><td><strong>${esc(r.voucher_no)}</strong><span class="subtext">${esc(r.voucher_type)} · ${esc(r.party||'')}</span></td><td>${esc(r.account_code)} · ${esc(r.account)}</td><td>${esc(r.particular||'')}</td><td>${r.debit?money(r.debit):'—'}</td><td>${r.credit?money(r.credit):'—'}</td><td><strong>${money(r.balance)}</strong></td></tr>`).join('')||'<tr><td colspan="7"><div class="empty-state">No transactions found.</div></td></tr>'}</tbody></table></div></div>`}
  $('#runReport').addEventListener('click',run); $('#printReport').addEventListener('click',()=>window.print());
  $$('[data-export]').forEach(b=>b.addEventListener('click',()=>{window.location=`/api/reports/export?${url()}&format=${b.dataset.export}`})); run();
}

// ---------------- Expense Register ----------------
async function loadExpenses(page=1,q=''){
  const data=await api(sortUrl('expenses', `/expenses?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const total=data.items.reduce((s,x)=>s+Number(x.amount||0),0);
  const columns=[
    {label:'Date / Voucher',render:r=>`<strong>${esc(r.voucher_no)}</strong><span class="subtext">${dateText(r.expense_date)}</span>`},
    {label:'Expense Account',key:'account'},{label:'Party / Paid For',render:r=>esc(r.party||'—')},{label:'Narration',render:r=>esc((r.narration||'').slice(0,55))},
    {label:'Amount',render:r=>`<strong class="money ${r.amount<0?'positive':'negative'}">${money(Math.abs(r.amount))}${r.amount<0?' reversal':''}</strong>`},{label:'Source',key:'source_module'},
    {label:'Status',render:r=>pill(r.status)},{label:'Actions',render:r=>actionButtons([{action:'view-exp-voucher',id:r.voucher_id,label:'Voucher'}])}
  ];
  content.innerHTML=`${pageHead('Expense register','Post cash, bank or director-paid expenses without editing the ledger directly.','<button id="addExpense" class="primary">+ Post expense</button>')}
  <div class="kpi-grid">${kpi('Visible Expense Lines',money(total),'Current filtered page')}${kpi('Control Method','Double Entry','Debit expense · credit payment source')}${kpi('Director-Paid Expense','Supported','Credit director current account')}${kpi('Amendment Method','Reverse & Re-post','No direct edit after posting')}</div>
  ${renderTable({id:'expenses',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadExpenses(1,v),onPage:p=>loadExpenses(p,q)})}`;
  $('#addExpense').addEventListener('click',expenseForm);
  $$('[data-action="view-exp-voucher"]').forEach(b=>b.addEventListener('click',()=>showVoucher(Number(b.dataset.id))));
}
async function expenseForm(){
  setLoading(true);try{
    const d=await api('/accounts');
    const expenseAccounts=d.items.filter(x=>x.active&&x.type==='Expense').map(x=>({value:x.name,label:`${x.code} · ${x.name}`}));
    const paymentAccounts=d.items.filter(x=>x.active&&(['Asset','Liability'].includes(x.type))&&(x.name.includes('Cash')||x.name.includes('Bank')||x.name.includes('Director Current'))).map(x=>({value:x.name,label:`${x.code} · ${x.name}`}));
    openModal({title:'Post company expense',eyebrow:'DOUBLE-ENTRY EXPENSE',submitText:'Post expense',fields:[
      {name:'expense_date',label:'Expense date',type:'date',value:today(),required:true},{name:'expense_account',label:'Expense account',type:'select',options:expenseAccounts,required:true},
      {name:'amount',label:'Amount',type:'number',step:'0.01',required:true},{name:'paid_from',label:'Paid from / paid by',type:'select',options:paymentAccounts,required:true},
      {name:'party',label:'Vendor / recipient'},{name:'reference',label:'Bill / approval reference'},
      {name:'narration',label:'Complete narration',type:'textarea',full:true,required:true}
    ],onSubmit:p=>api('/expenses',{method:'POST',body:JSON.stringify(p)})});
  }finally{setLoading(false)}
}

// ---------------- Parties ----------------
async function loadParties(page=1,q=''){
  const data=await api(sortUrl('parties', `/parties?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const columns=[
    {label:'Party',render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.code)}</span>`},{label:'Type',render:r=>pill(r.party_type)},
    {label:'Mobile',key:'mobile'},{label:'Email',key:'email'},{label:'Opening Balance',render:r=>`${money(r.opening_balance)} ${esc(r.balance_side)}`},
    {label:'Status',render:r=>pill(r.active?'Active':'Inactive')},{label:'Actions',render:r=>actionButtons([{action:'edit-party',id:r.id,label:'Edit'}])}
  ];
  content.innerHTML=`${pageHead('Parties, vendors and contractors','Master data used in procurement, development and financial ledgers.','<button id="addParty" class="primary">+ Add party</button>')}${renderTable({id:'parties',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadParties(1,v),onPage:p=>loadParties(p,q)})}`;
  $('#addParty').addEventListener('click',()=>partyForm());
  $$('[data-action="edit-party"]').forEach(b=>b.addEventListener('click',()=>partyForm(data.items.find(x=>x.id==b.dataset.id))));
}
function partyForm(item={}){
  openModal({title:item.id?'Edit party':'Add party',eyebrow:'BUSINESS PARTNER MASTER',fields:[
    {name:'code',label:'Party code',value:item.code,readonly:!!item.id},{name:'name',label:'Party name',required:true,value:item.name},
    {name:'party_type',label:'Party type',type:'select',options:['Vendor','Contractor','Dealer','Director','Consultant','Other'],value:item.party_type||'Vendor'},
    {name:'mobile',label:'Mobile',value:item.mobile},{name:'email',label:'Email',type:'email',value:item.email},{name:'opening_balance',label:'Opening balance',type:'number',step:'0.01',value:item.opening_balance},
    {name:'balance_side',label:'Balance side',type:'select',options:['Debit','Credit'],value:item.balance_side||'Credit'},{name:'active',label:'Active',type:'checkbox',value:item.active??true},
    {name:'address',label:'Address',type:'textarea',full:true,value:item.address},{name:'remarks',label:'Remarks',type:'textarea',full:true,value:item.remarks},{name:'version',label:'',type:'hidden',value:item.version||1}
  ],values:item,onSubmit:p=>{if(item.id)delete p.code;return api(item.id?`/parties/${item.id}`:'/parties',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})}});
}

// ---------------- Procurement ----------------
async function loadProcurement(page=1,q=''){
  const data=await api(sortUrl('purchaseOrders', `/purchase-orders?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const total=data.items.reduce((s,x)=>s+Number(x.amount||0),0),approved=data.items.filter(x=>x.status==='Approved').reduce((s,x)=>s+Number(x.amount||0),0);
  const columns=[
    {label:'Purchase Order',render:r=>`<strong>${esc(r.po_no)}</strong><span class="subtext">${dateText(r.po_date)}</span>`},{label:'Vendor / Contractor',key:'vendor_name'},
    {label:'Description',render:r=>esc((r.description||'').slice(0,55))},{label:'Amount',render:r=>`<strong>${money(r.amount)}</strong>`},{label:'Expected',render:r=>dateText(r.expected_date)},
    {label:'Status',render:r=>pill(r.status)},{label:'Approved By',render:r=>esc(r.approved_by||'—')},{label:'Actions',render:r=>actionButtons([{action:'edit-po',id:r.id,label:'Edit'}])}
  ];
  content.innerHTML=`${pageHead('Procurement and purchase orders','Control vendor commitments, approvals and delivery expectations.','<button id="addPO" class="primary">+ New purchase order</button>')}
  <div class="kpi-grid">${kpi('Visible PO Value',money(total),'Current filtered page')}${kpi('Approved Commitments',money(approved),'Approved POs on page')}${kpi('Open Orders',number(data.items.filter(x=>!['Closed','Cancelled'].includes(x.status)).length),'Current page')}${kpi('Vendors','Linked master','Parties and contractors')}</div>
  ${renderTable({id:'purchaseOrders',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadProcurement(1,v),onPage:p=>loadProcurement(p,q)})}`;
  $('#addPO').addEventListener('click',()=>purchaseOrderForm());
  $$('[data-action="edit-po"]').forEach(b=>b.addEventListener('click',()=>purchaseOrderForm(data.items.find(x=>x.id==b.dataset.id))));
}
async function purchaseOrderForm(item={}){
  setLoading(true);try{
    const parties=await getOptions('/parties','id',x=>`${x.name} · ${x.party_type}`);
    const vendors=parties.filter(x=>['Vendor','Contractor','Consultant','Other'].includes(x.raw.party_type));
    openModal({title:item.id?`Edit ${item.po_no}`:'Create purchase order',eyebrow:'PROCUREMENT CONTROL',fields:[
      {name:'vendor_id',label:'Vendor / contractor',type:'select',options:vendors,required:true,value:item.vendor_id},{name:'po_date',label:'PO date',type:'date',required:true,value:item.po_date||today()},
      {name:'amount',label:'Order amount',type:'number',step:'0.01',required:true,value:item.amount},{name:'expected_date',label:'Expected delivery',type:'date',value:item.expected_date},
      {name:'status',label:'Status',type:'select',options:['Draft','Submitted','Approved','Partially Received','Closed','Cancelled'],value:item.status||'Draft'},
      {name:'description',label:'Goods / services description',type:'textarea',full:true,required:true,value:item.description},{name:'remarks',label:'Commercial terms / remarks',type:'textarea',full:true,value:item.remarks},
      {name:'version',label:'',type:'hidden',value:item.version||1}
    ],values:item,onSubmit:p=>api(item.id?`/purchase-orders/${item.id}`:'/purchase-orders',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})});
  }finally{setLoading(false)}
}

// ---------------- HR & Payroll ----------------
async function loadHR(empPage=1,q=''){
  const [employees,payroll]=await Promise.all([api(sortUrl('employees', `/employees?page=${empPage}&size=25&q=${encodeURIComponent(q)}`)),api(sortUrl('payroll','/payroll?page=1&size=50'))]);
  const payrollTotal=payroll.items.reduce((s,x)=>s+Number(x.net_pay||0),0);
  const empCols=[
    {label:'Employee',render:r=>`<strong>${esc(r.name)}</strong><span class="subtext">${esc(r.employee_no)}</span>`},{label:'Department',key:'department'},{label:'Designation',key:'designation'},
    {label:'Mobile',key:'mobile'},{label:'Joining',render:r=>dateText(r.joining_date)},{label:'Salary',render:r=>money(r.salary)},{label:'Status',render:r=>pill(r.status)},
    {label:'Actions',render:r=>actionButtons([{action:'edit-employee',id:r.id,label:'Edit'},{action:'make-payroll',id:r.id,label:'Payroll'}])}
  ];
  const payCols=[
    {label:'Month',key:'payroll_month'},{label:'Employee',render:r=>`<strong>${esc(r.employee_name)}</strong><span class="subtext">${esc(r.employee_no)}</span>`},
    {label:'Basic',render:r=>money(r.basic_salary)},{label:'Allowances',render:r=>money(r.allowances)},{label:'Deductions',render:r=>money(r.deductions)},{label:'Net Pay',render:r=>`<strong>${money(r.net_pay)}</strong>`},
    {label:'Status',render:r=>pill(r.status)},{label:'Actions',render:r=>r.status==='Draft'?actionButtons([{action:'pay-payroll',id:r.id,label:'Pay'}]):'—'}
  ];
  content.innerHTML=`${pageHead('Human resources and payroll','Employee master, monthly payroll preparation and posted salary payments.','<button id="addEmployee" class="primary">+ Add employee</button>')}
  <div class="kpi-grid">${kpi('Active Employees',number(employees.items.filter(x=>x.status==='Active').length),'Current page')}${kpi('Monthly Payroll Records',number(payroll.total),'All payroll records')}${kpi('Payroll Value',money(payrollTotal),'Loaded payroll records')}${kpi('Paid Payroll',money(payroll.items.filter(x=>x.status==='Paid').reduce((s,x)=>s+Number(x.net_pay),0)),'Posted salary vouchers')}</div>
  <div class="panel" style="margin-bottom:16px"><div class="panel-head"><h3>Employee master</h3><span>Edit-enabled table</span></div>${renderTable({id:'employees',columns:empCols,items:employees.items,total:employees.total,page:employees.page,size:employees.size,query:q,onSearch:v=>loadHR(1,v),onPage:p=>loadHR(p,q)})}</div>
  <div class="panel"><div class="panel-head"><h3>Payroll register</h3><span>Draft and paid payroll</span></div>${renderTable({id:'payroll',columns:payCols,items:payroll.items,total:payroll.total,page:payroll.page,size:payroll.size,query:'',onSearch:()=>loadHR(empPage,q),onPage:()=>loadHR(empPage,q)})}</div>`;
  $('#addEmployee').addEventListener('click',()=>employeeForm());
  $$('[data-action="edit-employee"]').forEach(b=>b.addEventListener('click',()=>employeeForm(employees.items.find(x=>x.id==b.dataset.id))));
  $$('[data-action="make-payroll"]').forEach(b=>b.addEventListener('click',()=>payrollForm(employees.items.find(x=>x.id==b.dataset.id))));
  $$('[data-action="pay-payroll"]').forEach(b=>b.addEventListener('click',()=>openModal({title:'Post salary payment',eyebrow:'PAYROLL PAYMENT',submitText:'Pay and post voucher',fields:[{name:'payment_date',label:'Payment date',type:'date',value:today(),required:true},{name:'paid_from',label:'Paid from',type:'select',options:['Bank Account','Cash in Hand','Director Current Account - Salman','Director Current Account - Humayun']}],onSubmit:p=>api(`/payroll/${b.dataset.id}/pay`,{method:'POST',body:JSON.stringify(p)})})));
}
function employeeForm(item={}){
  openModal({title:item.id?'Edit employee':'Add employee',eyebrow:'HR MASTER',fields:[
    {name:'employee_no',label:'Employee no.',value:item.employee_no,readonly:!!item.id},{name:'name',label:'Employee name',required:true,value:item.name},
    {name:'department',label:'Department',type:'select',options:['Finance','Sales','CRM','Development','Administration','Compliance'],value:item.department||'Administration'},
    {name:'designation',label:'Designation',value:item.designation},{name:'mobile',label:'Mobile',value:item.mobile},{name:'cnic',label:'CNIC',value:item.cnic},
    {name:'joining_date',label:'Joining date',type:'date',value:item.joining_date},{name:'salary',label:'Monthly salary',type:'number',step:'0.01',value:item.salary},
    {name:'status',label:'Status',type:'select',options:['Active','On Leave','Resigned','Terminated'],value:item.status||'Active'},{name:'remarks',label:'Remarks',type:'textarea',full:true,value:item.remarks},{name:'version',label:'',type:'hidden',value:item.version||1}
  ],values:item,onSubmit:p=>{if(item.id)delete p.employee_no;return api(item.id?`/employees/${item.id}`:'/employees',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})}});
}
function payrollForm(employee){
  openModal({title:`Prepare payroll: ${employee.name}`,eyebrow:'MONTHLY PAYROLL',fields:[
    {name:'employee_id',label:'',type:'hidden',value:employee.id},{name:'payroll_month',label:'Payroll month',type:'month',required:true,value:today().slice(0,7)},
    {name:'basic_salary',label:'Basic salary',type:'number',step:'0.01',value:employee.salary,required:true},{name:'allowances',label:'Allowances',type:'number',step:'0.01',value:0},
    {name:'deductions',label:'Deductions',type:'number',step:'0.01',value:0}
  ],onSubmit:p=>api('/payroll',{method:'POST',body:JSON.stringify(p)})});
}

// ---------------- Compliance ----------------
async function loadCompliance(page=1,q=''){
  const data=await api(sortUrl('compliance', `/compliance?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const overdue=data.items.filter(x=>x.due_date&&x.due_date<today()&&!['Closed','Complied'].includes(x.status)).length;
  const columns=[
    {label:'Reference',render:r=>`<strong>${esc(r.reference_no)}</strong><span class="subtext">${esc(r.authority)}</span>`},{label:'Subject',render:r=>esc((r.subject||'').slice(0,65))},
    {label:'Issue Date',render:r=>dateText(r.issue_date)},{label:'Due Date',render:r=>`<span class="${r.due_date&&r.due_date<today()&&!['Closed','Complied'].includes(r.status)?'negative':''}">${dateText(r.due_date)}</span>`},
    {label:'Responsible',key:'responsible_person'},{label:'Status',render:r=>pill(r.status)},{label:'Actions',render:r=>actionButtons([{action:'edit-compliance',id:r.id,label:'Edit'}])}
  ];
  content.innerHTML=`${pageHead('RUDA and compliance register','Track notices, approvals, submissions, deadlines and responsible persons.','<button id="addCompliance" class="primary">+ Add compliance item</button>')}
  <div class="kpi-grid">${kpi('Open Items',number(data.items.filter(x=>!['Closed','Complied'].includes(x.status)).length),'Current page')}${kpi('Overdue Items',number(overdue),'Require immediate action')}${kpi('Closed / Complied',number(data.items.filter(x=>['Closed','Complied'].includes(x.status)).length),'Current page')}${kpi('Primary Authority','RUDA','Configurable per item')}</div>
  ${renderTable({id:'compliance',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadCompliance(1,v),onPage:p=>loadCompliance(p,q)})}`;
  $('#addCompliance').addEventListener('click',()=>complianceForm());
  $$('[data-action="edit-compliance"]').forEach(b=>b.addEventListener('click',()=>complianceForm(data.items.find(x=>x.id==b.dataset.id))));
}
function complianceForm(item={}){
  openModal({title:item.id?'Edit compliance item':'Add compliance item',eyebrow:'REGULATORY CONTROL',fields:[
    {name:'reference_no',label:'Reference number',value:item.reference_no,readonly:!!item.id},{name:'authority',label:'Authority',type:'select',options:['RUDA','LDA','FBR','SECP','Bank','Other'],value:item.authority||'RUDA'},
    {name:'subject',label:'Subject',full:true,required:true,value:item.subject},{name:'issue_date',label:'Issue date',type:'date',value:item.issue_date},{name:'due_date',label:'Due date',type:'date',value:item.due_date},
    {name:'status',label:'Status',type:'select',options:['Open','In Progress','Submitted','Complied','Closed','On Hold'],value:item.status||'Open'},{name:'responsible_person',label:'Responsible person',value:item.responsible_person},
    {name:'remarks',label:'Remarks / required action',type:'textarea',full:true,value:item.remarks},{name:'version',label:'',type:'hidden',value:item.version||1}
  ],values:item,onSubmit:p=>{if(item.id)delete p.reference_no;return api(item.id?`/compliance/${item.id}`:'/compliance',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})}});
}

// ---------------- Documents ----------------
async function loadDocuments(page=1,q=''){
  const data=await api(sortUrl('documents', `/documents?page=${page}&size=25&q=${encodeURIComponent(q)}`));
  const columns=[
    {label:'File',render:r=>`<strong>${esc(r.file_name)}</strong><span class="subtext">${esc(r.document_type)}</span>`},{label:'Module',key:'module'},{label:'Record ID',key:'record_id'},
    {label:'Uploaded By',key:'uploaded_by'},{label:'Date',render:r=>new Date(r.created_at).toLocaleDateString()},{label:'Link',render:r=>r.storage_url?`<a href="${esc(r.storage_url)}" target="_blank" rel="noopener">Open document</a>`:'—'}
  ];
  content.innerHTML=`${pageHead('Document register','Register customer, plot, RUDA, contractor and project document locations.','<button id="addDocument" class="primary">+ Register document</button>')}
  <div class="notice">This release stores secure document metadata and URLs. For cloud production, connect private object storage and signed download links.</div>
  ${renderTable({id:'documents',columns,items:data.items,total:data.total,page:data.page,size:data.size,query:q,onSearch:v=>loadDocuments(1,v),onPage:p=>loadDocuments(p,q)})}`;
  $('#addDocument').addEventListener('click',()=>openModal({title:'Register document',eyebrow:'DOCUMENT CONTROL',fields:[
    {name:'module',label:'Module',type:'select',options:['Customer','Plot','Booking','RUDA','Development','Contractor','Finance','HR','General']},{name:'record_id',label:'Related record ID',type:'number',value:0},
    {name:'document_type',label:'Document type',type:'select',options:['CNIC','Booking Form','Receipt','Allotment Letter','Agreement','NOC','Notice','Invoice','Photo','Other']},{name:'file_name',label:'File name / title',required:true},
    {name:'storage_url',label:'Secure storage URL',type:'url',full:true,help:'Use a private or controlled link in production.'}
  ],onSubmit:p=>api('/documents',{method:'POST',body:JSON.stringify(p)})}));
}

// ---------------- Users ----------------
async function loadUsers(){
  const data=await api(sortUrl('users','/users'));
  const columns=[
    {label:'User',render:r=>`<strong>${esc(r.full_name)}</strong><span class="subtext">${esc(r.username)}</span>`},{label:'Role',render:r=>pill(r.role)},
    {label:'Customer Link',render:r=>r.customer_id?`Customer #${r.customer_id}`:'—'},{label:'Status',render:r=>pill(r.active?'Active':'Inactive')},{label:'Created',render:r=>new Date(r.created_at).toLocaleDateString()},
    {label:'Actions',render:r=>actionButtons([{action:'edit-user',id:r.id,label:'Edit'}])}
  ];
  content.innerHTML=`${pageHead('Users and roles','Create role-based management accounts and customer portal logins.','<button id="addUser" class="primary">+ Add user</button>')}${renderTable({id:'users',columns,items:data.items,total:data.items.length,page:1,size:100,query:'',onSearch:()=>{},onPage:()=>{}})}`;
  $('#addUser').addEventListener('click',()=>userForm());
  $$('[data-action="edit-user"]').forEach(b=>b.addEventListener('click',()=>userForm(data.items.find(x=>x.id==b.dataset.id))));
}
async function userForm(item={}){
  setLoading(true);try{
    const customers=await getOptions('/customers','id',x=>`${x.name} · ${x.code}`);
    openModal({title:item.id?'Edit user':'Create user account',eyebrow:'ACCESS CONTROL',fields:[
      {name:'username',label:'Username',required:true,value:item.username,readonly:!!item.id},{name:'full_name',label:'Full name',required:true,value:item.full_name},
      {name:'role',label:'Role',type:'select',options:['Admin','Finance','Sales','CRM','Development','Customer'],value:item.role||'Sales'},
      {name:'customer_id',label:'Linked customer (customer role)',type:'select',options:[{value:'',label:'Not linked'},...customers],value:item.customer_id||''},
      {name:'password',label:item.id?'New password (leave blank to keep)':'Initial password',type:'password',required:!item.id,help:'Minimum 8 characters.'},
      {name:'active',label:'Active user',type:'checkbox',value:item.active??true}
    ],values:item,onSubmit:p=>{if(item.id)delete p.username;return api(item.id?`/users/${item.id}`:'/users',{method:item.id?'PATCH':'POST',body:JSON.stringify(p)})}});
  }finally{setLoading(false)}
}

// ---------------- Settings ----------------
async function loadSettings(){
  content.innerHTML=`${pageHead('Settings and deployment','System operation, mobile installation and deployment information.')}
  <div class="report-grid">
    <section class="report-card"><h3>Install as a mobile app</h3><p>Horizon ERP is a Progressive Web App. Open the hosted URL on Android Chrome or iPhone Safari and choose Add to Home Screen.</p><button id="installSettings" class="primary">Install app</button></section>
    <section class="report-card"><h3>Role-based portals</h3><p>Admin, Finance, Sales, CRM, Development and Customer roles receive separate navigation and permissions from the same secure platform.</p><div class="actions"><button id="changePassword" class="primary">Change password</button><button id="showCredentials" class="secondary">Initial users</button></div></section>
    <section class="report-card"><h3>Production database</h3><p>Local mode uses SQLite. Cloud mode supports PostgreSQL through the DATABASE_URL environment variable.</p><button id="hostingGuide" class="secondary">Hosting checklist</button></section>
    <section class="report-card"><h3>WhatsApp Business API</h3><p>Configure Meta Cloud API, booking confirmations, due reminders and delivery logs.</p><button id="openWhatsappSettings" class="secondary">Open WhatsApp Center</button></section>
    <section class="report-card"><h3>Biometric Plot Transfer</h3><p>Use WebAuthn/passkeys so fingerprint/Face ID/Windows Hello can approve ownership transfers without storing raw biometric data.</p><button id="biometricSettings" class="secondary">Biometric settings</button></section>
  </div>
  <div class="notice" style="margin-top:16px"><b>Important:</b> Verify migrated opening balances and change all initial passwords before production use. Free cloud tiers are appropriate for pilot testing, not permanent accounting records.</div>
  <section class="panel" style="margin-top:16px"><div class="panel-head"><h3>Professional transaction controls</h3><span>Enabled</span></div><div class="panel-body"><div class="mix-list">
    ${['Posted vouchers cannot be directly edited','Sale values change through a posted amendment','Reservation deposits remain a liability until conversion or refund','Plot inventory updates from sales and collection transactions','Optimistic locking prevents silent overwrites','Every material action writes to the audit trail','Responsive PWA supports management and customer portals','Plot transfers can require biometric/passkey verification for both customers without storing raw fingerprints' ].map((x,i)=>`<div class="mix-row"><i style="background:#16845b"></i><span>${esc(x)}</span><b>✓</b></div>`).join('')}
  </div></div></section>`;
  $('#installSettings').addEventListener('click',installApp);
  $('#openWhatsappSettings')?.addEventListener('click',()=>navigate('whatsapp'));
  $('#biometricSettings')?.addEventListener('click',async()=>{try{const d=await api('/biometrics/settings');openModal({title:'Biometric transfer settings',eyebrow:'SECURITY CONTROL',submitText:'Save biometric policy',fields:[{name:'transfer_mode',label:'Transfer biometric requirement',type:'select',options:['Both Parties','Outgoing Only','Disabled'],value:d.transfer_mode,help:'Recommended: Both Parties. Disabled should only be used during setup/testing.'},{name:'provider',label:'Provider',readonly:true,value:d.provider},{name:'rp_id',label:'Relying Party / ERP Domain',readonly:true,value:d.rp_id||'Set WEBAUTHN_RP_ID for production'},{name:'origin',label:'Expected HTTPS Origin',readonly:true,value:d.origin||'Set WEBAUTHN_ORIGIN for production'},{name:'privacy',label:'Privacy',type:'textarea',full:true,readonly:true,value:d.privacy}],onSubmit:p=>api('/biometrics/settings',{method:'POST',body:JSON.stringify({transfer_mode:p.transfer_mode})})})}catch(e){toast(e.message,'error')}});
  $('#changePassword').addEventListener('click',()=>openModal({title:'Change my password',eyebrow:'SECURITY',submitText:'Update password',fields:[{name:'current_password',label:'Current password',type:'password',required:true},{name:'new_password',label:'New password',type:'password',required:true,help:'Use at least 8 characters with letters, numbers and symbols.'},{name:'confirm_password',label:'Confirm new password',type:'password',required:true}],onSubmit:p=>{if(p.new_password!==p.confirm_password)throw new Error('New passwords do not match');delete p.confirm_password;return api('/change-password',{method:'POST',body:JSON.stringify(p)})}}));
  $('#showCredentials').addEventListener('click',()=>openDrawer('Initial user accounts',`<div class="notice">Change these passwords immediately after first login.</div>${[['admin','Admin@123','Full system'],['finance','Finance@123','Accounts'],['sales','Sales@123','Sales and collections'],['crm','CRM@123','Leads and follow-ups'],['site','Site@123','Development'],['customer','Customer@123','Customer portal']].map(x=>`<div class="notification-item"><b>${x[0]}</b><p>Password: ${x[1]}<br>${x[2]}</p></div>`).join('')}`));
  $('#hostingGuide').addEventListener('click',()=>openDrawer('Free pilot hosting checklist',`<div class="notification-item"><b>1. PostgreSQL</b><p>Create a Supabase project and copy the connection string into DATABASE_URL.</p></div><div class="notification-item"><b>2. Web service</b><p>Push this folder to GitHub and connect it to Render using the included render.yaml.</p></div><div class="notification-item"><b>3. Security</b><p>Set COOKIE_SECURE=1 and a strong DEFAULT_ADMIN_PASSWORD.</p></div><div class="notification-item"><b>4. Mobile</b><p>Open the HTTPS URL on the phone and install the PWA from the browser menu.</p></div><div class="notice">Free hosting can sleep, pause or impose storage limits. Use it for pilot testing and move accounting production to a paid, backed-up service.</div>`));
}

// ---------------- Notifications & shell ----------------
async function loadNotifications(){
  try{const d=await api('/notifications');openDrawer('Notifications',d.items.map(x=>`<div class="notification-item ${x.read?'':'unread'}" data-notification="${x.id}"><b>${esc(x.title)}</b><p>${esc(x.message)}</p><small>${new Date(x.created_at).toLocaleString()}</small></div>`).join('')||'<div class="empty-state">No notifications.</div>');$$('[data-notification]').forEach(el=>el.addEventListener('click',()=>api(`/notifications/${el.dataset.notification}/read`,{method:'POST',body:'{}'}).then(()=>el.classList.remove('unread'))))}catch(e){toast(e.message,'error')}
}
function toggleSidebar(){ $('#sidebar').classList.toggle('open'); $('#sidebarBackdrop').classList.toggle('hidden'); }
function closeSidebar(){ $('#sidebar').classList.remove('open'); $('#sidebarBackdrop').classList.add('hidden'); }
async function installApp(){if(state.installPrompt){state.installPrompt.prompt();await state.installPrompt.userChoice;state.installPrompt=null;$('#installButton').classList.add('hidden')}else{toast('Use your browser menu and choose “Add to Home Screen” or “Install app”.')}}

async function bootstrap(){
  try{
    const me=await api('/me');state.user=me.user;state.csrf=me.csrf_token;showApp();buildNav();
    $('#userName').textContent=state.user.full_name;$('#userRole').textContent=state.user.role;$('#userInitials').textContent=state.user.full_name.split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase();
    $('#notificationCount').textContent=me.unread_notifications;$('#notificationCount').classList.toggle('hidden',!me.unread_notifications);
    await loadRoute();
  }catch(e){showLogin()}
}

$('#loginForm').addEventListener('submit',async e=>{e.preventDefault();$('#loginError').textContent='';setLoading(true);try{const d=await api('/login',{method:'POST',body:JSON.stringify({username:$('#loginUsername').value,password:$('#loginPassword').value})});state.user=d.user;state.csrf=d.csrf_token;showApp();buildNav();$('#userName').textContent=state.user.full_name;$('#userRole').textContent=state.user.role;$('#userInitials').textContent=state.user.full_name.split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase();navigate(state.user.role==='Customer'?'portal':'dashboard');await loadRoute()}catch(err){$('#loginError').textContent=err.message}finally{setLoading(false)}});
$('#showPassword').addEventListener('click',()=>{const x=$('#loginPassword');x.type=x.type==='password'?'text':'password';$('#showPassword').textContent=x.type==='password'?'Show':'Hide'});
$('#logoutButton').addEventListener('click',async()=>{try{await api('/logout',{method:'POST',body:'{}'})}catch{}showLogin();$('#userDropdown').classList.add('hidden')});
$('#userButton').addEventListener('click',()=>$('#userDropdown').classList.toggle('hidden'));
$('#notificationButton').addEventListener('click',loadNotifications);$('#refreshButton').addEventListener('click',()=>state.currentLoader?.());
$('#menuButton').addEventListener('click',toggleSidebar);$('#sidebarClose').addEventListener('click',closeSidebar);$('#sidebarBackdrop').addEventListener('click',closeSidebar);$('#installButton').addEventListener('click',installApp);
window.addEventListener('hashchange',()=>state.user&&loadRoute());
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();state.installPrompt=e;$('#installButton').classList.remove('hidden')});
window.addEventListener('appinstalled',()=>toast('Horizon ERP installed successfully'));
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js?v=23.0.0').catch(()=>{}));
bootstrap();


// ---------------- V12 Data Migration & Reconciliation ----------------
async function loadMigration(page=1,q='',status=''){
  const summary=await api('/migration/summary'); const batch=summary.latest;
  const rows=await api(sortUrl('migrationRows', `/migration/rows?page=${page}&size=25&q=${encodeURIComponent(q)}&status=${encodeURIComponent(status)}${batch?`&batch_id=${batch.id}`:''}`));
  const control=summary.control_totals, erp=summary.erp;
  const columns=[
    {label:'Source',sortKey:'source_row',render:r=>`<strong>Row ${r.source_row}</strong><span class="subtext">${esc(r.source_sheet)} · ${esc(r.migration_key)}</span>`},
    {label:'Voucher / Date',sortKey:'voucher_no',render:r=>`<strong>${esc(r.voucher_no)}</strong><span class="subtext">${dateText(r.transaction_date)}</span>`},
    {label:'Transaction',sortKey:'particulars',render:r=>`<strong>${esc(r.source_account)}</strong><span class="subtext">${esc(r.particulars)}</span>`},
    {label:'Debit Account',key:'debit_account',sortKey:'debit_account'},{label:'Credit Account',key:'credit_account',sortKey:'credit_account'},
    {label:'Debit',sortKey:'debit',render:r=>money(r.debit)},{label:'Credit',sortKey:'credit',render:r=>money(r.credit)},
    {label:'Status',sortKey:'reconciliation_status',render:r=>`${pill(r.reconciliation_status)}${r.mismatch_details?`<span class="subtext negative">${esc(r.mismatch_details)}</span>`:''}`},
    {label:'Actions',render:r=>actionButtons([{action:'view-migration',id:r.id,label:'View'},...((!['Matched','Duplicate in ERP'].includes(r.reconciliation_status))?[{action:'approve-migration',id:r.id,label:r.posted?'Approve':'Approve & Post'}]:[])])}
  ];
  content.innerHTML=`${pageHead('Data migration & reconciliation','Upload the original Horizon source ledger directly. The ERP detects inserted/reordered rows by transaction fingerprint so row shifts do not create false duplicates. Posted vouchers remain protected.','')}
  <div class="kpi-grid">${kpi('Source Rows',batch?batch.source_rows:0,`Control ${control.source_rows}`)}${kpi('Matched',batch?batch.matched_count:0,'Exact source-to-ERP match')}${kpi('Mismatches',batch?batch.mismatch_count:0,'Must be resolved')}${kpi('ERP Vouchers',erp.vouchers,`Control ${control.vouchers}`)}</div>
  <div class="panel"><div class="panel-head"><div><h3>Latest source reconciliation controls</h3><p>Controls update automatically from the uploaded master workbook; every generated accounting transaction must remain balanced.</p></div><div class="button-row"><a class="button secondary" href="/api/migration/export.xlsx${batch?`?batch_id=${batch.id}`:''}">Export Excel</a><a class="button secondary" href="/api/migration/export.pdf${batch?`?batch_id=${batch.id}`:''}">Export PDF</a></div></div>
  <div class="control-grid"><div><span>ERP Debit</span><strong>${money(erp.debit)}</strong></div><div><span>ERP Credit</span><strong>${money(erp.credit)}</strong></div><div><span>Difference</span><strong>${money(erp.debit-erp.credit)}</strong></div><div><span>Batch Status</span><strong>${batch?esc(batch.status):'No batch'}</strong></div></div></div>
  <div class="panel"><div class="panel-head"><div><h3>Upload Horizon Master Excel</h3><p>Accepts your single-sheet <b>Horizon</b> source file directly, as well as the enterprise 3-sheet template. Repeated uploads are detected by SHA-256. Use <b>View</b> and <b>Approve</b> beside each unresolved transaction to review/correct its account mapping and post it directly.</p></div></div><form id="migrationUpload" class="inline-form"><input id="migrationFile" type="file" accept=".xlsx,.xlsm" required><button class="primary" type="submit">Upload Source File → Validate & Reconcile</button>${batch?`<button id="reconcileBatch" type="button" class="secondary">Reconcile Again</button><button id="postVerified" type="button" class="secondary">Bulk Post Auto-Mapped Missing</button><button id="rollbackBatch" type="button" class="danger">Roll Back Draft Imports</button>`:''}</form></div>
  <div class="filter-bar"><select id="migrationStatus"><option value="">All statuses</option>${['Matched','Missing in ERP','Duplicate in ERP','Amount Mismatch','Account Mismatch','Date Mismatch','Unbalanced Voucher','Requires Review'].map(x=>`<option ${status===x?'selected':''}>${x}</option>`).join('')}</select></div>
  ${renderTable({id:'migrationRows',columns,items:rows.items,total:rows.total,page:rows.page,size:rows.size,query:q,onSearch:v=>loadMigration(1,v,status),onPage:p=>loadMigration(p,q,status)})}`;
  $('#migrationStatus').addEventListener('change',e=>loadMigration(1,q,e.target.value));
  $('#migrationUpload').addEventListener('submit',async e=>{e.preventDefault(); const file=$('#migrationFile').files[0]; if(!file)return; const fd=new FormData(); fd.append('file',file); try{const result=await api('/migration/upload',{method:'POST',body:fd,rawBody:true}); toast(`${result.batch_no}: ${result.matched} matched, ${result.mismatches} mismatches`); loadMigration();}catch(err){toast(err.message,true)}});
  $$('[data-action="view-migration"]').forEach(b=>b.addEventListener('click',async()=>{try{const r=await api(`/migration/row/${b.dataset.id}`); const existing=r.existing_voucher; openDrawer(`Migration row ${r.source_row}`,`<div class="detail-grid"><div><span>Source account</span><strong>${esc(r.source_account||'—')}</strong></div><div><span>Date</span><strong>${dateText(r.transaction_date)}</strong></div><div><span>Particulars</span><strong>${esc(r.particulars||'—')}</strong></div><div><span>Paid / Received by</span><strong>${esc(r.paid_received_by||'—')}</strong></div><div><span>Debit account</span><strong>${esc(r.debit_account||'Not mapped')}</strong></div><div><span>Credit account</span><strong>${esc(r.credit_account||'Not mapped')}</strong></div><div><span>Debit</span><strong>${money(r.debit)}</strong></div><div><span>Credit</span><strong>${money(r.credit)}</strong></div><div><span>Status</span><strong>${esc(r.reconciliation_status)}</strong></div><div><span>Mismatch / review note</span><strong>${esc(r.mismatch_details||'—')}</strong></div></div>${existing?`<div class="notice" style="margin-top:16px"><b>Existing ERP voucher:</b> ${esc(existing.voucher_no)} · ${dateText(existing.date)} · ${esc(existing.status)}<br>Debit: ${money(existing.debit)} · Credit: ${money(existing.credit)}<br>Dr: ${esc(existing.debit_accounts.join(', '))}<br>Cr: ${esc(existing.credit_accounts.join(', '))}</div>`:''}`,true);}catch(err){toast(err.message,true)}}));
  $$('[data-action="approve-migration"]').forEach(b=>b.addEventListener('click',async()=>{try{const [r,accounts]=await Promise.all([api(`/migration/row/${b.dataset.id}`),api('/accounts')]); const options=accounts.items.filter(a=>a.active).map(a=>({value:a.name,label:`${a.code} · ${a.name}`})); const existing=r.existing_voucher; const existingFields=existing?[{name:'existing_voucher',label:'Existing ERP voucher',value:`${existing.voucher_no} · ${dateText(existing.date)} · ${existing.status}`,readonly:true},{name:'existing_debit',label:'Existing ERP Debit account(s)',value:existing.debit_accounts.join(', '),readonly:true},{name:'existing_credit',label:'Existing ERP Credit account(s)',value:existing.credit_accounts.join(', '),readonly:true}]:[]; openModal({title:`Review & approve row ${r.source_row}`,eyebrow:'MIGRATION APPROVAL',submitText:existing?'Approve Match':'Approve & Post',fields:[{name:'source_account',label:'Source account',value:r.source_account,readonly:true},{name:'transaction_date',label:'Transaction date',type:'date',value:r.transaction_date||''},{name:'particulars',label:'Particulars / narration',type:'textarea',full:true,value:r.particulars,required:true},{name:'party_name',label:'Party / Paid-Received By',value:r.party_name||r.paid_received_by||''},...existingFields,{name:'debit_account',label:'Approved Debit account',type:'select',options,value:(existing&&existing.debit_accounts.length===1?existing.debit_accounts[0]:r.debit_account)||'',required:true},{name:'credit_account',label:'Approved Credit account',type:'select',options,value:(existing&&existing.credit_accounts.length===1?existing.credit_accounts[0]:r.credit_account)||'',required:true},{name:'amount',label:'Voucher amount',value:money(r.debit),readonly:true},{name:'plot_no',label:'Plot No.',value:r.plot_no||''},{name:'customer_reference',label:'Customer reference',value:r.customer_reference||''}],onSubmit:async payload=>{const msg=existing?`Approve this source transaction against existing voucher ${existing.voucher_no}?\nDebit: ${payload.debit_account}\nCredit: ${payload.credit_account}\nAmount: ${money(r.debit)}`:`Approve and post this transaction?\nDebit: ${payload.debit_account}\nCredit: ${payload.credit_account}\nAmount: ${money(r.debit)}`; if(!confirm(msg))throw new Error('Approval cancelled'); const result=await api(`/migration/row/${r.id}/approve-post`,{method:'POST',body:JSON.stringify(payload)}); toast(result.message||`Approved · ${result.voucher_no}`); loadMigration();}});}catch(err){toast(err.message,true)}}));
  if(batch){ $('#reconcileBatch').addEventListener('click',async()=>{try{await api(`/migration/reconcile/${batch.id}`,{method:'POST'}); toast('Reconciliation completed'); loadMigration();}catch(err){toast(err.message,true)}}); $('#postVerified').addEventListener('click',async()=>{if(!confirm('Bulk-post every currently auto-mapped Missing in ERP transaction? For mismatches, use the row-level Approve button instead.'))return; try{const r=await api(`/migration/post-verified/${batch.id}`,{method:'POST'}); toast(`${r.posted} auto-mapped missing entries posted`); loadMigration();}catch(err){toast(err.message,true)}}); $('#rollbackBatch').addEventListener('click',async()=>{if(!confirm('Only draft migration vouchers will be removed. Posted entries stay protected. Continue?'))return; try{const r=await api(`/migration/rollback/${batch.id}`,{method:'POST'}); toast(r.message); loadMigration();}catch(err){toast(err.message,true)}}); }
}
