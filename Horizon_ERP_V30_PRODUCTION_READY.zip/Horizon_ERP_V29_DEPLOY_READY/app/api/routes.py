from __future__ import annotations

import hashlib
import hmac
import csv
import os
import json
from threading import Thread
from pathlib import Path
from io import BytesIO, StringIO
from datetime import date, datetime, timedelta
from typing import Any
from html import escape as html_escape

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, UploadFile, File
from fastapi.responses import StreamingResponse, FileResponse
from sqlalchemy import and_, case, desc, func, or_, select
from sqlalchemy.orm import Session
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

from ..core.config import (APP_NAME, APP_VERSION, PROJECT_NAME, BASE_DIR, COOKIE_SECURE, SESSION_HOURS,
    WEBAUTHN_RP_ID, WEBAUTHN_ORIGIN, WEBAUTHN_RP_NAME, BIOMETRIC_VERIFICATION_MINUTES)
from ..core.security import expires_in, hash_password, new_csrf_token, new_session_token, verify_password
from ..db import SessionLocal
from ..models import (
    Account, AccountAlias, AuditLog, AuthSession, Booking, ComplianceItem, CRMActivity, Customer,
    DevelopmentProject, DevelopmentUpdate, Document, Employee, Installment, Lead,
    Notification, Party, Payroll, Plot, PurchaseOrder, Receipt, Reservation, Setting, User,
    Voucher, VoucherLine, Commission, MigrationBatch, MigrationRow, WhatsAppMessageLog,
    ProjectProfile, ProjectAreaRevision, PaymentPlanTemplate, PaymentPlanTemplateLine, BookingPaymentPlan, PlotTransfer,
    BiometricCredential, BiometricChallenge, BiometricVerification, ClientFile
)
from ..services.accounting import balance_sheet, create_voucher, profit_loss, reverse_voucher, trial_balance
from ..services.account_cleanup import merge_account, restore_account_mapping
from ..services.financial_integrity import financial_integrity_summary, duplicate_groups, reverse_duplicate_voucher, remove_or_reverse_voucher
from ..services.financial_import import import_status, request_import, run_import
from ..services.common import as_float, audit, model_dict, next_number, to_date
from ..services.erp import amend_sale_value, create_booking, create_receipt, release_reservation, reserve_plot, update_booking_details
from ..services.project_overview import area_metrics, normalize_coordinates, parse_kmz_bytes, polygon_area_sqm
from ..services.payment_plans import apply_template_to_booking, import_plans
from ..services.whatsapp import (
    fmt_money, get_whatsapp_config, make_wa_link, public_whatsapp_config,
    save_whatsapp_config, send_template_message,
)
from ..services.biometrics import (
    authentication_options, b64url_decode, b64url_encode, expires as biometric_expires,
    new_verification_token, registration_options, request_webauthn_context, token_hash,
    utcnow as biometric_now, verify_authentication, verify_registration, webauthn_available,
)
from .deps import csrf_protect, csrf_roles, get_current_context, get_db, require_roles

router = APIRouter(prefix="/api")


def error(exc: Exception, status_code: int = 400):
    raise HTTPException(status_code=status_code, detail=str(exc))


def page_params(request: Request) -> tuple[int, int, str]:
    try:
        page = max(1, int(request.query_params.get("page", "1")))
        size = min(100, max(10, int(request.query_params.get("size", "25"))))
    except ValueError:
        page, size = 1, 25
    return page, size, request.query_params.get("q", "").strip()


def paginated(db: Session, stmt, count_stmt, page: int, size: int):
    total = db.scalar(count_stmt) or 0
    rows = db.execute(stmt.offset((page - 1) * size).limit(size)).all()
    return rows, total


def apply_sort(request: Request, stmt, sort_map: dict[str, Any], default_key: str, default_dir: str = "asc", secondary=None):
    """Apply an allow-listed server-side sort so pagination always follows the selected header."""
    sort_by = request.query_params.get("sort_by", default_key).strip()
    if sort_by not in sort_map:
        sort_by = default_key
    sort_dir = request.query_params.get("sort_dir", default_dir).strip().lower()
    if sort_dir not in {"asc", "desc"}:
        sort_dir = default_dir
    column = sort_map[sort_by]
    if callable(column):
        clauses = column(sort_dir)
        if not isinstance(clauses, (list, tuple)):
            clauses = [clauses]
    else:
        clauses = [column.asc() if sort_dir == "asc" else column.desc()]
    if secondary is not None:
        clauses.append(secondary)
    return stmt.order_by(*clauses), sort_by, sort_dir


def with_sort_meta(payload: dict, sort_by: str, sort_dir: str) -> dict:
    payload["sort_by"] = sort_by
    payload["sort_dir"] = sort_dir
    return payload


def ip_of(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    return (forwarded.split(",")[0].strip() if forwarded else (request.client.host if request.client else ""))


def _booking_whatsapp_context(db: Session, booking_id: int):
    row = db.execute(
        select(Booking, Plot, Customer)
        .join(Plot, Plot.id == Booking.plot_id)
        .join(Customer, Customer.id == Booking.customer_id)
        .where(Booking.id == booking_id)
    ).first()
    if not row:
        raise ValueError("Booking not found")
    booking, plot, customer = row
    return booking, plot, customer


def _send_booking_whatsapp(db: Session, booking_id: int, sent_by: str):
    booking, plot, customer = _booking_whatsapp_context(db, booking_id)
    cfg = get_whatsapp_config(db)
    parameters = [
        customer.name, booking.booking_no, plot.plot_no, fmt_money(booking.net_sale_value),
        fmt_money(plot.received), fmt_money(plot.outstanding),
    ]
    return send_template_message(
        db, mobile=customer.mobile, template_name=cfg["booking_template"], parameters=parameters,
        message_type="Booking Confirmation", sent_by=sent_by, customer_id=customer.id, booking_id=booking.id,
    )


def _send_due_whatsapp(db: Session, installment_id: int, sent_by: str):
    row = db.execute(
        select(Installment, Booking, Plot, Customer)
        .join(Booking, Booking.id == Installment.booking_id)
        .join(Plot, Plot.id == Booking.plot_id)
        .join(Customer, Customer.id == Booking.customer_id)
        .where(Installment.id == installment_id)
    ).first()
    if not row:
        raise ValueError("Installment not found")
    ins, booking, plot, customer = row
    due_balance = max(0.0, float(ins.amount or 0) - float(ins.paid or 0))
    if due_balance <= 0:
        raise ValueError("This installment has no outstanding due amount")
    cfg = get_whatsapp_config(db)
    parameters = [
        customer.name, plot.plot_no, ins.due_type, ins.due_date.strftime("%d-%m-%Y"),
        fmt_money(due_balance), fmt_money(plot.outstanding),
    ]
    return send_template_message(
        db, mobile=customer.mobile, template_name=cfg["due_template"], parameters=parameters,
        message_type="Due Reminder", sent_by=sent_by, customer_id=customer.id, booking_id=booking.id, installment_id=ins.id,
    )


def _client_file_context(db: Session, booking_id: int):
    row = db.execute(
        select(Booking, Plot, Customer).join(Plot, Plot.id == Booking.plot_id)
        .join(Customer, Customer.id == Booking.customer_id).where(Booking.id == booking_id)
    ).first()
    if not row:
        raise ValueError("Booking not found")
    return row


def _client_file_defaults(booking: Booking, plot: Plot, customer: Customer) -> dict:
    amount = fmt_money(booking.net_sale_value)
    return {
        "booking_acknowledgment": (
            f"This is to acknowledge the booking of Plot {plot.plot_no} ({plot.category}, {plot.size_marla:g} Marla, {plot.block}) "
            f"in {PROJECT_NAME} in the name of {customer.name}, CNIC {customer.cnic or 'not recorded'}, under Booking No. {booking.booking_no} "
            f"dated {booking.booking_date:%d-%m-%Y}. The agreed net sale value is {amount} under the {booking.payment_plan} payment plan."
        ),
        "payment_acknowledgment": (
            f"The customer acknowledges that all booking, down-payment, confirmation and installment amounts for {booking.booking_no} "
            f"will be paid according to the approved {booking.payment_plan} schedule. Amounts received are reflected in official Horizon ERP receipts only."
        ),
        "terms_and_conditions": (
            "1. This acknowledgement is subject to the approved booking and payment-plan record.\n"
            "2. Payments are valid only against an official receipt issued by the Company.\n"
            "3. Transfer, possession and allotment remain subject to clearance of dues and applicable Company policy.\n"
            "4. Any change to the booking, plot, sale value or schedule requires written Company approval."
        ),
    }


@router.post("/login")
def login(payload: dict, response: Response, request: Request, db: Session = Depends(get_db)):
    username = str(payload.get("username") or "").strip().lower()
    password = str(payload.get("password") or "")
    user = db.scalar(select(User).where(func.lower(User.username) == username, User.active.is_(True)))
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token, token_hash = new_session_token()
    csrf = new_csrf_token()
    db.add(AuthSession(token_hash=token_hash, csrf_token=csrf, user_id=user.id, expires_at=expires_in(SESSION_HOURS)))
    audit(db, user.full_name, "LOGIN", "Security", user.id, "Successful login", ip_of(request))
    db.commit()
    response.set_cookie(
        "horizon_session", token, max_age=SESSION_HOURS * 3600, httponly=True,
        secure=COOKIE_SECURE, samesite="lax", path="/"
    )
    return {"ok": True, "csrf_token": csrf, "user": {"id": user.id, "username": user.username, "full_name": user.full_name, "role": user.role}}


@router.post("/logout")
def logout(response: Response, context=Depends(csrf_protect), db: Session = Depends(get_db)):
    db.delete(db.merge(context["session"]))
    audit(db, context["user"].full_name, "LOGOUT", "Security", context["user"].id)
    db.commit()
    response.delete_cookie("horizon_session", path="/")
    return {"ok": True}


@router.get("/me")
def me(context=Depends(get_current_context), db: Session = Depends(get_db)):
    user = context["user"]
    unread = db.scalar(select(func.count()).select_from(Notification).where(
        Notification.read.is_(False),
        or_(Notification.user_id == user.id, Notification.role == user.role, Notification.role == "")
    )) or 0
    return {
        "app": APP_NAME, "version": APP_VERSION, "csrf_token": context["session"].csrf_token,
        "user": {"id": user.id, "username": user.username, "full_name": user.full_name, "role": user.role, "customer_id": user.customer_id},
        "unread_notifications": unread,
    }


@router.get("/health")
def health(db: Session = Depends(get_db)):
    db.scalar(select(func.count()).select_from(User))
    return {"status": "ok", "app": APP_NAME, "version": APP_VERSION, "time": datetime.utcnow().isoformat()}


@router.get("/migration/runner-status")
def migration_runner_status(context=Depends(require_roles("Admin", "Finance")), db: Session = Depends(get_db)):
    """Expose import state without ever starting a migration from a web request."""
    latest = db.scalar(select(MigrationBatch).order_by(MigrationBatch.id.desc()).limit(1))
    return {
        "startup_execution": "disabled",
        "message": "Financial migrations run only as a separately invoked, one-time controlled job; web startup is never blocked.",
        "latest_batch": model_dict(latest, ["id", "batch_no", "status", "source_rows", "imported_count", "matched_count", "mismatch_count", "created_at"]) if latest else None,
    }


@router.get("/backup/status")
def backup_status(context=Depends(require_roles("Admin")), db: Session = Depends(get_db)):
    from ..core.config import DATABASE_URL
    mode = "local-sqlite" if DATABASE_URL.startswith("sqlite") else "managed-postgresql"
    return {"mode": mode, "restore": "provider-controlled", "message": "PostgreSQL backups/restores must use the managed database provider to avoid exposing credentials or restoring over a live ledger."}


def _maintenance_token_valid(token: str | None) -> bool:
    configured = os.getenv("HORIZON_LEDGER_IMPORT_TOKEN", "")
    return bool(configured) and bool(token) and hmac.compare_digest(token, configured)


@router.post("/maintenance/financial-import/execute", status_code=202)
def execute_financial_import(x_horizon_maintenance_token: str | None = Header(default=None)):
    """Start the separately invoked, approved one-time master-ledger import."""
    if not _maintenance_token_valid(x_horizon_maintenance_token):
        raise HTTPException(status_code=403, detail="Maintenance authorization is required.")
    result = request_import()
    if result["status"] == "queued":
        Thread(target=run_import, name="approved-financial-import", daemon=True).start()
    return result


@router.get("/maintenance/financial-import/status")
def financial_import_status(x_horizon_maintenance_token: str | None = Header(default=None)):
    if not _maintenance_token_valid(x_horizon_maintenance_token):
        raise HTTPException(status_code=403, detail="Maintenance authorization is required.")
    return import_status()


@router.get("/dashboard")
def dashboard(context=Depends(require_roles("Finance", "Sales", "CRM", "Development")), db: Session = Depends(get_db)):
    today_date = date.today()
    month_start = today_date.replace(day=1)
    plot_metrics = db.execute(select(
        func.count(Plot.id),
        func.coalesce(func.sum(case((Plot.status == "Available", 1), else_=0)), 0),
        func.coalesce(func.sum(case((Plot.status == "Reserved", 1), else_=0)), 0),
        func.coalesce(func.sum(case((Plot.status.in_(["Booked", "Sold"]), 1), else_=0)), 0),
        func.coalesce(func.sum(case((Plot.status.in_(["Booked", "Sold"]), Plot.sale_price), else_=0)), 0),
        func.coalesce(func.sum(Plot.received), 0), func.coalesce(func.sum(Plot.outstanding), 0),
    )).one()
    total_plots, available, reserved, booked, sales_value, received, outstanding = plot_metrics
    this_month_receipts = float(db.scalar(select(func.coalesce(func.sum(Receipt.amount), 0)).where(Receipt.receipt_date >= month_start)) or 0)
    overdue = float(db.scalar(select(func.coalesce(func.sum(Installment.amount - Installment.paid), 0)).where(Installment.due_date < today_date, Installment.status.in_(["Due", "Partial"]))) or 0)
    open_leads = db.scalar(select(func.count()).select_from(Lead).where(~Lead.stage.in_(["Won", "Lost"]))) or 0
    avg_progress = float(db.scalar(select(func.coalesce(func.avg(DevelopmentProject.progress_percent), 0))) or 0)
    dev_budget = float(db.scalar(select(func.coalesce(func.sum(DevelopmentProject.budget), 0))) or 0)
    dev_actual = float(db.scalar(select(func.coalesce(func.sum(DevelopmentProject.actual_cost), 0))) or 0)

    months = []
    for offset in range(5, -1, -1):
        year = today_date.year
        month = today_date.month - offset
        while month <= 0:
            month += 12
            year -= 1
        months.append(date(year, month, 1))
    window_start = months[0]
    window_end = date(months[-1].year + (months[-1].month == 12), 1 if months[-1].month == 12 else months[-1].month + 1, 1)
    receipt_months = {(int(y), int(m)): float(amount or 0) for y, m, amount in db.execute(
        select(func.extract("year", Receipt.receipt_date), func.extract("month", Receipt.receipt_date), func.sum(Receipt.amount))
        .where(Receipt.receipt_date >= window_start, Receipt.receipt_date < window_end)
        .group_by(func.extract("year", Receipt.receipt_date), func.extract("month", Receipt.receipt_date))
    )}
    installment_months = {(int(y), int(m)): float(amount or 0) for y, m, amount in db.execute(
        select(func.extract("year", Installment.due_date), func.extract("month", Installment.due_date), func.sum(Installment.amount))
        .where(Installment.due_date >= window_start, Installment.due_date < window_end)
        .group_by(func.extract("year", Installment.due_date), func.extract("month", Installment.due_date))
    )}
    monthly = [{"month": start.strftime("%b %Y"), "expected": installment_months.get((start.year, start.month), 0), "actual": receipt_months.get((start.year, start.month), 0)} for start in months]
    return {
        "kpis": {
            "total_plots": int(total_plots or 0), "available": int(available or 0), "reserved": int(reserved or 0), "booked_sold": int(booked or 0),
            "sales_value": float(sales_value or 0), "received": float(received or 0), "outstanding": float(outstanding or 0),
            "this_month_receipts": this_month_receipts, "overdue": overdue, "open_leads": open_leads,
            "development_progress": avg_progress, "development_budget": dev_budget, "development_actual": dev_actual,
        },
        "monthly_collections": monthly,
        "plot_mix": [
            {"label": "Available", "value": available}, {"label": "Reserved", "value": reserved}, {"label": "Booked/Sold", "value": booked},
        ],
    }


# ---------------- Customer Master ----------------
@router.get("/customers")
def list_customers(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    filters = []
    if q:
        pattern = f"%{q}%"
        filters.append(or_(Customer.name.ilike(pattern), Customer.code.ilike(pattern), Customer.cnic.ilike(pattern), Customer.mobile.ilike(pattern)))
    stmt = select(Customer).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "code": Customer.code, "name": Customer.name, "cnic": Customer.cnic, "mobile": Customer.mobile,
        "email": Customer.email, "address": Customer.address, "status": Customer.status, "created_at": Customer.created_at,
    }, "id" if False else "name", "asc", secondary=Customer.id.asc())
    count_stmt = select(func.count()).select_from(Customer).where(*filters)
    rows = db.scalars(stmt.offset((page - 1) * size).limit(size)).all()
    total = db.scalar(count_stmt) or 0
    fields = ["id", "code", "name", "father_name", "cnic", "mobile", "email", "address", "status", "version", "created_at", "updated_at"]
    return {"items": [model_dict(r, fields) for r in rows], "total": total, "page": page, "size": size}


@router.post("/customers")
def add_customer(payload: dict, request: Request, context=Depends(csrf_roles("Sales", "CRM", "Finance")), db: Session = Depends(get_db)):
    try:
        name = str(payload.get("name") or "").strip()
        if not name:
            raise ValueError("Customer name is required")
        code = str(payload.get("code") or next_number(db, Customer, Customer.code, "CUS"))
        if db.scalar(select(Customer).where(Customer.code == code)):
            raise ValueError("Customer code already exists")
        customer = Customer(
            code=code, name=name, father_name=str(payload.get("father_name") or ""), cnic=str(payload.get("cnic") or ""),
            mobile=str(payload.get("mobile") or ""), email=str(payload.get("email") or ""), address=str(payload.get("address") or ""), status=str(payload.get("status") or "Active")
        )
        db.add(customer); db.flush()
        audit(db, context["user"].full_name, "CREATE", "Customers", customer.id, payload, ip_of(request)); db.commit()
        return {"ok": True, "id": customer.id, "code": customer.code}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.patch("/customers/{customer_id}")
def edit_customer(customer_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Sales", "CRM", "Finance")), db: Session = Depends(get_db)):
    customer = db.get(Customer, customer_id)
    if not customer: raise HTTPException(404, "Customer not found")
    expected = int(payload.pop("version", customer.version))
    if expected != customer.version: raise HTTPException(409, "This record was changed by another user. Refresh and try again.")
    allowed = ["name", "father_name", "cnic", "mobile", "email", "address", "status"]
    before = model_dict(customer, allowed)
    for field in allowed:
        if field in payload: setattr(customer, field, str(payload[field] or ""))
    if not customer.name.strip(): error(ValueError("Customer name is required"))
    customer.version += 1
    audit(db, context["user"].full_name, "UPDATE", "Customers", customer.id, {"before": before, "after": model_dict(customer, allowed)}, ip_of(request)); db.commit()
    return {"ok": True, "version": customer.version}


# ---------------- Plot Inventory & Reservation ----------------
@router.get("/plots")
def list_plots(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM", "Development")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    status = request.query_params.get("status", "")
    filters = []
    if q:
        pattern = f"%{q}%"
        filters.append(or_(Plot.plot_no.ilike(pattern), Plot.chz_no.ilike(pattern), Customer.name.ilike(pattern)))
    if status: filters.append(Plot.status == status)
    stmt = select(Plot, Customer.name.label("customer_name")).outerjoin(Customer, Customer.id == Plot.customer_id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "plot_no": lambda d: [func.length(Plot.plot_no).asc() if d == "asc" else func.length(Plot.plot_no).desc(), Plot.plot_no.asc() if d == "asc" else Plot.plot_no.desc()],
        "category": Plot.category, "size_marla": Plot.size_marla, "block": Plot.block, "status": Plot.status,
        "customer_name": Customer.name, "list_price": Plot.list_price, "sale_price": Plot.sale_price,
        "received": Plot.received, "outstanding": Plot.outstanding, "chz_no": Plot.chz_no,
    }, "plot_no", "asc", secondary=Plot.id.asc())
    count_stmt = select(func.count()).select_from(Plot).outerjoin(Customer, Customer.id == Plot.customer_id).where(*filters)
    rows, total = paginated(db, stmt, count_stmt, page, size)
    items = []
    for plot, customer_name in rows:
        item = model_dict(plot, ["id", "plot_no", "block", "category", "size_marla", "status", "list_price", "sale_price", "chz_no", "customer_id", "received", "outstanding", "payment_status", "remarks", "version"])
        item["customer_name"] = customer_name or ""
        items.append(item)
    return {"items": items, "total": total, "page": page, "size": size}


@router.post("/plots")
def add_plot(payload: dict, request: Request, context=Depends(csrf_roles("Sales")), db: Session = Depends(get_db)):
    try:
        plot_no = str(payload.get("plot_no") or "").strip()
        if not plot_no: raise ValueError("Plot number is required")
        if db.scalar(select(Plot).where(Plot.plot_no == plot_no)): raise ValueError("Plot number already exists")
        plot = Plot(
            plot_no=plot_no, block=str(payload.get("block") or ""), category=str(payload.get("category") or "Residential"),
            size_marla=as_float(payload.get("size_marla")), status="Available", list_price=as_float(payload.get("list_price")),
            chz_no=str(payload.get("chz_no") or ""), payment_status="Not Sold", remarks=str(payload.get("remarks") or "")
        )
        db.add(plot); db.flush(); audit(db, context["user"].full_name, "CREATE", "Plots", plot.id, payload, ip_of(request)); db.commit()
        return {"ok": True, "id": plot.id}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.patch("/plots/{plot_id}")
def edit_plot(plot_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Sales", "Development")), db: Session = Depends(get_db)):
    plot = db.get(Plot, plot_id)
    if not plot: raise HTTPException(404, "Plot not found")
    expected = int(payload.pop("version", plot.version))
    if expected != plot.version: raise HTTPException(409, "This record was changed by another user. Refresh and try again.")
    forbidden = {"sale_price", "received", "outstanding", "customer_id", "status", "payment_status"}
    if forbidden.intersection(payload): raise HTTPException(400, "Financial and status fields must be changed through booking, reservation, receipt, or sale-amendment transactions")
    allowed = ["block", "category", "size_marla", "list_price", "chz_no", "remarks"]
    before = model_dict(plot, allowed)
    for field in allowed:
        if field in payload:
            setattr(plot, field, as_float(payload[field]) if field in {"size_marla", "list_price"} else str(payload[field] or ""))
    plot.version += 1
    audit(db, context["user"].full_name, "UPDATE", "Plots", plot.id, {"before": before, "after": model_dict(plot, allowed)}, ip_of(request)); db.commit()
    return {"ok": True, "version": plot.version}


@router.get("/reservations")
def list_reservations(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(Reservation.reservation_no.ilike(p), Plot.plot_no.ilike(p), Customer.name.ilike(p)))
    stmt = select(Reservation, Plot.plot_no, Customer.name).join(Plot, Plot.id == Reservation.plot_id).join(Customer, Customer.id == Reservation.customer_id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "reservation_no": Reservation.reservation_no, "reservation_date": Reservation.reservation_date, "plot_no": Plot.plot_no,
        "customer_name": Customer.name, "amount": Reservation.amount, "expiry_date": Reservation.expiry_date,
        "payment_mode": Reservation.payment_mode, "dealer_name": Reservation.dealer_name, "status": Reservation.status,
    }, "reservation_date", "desc", secondary=Reservation.id.desc())
    count_stmt = select(func.count()).select_from(Reservation).join(Plot).join(Customer).where(*filters)
    rows, total = paginated(db, stmt, count_stmt, page, size)
    items = []
    for r, plot_no, customer_name in rows:
        x = model_dict(r, ["id", "reservation_no", "reservation_date", "expiry_date", "plot_id", "customer_id", "amount", "refundable", "payment_mode", "reference", "dealer_name", "status", "remarks", "version"])
        x.update(plot_no=plot_no, customer_name=customer_name); items.append(x)
    return {"items": items, "total": total, "page": page, "size": size}


@router.post("/reservations")
def add_reservation(payload: dict, request: Request, context=Depends(csrf_roles("Sales")), db: Session = Depends(get_db)):
    try:
        r = reserve_plot(db, payload, context["user"].full_name, ip_of(request)); db.commit(); return {"ok": True, "id": r.id, "reservation_no": r.reservation_no}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.post("/reservations/{reservation_id}/release")
def release_reservation_api(reservation_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Sales", "Finance")), db: Session = Depends(get_db)):
    try:
        r = release_reservation(db, reservation_id, str(payload.get("reason") or "Released by management"), context["user"].full_name, ip_of(request)); db.commit(); return {"ok": True, "id": r.id}
    except ValueError as exc:
        db.rollback(); error(exc)


# ---------------- Bookings, Receipts, Installments ----------------
@router.get("/bookings")
def list_bookings(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(Booking.booking_no.ilike(p), Plot.plot_no.ilike(p), Customer.name.ilike(p), Booking.dealer_name.ilike(p), Booking.payment_plan.ilike(p), Booking.status.ilike(p)))

    # V18: allow-listed server-side sorting keeps ordering correct across all pages.
    sort_map = {
        "booking_no": Booking.booking_no,
        "booking_date": Booking.booking_date,
        "plot_no": Plot.plot_no,
        "customer_name": Customer.name,
        "payment_plan": Booking.payment_plan,
        "sale_price": Booking.sale_price,
        "discount": Booking.discount,
        "net_sale_value": Booking.net_sale_value,
        "dealer_name": Booking.dealer_name,
        "status": Booking.status,
    }
    sort_by = request.query_params.get("sort_by", "booking_date").strip()
    if sort_by not in sort_map:
        sort_by = "booking_date"
    sort_dir = request.query_params.get("sort_dir", "desc").strip().lower()
    if sort_dir not in {"asc", "desc"}:
        sort_dir = "desc"
    sort_column = sort_map[sort_by]
    if sort_by == "plot_no":
        # Natural ordering for numeric-looking plot numbers: 2 comes before 10.
        order_clauses = [
            func.length(Plot.plot_no).asc() if sort_dir == "asc" else func.length(Plot.plot_no).desc(),
            Plot.plot_no.asc() if sort_dir == "asc" else Plot.plot_no.desc(),
        ]
    else:
        order_clauses = [sort_column.asc() if sort_dir == "asc" else sort_column.desc()]

    stmt = (
        select(Booking, Plot.plot_no, Customer.name, Plot.received, Plot.outstanding)
        .join(Plot, Plot.id == Booking.plot_id)
        .join(Customer, Customer.id == Booking.customer_id)
        .where(*filters)
        .order_by(*order_clauses, desc(Booking.id))
    )
    count_stmt = select(func.count()).select_from(Booking).join(Plot).join(Customer).where(*filters)
    rows, total = paginated(db, stmt, count_stmt, page, size)
    items = []
    for b, plot_no, customer_name, received, outstanding in rows:
        x = model_dict(b, ["id", "booking_no", "booking_date", "customer_id", "plot_id", "sale_price", "discount", "net_sale_value", "payment_plan", "dealer_name", "status", "reservation_id", "version"])
        plan_assignment = db.scalar(select(BookingPaymentPlan).where(BookingPaymentPlan.booking_id == b.id))
        x.update(plot_no=plot_no, customer_name=customer_name, received=float(received or 0), outstanding=float(outstanding or 0), plan_template_id=(plan_assignment.template_id if plan_assignment else None)); items.append(x)
    return {"items": items, "total": total, "page": page, "size": size, "sort_by": sort_by, "sort_dir": sort_dir}


@router.post("/bookings")
def add_booking(payload: dict, request: Request, context=Depends(csrf_roles("Sales", "Finance")), db: Session = Depends(get_db)):
    try:
        b = create_booking(db, payload, context["user"].full_name, ip_of(request))
        booking, plot, customer = _client_file_context(db, b.id)
        client_file = ClientFile(
            booking_id=b.id, customer_id=customer.id, file_no=f"CF-{b.booking_no}",
            prepared_by=context["user"].full_name,
            **_client_file_defaults(booking, plot, customer),
        )
        db.add(client_file); db.flush()
        db.add(Document(module="Client File", record_id=client_file.id, document_type="Client File Set",
                        file_name=f"{client_file.file_no}.pdf", storage_url=f"/api/client-files/{client_file.id}/pdf",
                        uploaded_by=context["user"].full_name))
        whatsapp = {"attempted": False, "status": "Not sent"}
        cfg = get_whatsapp_config(db)
        if cfg.get("enabled") and cfg.get("auto_booking"):
            whatsapp["attempted"] = True
            try:
                log = _send_booking_whatsapp(db, b.id, context["user"].full_name)
                whatsapp.update(status=log.status, message_id=log.provider_message_id)
            except Exception as wa_exc:
                whatsapp.update(status="Failed", error=str(wa_exc))
                db.add(Notification(role="Admin", title="WhatsApp booking notification failed", message=f"{b.booking_no}: {wa_exc}", link="#bookings"))
        db.commit()
        return {"ok": True, "id": b.id, "booking_no": b.booking_no, "client_file_id": client_file.id, "whatsapp": whatsapp}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.patch("/bookings/{booking_id}")
def edit_booking_details_api(booking_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Sales", "Finance")), db: Session = Depends(get_db)):
    try:
        b = update_booking_details(db, booking_id, payload, context["user"].full_name, ip_of(request))
        db.commit()
        return {"ok": True, "id": b.id, "booking_no": b.booking_no, "version": b.version}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.post("/bookings/{booking_id}/amend-sale")
def amend_booking_sale(booking_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    try:
        b = amend_sale_value(db, booking_id, as_float(payload.get("new_net_value")), str(payload.get("reason") or "Approved correction"), context["user"].full_name, ip_of(request)); db.commit(); return {"ok": True, "id": b.id, "new_net_value": float(b.net_sale_value)}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.get("/receipts")
def list_receipts(request: Request, context=Depends(require_roles("Finance", "Sales")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(Receipt.receipt_no.ilike(p), Plot.plot_no.ilike(p), Customer.name.ilike(p), Receipt.reference.ilike(p)))
    stmt = select(Receipt, Booking.booking_no, Plot.plot_no, Customer.name).join(Booking, Booking.id == Receipt.booking_id).join(Plot, Plot.id == Booking.plot_id).join(Customer, Customer.id == Receipt.customer_id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "receipt_no": Receipt.receipt_no, "receipt_date": Receipt.receipt_date, "booking_no": Booking.booking_no,
        "plot_no": Plot.plot_no, "customer_name": Customer.name, "amount": Receipt.amount, "mode": Receipt.mode, "reference": Receipt.reference, "narration": Receipt.narration,
    }, "receipt_date", "desc", secondary=Receipt.id.desc())
    count_stmt = select(func.count()).select_from(Receipt).join(Booking).join(Plot).join(Customer).where(*filters)
    rows, total = paginated(db, stmt, count_stmt, page, size)
    items = []
    for r, booking_no, plot_no, customer_name in rows:
        x = model_dict(r, ["id", "receipt_no", "receipt_date", "booking_id", "customer_id", "amount", "mode", "reference", "narration", "version"])
        x.update(booking_no=booking_no, plot_no=plot_no, customer_name=customer_name); items.append(x)
    return {"items": items, "total": total, "page": page, "size": size}


@router.post("/receipts")
def add_receipt(payload: dict, request: Request, context=Depends(csrf_roles("Finance", "Sales")), db: Session = Depends(get_db)):
    try:
        r = create_receipt(db, payload, context["user"].full_name, ip_of(request)); db.commit(); return {"ok": True, "id": r.id, "receipt_no": r.receipt_no}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.get("/installments")
def list_installments(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    status = request.query_params.get("status", "")
    filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(Booking.booking_no.ilike(p), Plot.plot_no.ilike(p), Customer.name.ilike(p)))
    if status: filters.append(Installment.status == status)
    stmt = select(Installment, Booking.booking_no, Plot.plot_no, Customer.name, Customer.mobile, Plot.outstanding).join(Booking, Booking.id == Installment.booking_id).join(Plot, Plot.id == Booking.plot_id).join(Customer, Customer.id == Booking.customer_id).where(*filters)
    balance_expr = Installment.amount - Installment.paid
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "due_date": Installment.due_date, "due_no": Installment.due_no, "booking_no": Booking.booking_no, "plot_no": Plot.plot_no,
        "customer_name": Customer.name, "due_type": Installment.due_type, "amount": Installment.amount, "paid": Installment.paid,
        "balance": balance_expr, "status": Installment.status,
    }, "due_date", "asc", secondary=Installment.due_no.asc())
    count_stmt = select(func.count()).select_from(Installment).join(Booking).join(Plot).join(Customer).where(*filters)
    rows, total = paginated(db, stmt, count_stmt, page, size)
    items = []
    today = date.today()
    for i, booking_no, plot_no, customer_name, customer_mobile, plot_outstanding in rows:
        status_value = i.status
        if i.due_date < today and i.status in {"Due", "Partial"}: status_value = "Overdue"
        x = model_dict(i, ["id", "booking_id", "due_no", "due_date", "due_type", "amount", "paid", "version"])
        x.update(status=status_value, balance=float(i.amount) - float(i.paid), booking_no=booking_no, plot_no=plot_no, customer_name=customer_name, customer_mobile=customer_mobile or "", plot_outstanding=float(plot_outstanding or 0)); items.append(x)
    return {"items": items, "total": total, "page": page, "size": size}


@router.get("/forecast")
def collection_forecast(context=Depends(require_roles("Finance", "Sales")), db: Session = Depends(get_db)):
    start = date.today().replace(day=1)
    result = []
    for offset in range(12):
        month = start.month - 1 + offset
        year = start.year + month // 12; month = month % 12 + 1
        period_start = date(year, month, 1)
        period_end = date(year + (month == 12), 1 if month == 12 else month + 1, 1)
        expected = float(db.scalar(select(func.coalesce(func.sum(Installment.amount - Installment.paid), 0)).where(Installment.due_date >= period_start, Installment.due_date < period_end)) or 0)
        actual = float(db.scalar(select(func.coalesce(func.sum(Receipt.amount), 0)).where(Receipt.receipt_date >= period_start, Receipt.receipt_date < period_end)) or 0)
        result.append({"month": period_start.strftime("%b %Y"), "expected": expected, "actual": actual, "variance": actual - expected})
    return {"items": result}



# ---------------- Receivables / Aging / Forecast ----------------
def _receivable_category(due_type: str) -> str:
    text = str(due_type or "").strip().lower()
    if "confirm" in text:
        return "Confirmation"
    if "booking" in text or "down payment" in text or text in {"downpayment", "down-payment"}:
        return "Booking / Down Payment"
    if "monthly" in text or "installment" in text or "instalment" in text:
        return "Monthly Installment"
    if "bulk" in text:
        return "Bulk Payment"
    if "possess" in text:
        return "Possession"
    if "full" in text:
        return "Full Payment"
    return "Other"


def _next_month(d: date) -> date:
    return date(d.year + (1 if d.month == 12 else 0), 1 if d.month == 12 else d.month + 1, 1)


def _receivable_rows(db: Session):
    rows = db.execute(
        select(Installment, Booking.booking_no, Plot.id, Plot.plot_no, Customer.id, Customer.name)
        .join(Booking, Booking.id == Installment.booking_id)
        .join(Plot, Plot.id == Booking.plot_id)
        .join(Customer, Customer.id == Booking.customer_id)
        .where(Booking.status == "Posted")
        .order_by(Installment.due_date, Plot.plot_no, Installment.due_no)
    ).all()
    result = []
    for ins, booking_no, plot_id, plot_no, customer_id, customer_name in rows:
        amount = round(float(ins.amount or 0), 2)
        paid = round(float(ins.paid or 0), 2)
        balance = max(0.0, round(amount - paid, 2))
        result.append({
            "installment_id": ins.id,
            "booking_id": ins.booking_id,
            "booking_no": booking_no,
            "plot_id": plot_id,
            "plot_no": plot_no,
            "customer_id": customer_id,
            "customer_name": customer_name,
            "due_no": ins.due_no,
            "due_date": ins.due_date,
            "due_type": ins.due_type,
            "category": _receivable_category(ins.due_type),
            "amount": amount,
            "paid": paid,
            "balance": balance,
        })
    return result


def _build_receivable_report(db: Session, from_date: date, to_date_: date, group_by: str, category: str = "All") -> dict:
    if to_date_ < from_date:
        raise ValueError("To date cannot be earlier than From date")
    if group_by not in {"month", "year", "plot"}:
        raise ValueError("Group by must be month, year, or plot")
    allowed_categories = {"All", "Booking / Down Payment", "Confirmation", "Monthly Installment", "Bulk Payment", "Possession", "Full Payment", "Other"}
    if category not in allowed_categories:
        raise ValueError("Unsupported due category")
    rows = [x for x in _receivable_rows(db) if x["balance"] > 0.005 and from_date <= x["due_date"] <= to_date_ and (category == "All" or x["category"] == category)]
    grouped: dict[str, dict] = {}
    for x in rows:
        if group_by == "month":
            key = x["due_date"].strftime("%Y-%m")
            label = x["due_date"].strftime("%b %Y")
        elif group_by == "year":
            key = str(x["due_date"].year)
            label = key
        else:
            key = str(x["plot_id"])
            label = f"Plot {x['plot_no']}"
        g = grouped.setdefault(key, {
            "key": key, "label": label, "plot_no": x["plot_no"] if group_by == "plot" else "",
            "booking_no": x["booking_no"] if group_by == "plot" else "",
            "customer_name": x["customer_name"] if group_by == "plot" else "",
            "receivable": 0.0, "installments": 0, "plots": set(),
            "booking_due": 0.0, "confirmation_due": 0.0, "monthly_due": 0.0, "other_due": 0.0,
        })
        g["receivable"] = round(g["receivable"] + x["balance"], 2)
        g["installments"] += 1
        g["plots"].add(x["plot_id"])
        if x["category"] == "Booking / Down Payment": g["booking_due"] = round(g["booking_due"] + x["balance"], 2)
        elif x["category"] == "Confirmation": g["confirmation_due"] = round(g["confirmation_due"] + x["balance"], 2)
        elif x["category"] == "Monthly Installment": g["monthly_due"] = round(g["monthly_due"] + x["balance"], 2)
        else: g["other_due"] = round(g["other_due"] + x["balance"], 2)
    items = []
    for g in grouped.values():
        g["plots"] = len(g["plots"])
        items.append(g)
    if group_by in {"month", "year"}:
        items.sort(key=lambda x: x["key"])
    else:
        def plot_sort_key(x):
            import re
            m = re.match(r"^(\d+)(.*)$", str(x.get("plot_no") or ""))
            return (int(m.group(1)) if m else 10**9, (m.group(2) if m else str(x.get("plot_no") or "")))
        items.sort(key=plot_sort_key)
    return {
        "from_date": from_date.isoformat(), "to_date": to_date_.isoformat(), "group_by": group_by, "category": category,
        "summary": {"receivable": round(sum(x["balance"] for x in rows), 2), "installments": len(rows), "plots": len({x["plot_id"] for x in rows})},
        "items": items,
    }


@router.get("/receivables/overview")
def receivables_overview(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    as_of = to_date(request.query_params.get("as_of") or date.today())
    month_start = as_of.replace(day=1)
    month_end = _next_month(month_start) - timedelta(days=1)
    rows = [x for x in _receivable_rows(db) if x["balance"] > 0.005]
    overdue = [x for x in rows if x["due_date"] < as_of]
    due_through_month = [x for x in rows if x["due_date"] <= month_end]
    current_month = [x for x in rows if month_start <= x["due_date"] <= month_end]
    future_after_month = [x for x in rows if x["due_date"] > month_end]
    booking_overdue = [x for x in overdue if x["category"] == "Booking / Down Payment"]
    confirmation_overdue = [x for x in overdue if x["category"] == "Confirmation"]
    plot_map: dict[int, dict] = {}
    for x in rows:
        p = plot_map.setdefault(x["plot_id"], {
            "plot_id": x["plot_id"], "plot_no": x["plot_no"], "booking_no": x["booking_no"], "customer_name": x["customer_name"],
            "booking_overdue": 0.0, "confirmation_overdue": 0.0, "installment_overdue": 0.0, "other_overdue": 0.0,
            "total_overdue": 0.0, "due_through_month": 0.0, "total_outstanding": 0.0,
        })
        p["total_outstanding"] = round(p["total_outstanding"] + x["balance"], 2)
        if x["due_date"] <= month_end:
            p["due_through_month"] = round(p["due_through_month"] + x["balance"], 2)
        if x["due_date"] < as_of:
            p["total_overdue"] = round(p["total_overdue"] + x["balance"], 2)
            if x["category"] == "Booking / Down Payment": p["booking_overdue"] = round(p["booking_overdue"] + x["balance"], 2)
            elif x["category"] == "Confirmation": p["confirmation_overdue"] = round(p["confirmation_overdue"] + x["balance"], 2)
            elif x["category"] == "Monthly Installment": p["installment_overdue"] = round(p["installment_overdue"] + x["balance"], 2)
            else: p["other_overdue"] = round(p["other_overdue"] + x["balance"], 2)
    plot_items = sorted(plot_map.values(), key=lambda x: (-x["total_overdue"], str(x["plot_no"])))
    return {
        "as_of": as_of.isoformat(), "month_start": month_start.isoformat(), "month_end": month_end.isoformat(), "month_label": month_start.strftime("%B %Y"),
        "summary": {
            "total_outstanding": round(sum(x["balance"] for x in rows), 2),
            "due_through_current_month": round(sum(x["balance"] for x in due_through_month), 2),
            "overdue_as_of_date": round(sum(x["balance"] for x in overdue), 2),
            "current_month_due": round(sum(x["balance"] for x in current_month), 2),
            "future_after_current_month": round(sum(x["balance"] for x in future_after_month), 2),
            "booking_overdue": round(sum(x["balance"] for x in booking_overdue), 2),
            "confirmation_overdue": round(sum(x["balance"] for x in confirmation_overdue), 2),
            "overdue_plots": len({x["plot_id"] for x in overdue}),
        },
        "plots": plot_items,
    }


@router.get("/receivables/report")
def receivables_report(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    start = to_date(request.query_params.get("from_date") or date.today())
    default_end = date(start.year + (1 if start.month == 12 else 0), 1 if start.month == 12 else start.month + 1, 1)
    for _ in range(11):
        default_end = _next_month(default_end)
    default_end = _next_month(default_end) - timedelta(days=1)
    end = to_date(request.query_params.get("to_date") or default_end)
    group_by = str(request.query_params.get("group_by") or "month").lower()
    category = str(request.query_params.get("category") or "All")
    try:
        return _build_receivable_report(db, start, end, group_by, category)
    except ValueError as exc:
        error(exc)


@router.get("/receivables/export.csv")
def receivables_export_csv(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    start = to_date(request.query_params.get("from_date") or date.today())
    end = to_date(request.query_params.get("to_date") or (_next_month(start) - timedelta(days=1)))
    group_by = str(request.query_params.get("group_by") or "month").lower()
    category = str(request.query_params.get("category") or "All")
    try:
        data = _build_receivable_report(db, start, end, group_by, category)
    except ValueError as exc:
        error(exc)
    out = StringIO(); writer = csv.writer(out)
    writer.writerow(["Horizon Homes Receivable Forecast"])
    writer.writerow(["From", data["from_date"], "To", data["to_date"], "Group By", group_by, "Category", category])
    writer.writerow(["Forecast Receivable", f"{data['summary']['receivable']:.2f}", "Installments", data['summary']['installments'], "Plots", data['summary']['plots']])
    writer.writerow([])
    if group_by == "plot":
        writer.writerow(["Plot", "Booking", "Customer", "Booking / Down Payment", "Confirmation", "Monthly", "Other", "Forecast Receivable", "Installments"])
        for x in data["items"]:
            writer.writerow([x["plot_no"], x["booking_no"], x["customer_name"], x["booking_due"], x["confirmation_due"], x["monthly_due"], x["other_due"], x["receivable"], x["installments"]])
    else:
        writer.writerow(["Period", "Forecast Receivable", "Plots", "Installments", "Booking / Down Payment", "Confirmation", "Monthly", "Other"])
        for x in data["items"]:
            writer.writerow([x["label"], x["receivable"], x["plots"], x["installments"], x["booking_due"], x["confirmation_due"], x["monthly_due"], x["other_due"]])
    payload = out.getvalue().encode("utf-8-sig")
    filename = f"Horizon_Receivable_Forecast_{data['from_date']}_to_{data['to_date']}.csv"
    return StreamingResponse(iter([payload]), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{filename}"'})

# ---------------- CRM ----------------
@router.get("/leads")
def list_leads(request: Request, context=Depends(require_roles("Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request); filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(Lead.lead_no.ilike(p), Lead.name.ilike(p), Lead.mobile.ilike(p), Lead.stage.ilike(p)))
    stmt = select(Lead).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "lead_no": Lead.lead_no, "name": Lead.name, "mobile": Lead.mobile, "source": Lead.source, "interest": Lead.interest,
        "budget": Lead.budget, "stage": Lead.stage, "assigned_to": Lead.assigned_to, "next_followup": Lead.next_followup,
    }, "next_followup", "asc", secondary=Lead.id.desc())
    count_stmt = select(func.count()).select_from(Lead).where(*filters)
    rows = db.scalars(stmt.offset((page - 1) * size).limit(size)).all(); total = db.scalar(count_stmt) or 0
    fields = ["id", "lead_no", "lead_date", "name", "mobile", "source", "interest", "budget", "stage", "assigned_to", "next_followup", "remarks", "version"]
    return {"items": [model_dict(x, fields) for x in rows], "total": total, "page": page, "size": size}


@router.post("/leads")
def add_lead(payload: dict, request: Request, context=Depends(csrf_roles("Sales", "CRM")), db: Session = Depends(get_db)):
    name = str(payload.get("name") or "").strip(); mobile = str(payload.get("mobile") or "").strip()
    if not name or not mobile: raise HTTPException(400, "Lead name and mobile are required")
    lead = Lead(
        lead_no=next_number(db, Lead, Lead.lead_no, "LEAD"), lead_date=to_date(payload.get("lead_date") or date.today()),
        name=name, mobile=mobile, source=str(payload.get("source") or "Walk-in"), interest=str(payload.get("interest") or "3 Marla Residential"),
        budget=as_float(payload.get("budget")), stage=str(payload.get("stage") or "New"), assigned_to=str(payload.get("assigned_to") or context["user"].full_name),
        next_followup=to_date(payload["next_followup"]) if payload.get("next_followup") else None, remarks=str(payload.get("remarks") or "")
    )
    db.add(lead); db.flush(); audit(db, context["user"].full_name, "CREATE", "CRM", lead.id, payload, ip_of(request)); db.commit()
    return {"ok": True, "id": lead.id, "lead_no": lead.lead_no}


@router.patch("/leads/{lead_id}")
def edit_lead(lead_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Sales", "CRM")), db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead: raise HTTPException(404, "Lead not found")
    expected = int(payload.pop("version", lead.version))
    if expected != lead.version: raise HTTPException(409, "Record changed by another user")
    allowed = ["name", "mobile", "source", "interest", "budget", "stage", "assigned_to", "next_followup", "remarks"]
    before = model_dict(lead, allowed)
    for field in allowed:
        if field in payload:
            if field == "budget": value = as_float(payload[field])
            elif field == "next_followup": value = to_date(payload[field]) if payload[field] else None
            else: value = str(payload[field] or "")
            setattr(lead, field, value)
    lead.version += 1; audit(db, context["user"].full_name, "UPDATE", "CRM", lead.id, {"before": before, "after": model_dict(lead, allowed)}, ip_of(request)); db.commit()
    return {"ok": True, "version": lead.version}


@router.post("/leads/{lead_id}/activities")
def add_activity(lead_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Sales", "CRM")), db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead: raise HTTPException(404, "Lead not found")
    activity = CRMActivity(lead_id=lead.id, activity_type=str(payload.get("activity_type") or "Call"), outcome=str(payload.get("outcome") or ""), next_followup=to_date(payload["next_followup"]) if payload.get("next_followup") else None, user_name=context["user"].full_name)
    db.add(activity)
    if activity.next_followup: lead.next_followup = activity.next_followup
    if payload.get("stage"): lead.stage = str(payload["stage"])
    audit(db, context["user"].full_name, "ADD_ACTIVITY", "CRM", lead.id, payload, ip_of(request)); db.commit()
    return {"ok": True, "id": activity.id}




# ---------------- Project Overview ----------------
PROJECT_SOURCE_DIR = BASE_DIR / "data" / "project_sources"


def _project_profile_payload(db: Session, project: ProjectProfile):
    try:
        boundary = normalize_coordinates(json.loads(project.boundary_json or "[]"))
    except Exception:
        boundary = []
    try:
        original_boundary = normalize_coordinates(json.loads(project.original_boundary_json or "[]"))
    except Exception:
        original_boundary = boundary
    try:
        landowners = json.loads(project.landowners_json or "[]")
    except Exception:
        landowners = []

    marla_sqft = float(project.marla_sqft or 225)
    current_metrics = area_metrics(boundary, marla_sqft) if boundary else {"sqm": 0.0, "marla": 0.0, "kanal": 0.0}
    source_metrics = area_metrics(original_boundary, 225.0) if original_boundary else current_metrics

    plot_status = {str(status or "Unknown"): int(count or 0) for status, count in db.execute(
        select(Plot.status, func.count(Plot.id)).group_by(Plot.status)
    ).all()}
    plot_category = {str(category or "Unknown"): int(count or 0) for category, count in db.execute(
        select(Plot.category, func.count(Plot.id)).group_by(Plot.category)
    ).all()}
    total_plots = sum(plot_category.values())
    total_sales = float(db.scalar(select(func.coalesce(func.sum(Booking.net_sale_value), 0)).where(Booking.status != "Cancelled")) or 0)
    total_collections = float(db.scalar(select(func.coalesce(func.sum(Receipt.amount), 0))) or 0)
    total_outstanding = float(db.scalar(select(func.coalesce(func.sum(Plot.outstanding), 0))) or 0)
    dev = db.execute(select(
        func.coalesce(func.avg(DevelopmentProject.progress_percent), 0),
        func.coalesce(func.sum(DevelopmentProject.budget), 0),
        func.coalesce(func.sum(DevelopmentProject.actual_cost), 0),
    )).one()

    land_account = db.scalar(select(Account).where(func.lower(Account.name) == "land inventory - horizon homes"))
    land_recorded = 0.0
    if land_account:
        land_recorded = float(db.scalar(
            select(func.coalesce(func.sum(VoucherLine.debit - VoucherLine.credit), 0))
            .join(Voucher, Voucher.id == VoucherLine.voucher_id)
            .where(VoucherLine.account_id == land_account.id, Voucher.status == "Posted")
        ) or 0)

    landuse_total = sum(float(x or 0) for x in [
        project.residential_area_marla, project.commercial_area_marla,
        project.public_building_area_marla, project.roads_parking_area_marla
    ])
    legal = float(project.legal_area_marla or 0)
    current = float(project.official_area_marla or 0)
    kmz_source = float(source_metrics["marla"] or 0)
    checks = []
    if project.deed_location.strip().lower() != project.layout_location.strip().lower():
        checks.append({"level": "Review", "title": "Location wording differs between source documents", "detail": f"Deed: {project.deed_location} | Layout: {project.layout_location}"})
    if abs(landuse_total - float(project.layout_area_marla or 0)) > 0.5:
        checks.append({"level": "Review", "title": "Planning land-use total differs from layout area", "detail": f"Land-use total {landuse_total/20:.2f} K vs layout {float(project.layout_area_marla or 0)/20:.2f} K"})
    if plot_category.get("Residential", 0) != 96 or plot_category.get("Commercial", 0) != 6:
        checks.append({"level": "Review", "title": "ERP plot count differs from layout schedule", "detail": f"Layout schedule: 96 residential + 6 commercial. ERP: {plot_category.get('Residential',0)} residential + {plot_category.get('Commercial',0)} commercial."})
    kmz_diff = kmz_source - legal
    checks.append({"level": "Info" if abs(kmz_diff) <= 2 else "Review", "title": "KMZ polygon vs deed area", "detail": f"Original KMZ computes to {kmz_source/20:.3f} K using {marla_sqft:g} sq ft/marla; deed area is {legal/20:.2f} K. Difference {kmz_diff:.2f} marla."})

    revisions = db.scalars(select(ProjectAreaRevision).where(ProjectAreaRevision.project_id == project.id).order_by(desc(ProjectAreaRevision.id)).limit(20)).all()
    return {
        "project": {
            "id": project.id, "code": project.code, "name": project.name, "developer": project.developer, "status": project.status,
            "mouza": project.mouza, "deed_location": project.deed_location, "layout_location": project.layout_location,
            "khasra_numbers": project.khasra_numbers, "khewat_numbers": project.khewat_numbers, "khatooni_numbers": project.khatooni_numbers,
            "landowners": landowners, "legal_area_marla": legal, "layout_area_marla": float(project.layout_area_marla or 0),
            "official_area_marla": current, "marla_sqft": marla_sqft, "kmz_current_area_marla": float(current_metrics["marla"]),
            "kmz_source_area_marla": kmz_source, "kmz_current_area_sqm": float(current_metrics["sqm"]), "kmz_source_area_sqm": float(source_metrics["sqm"]),
            "residential_area_marla": float(project.residential_area_marla or 0), "commercial_area_marla": float(project.commercial_area_marla or 0),
            "public_building_area_marla": float(project.public_building_area_marla or 0), "roads_parking_area_marla": float(project.roads_parking_area_marla or 0),
            "land_rate_per_marla": float(project.land_rate_per_marla or 0), "land_consideration": float(project.land_consideration or 0),
            "landowner_profit_share": float(project.landowner_profit_share or 0), "developer_profit_share": float(project.developer_profit_share or 0),
            "boundary": boundary, "original_boundary": original_boundary, "source_kmz_name": project.source_kmz_name, "notes": project.notes, "version": project.version,
        },
        "kpis": {
            "plots_total": total_plots, "plot_status": plot_status, "plot_category": plot_category, "total_sales": total_sales,
            "total_collections": total_collections, "total_outstanding": total_outstanding, "development_progress": float(dev[0] or 0),
            "development_budget": float(dev[1] or 0), "development_actual": float(dev[2] or 0), "land_recorded_cost": land_recorded,
            "land_remaining_vs_deed": max(0.0, float(project.land_consideration or 0) - land_recorded),
        },
        "checks": checks,
        "revisions": [{
            "id": r.id, "changed_at": r.changed_at.isoformat() if r.changed_at else None, "changed_by": r.changed_by, "change_type": r.change_type,
            "old_official_area_marla": r.old_official_area_marla, "new_official_area_marla": r.new_official_area_marla, "reason": r.reason
        } for r in revisions],
        "sources": [
            {"key": "deed", "name": "Deed of Agreement", "type": "DOCX", "note": "Land ownership, area, consideration and profit-sharing terms"},
            {"key": "layout", "name": "FINAL SUBMISSION - Layout Plan", "type": "PDF", "note": "Planning layout, plot schedule and land-use distribution"},
            {"key": "kmz", "name": project.source_kmz_name or "Horizon Homes KMZ", "type": "KMZ", "note": "Current project boundary source file"},
        ],
    }


@router.get("/project-overview")
def get_project_overview(context=Depends(require_roles("Finance", "Sales", "Development", "CRM")), db: Session = Depends(get_db)):
    project = db.scalar(select(ProjectProfile).order_by(ProjectProfile.id))
    if not project:
        raise HTTPException(404, "Project profile not initialized")
    return _project_profile_payload(db, project)


@router.patch("/project-overview")
def update_project_overview(payload: dict, request: Request, context=Depends(csrf_roles("Finance", "Development")), db: Session = Depends(get_db)):
    project = db.scalar(select(ProjectProfile).order_by(ProjectProfile.id))
    if not project:
        raise HTTPException(404, "Project profile not initialized")
    expected = int(payload.get("version") or project.version)
    if expected != project.version:
        raise HTTPException(409, "Project record changed by another user; refresh and try again")
    reason = str(payload.get("reason") or "").strip()
    if not reason:
        raise HTTPException(400, "Reason / approval reference is required")
    before_area = float(project.official_area_marla or 0)
    before_boundary = project.boundary_json or "[]"
    numeric = [
        "official_area_marla", "residential_area_marla", "commercial_area_marla", "public_building_area_marla",
        "roads_parking_area_marla", "land_rate_per_marla", "land_consideration", "landowner_profit_share", "developer_profit_share", "marla_sqft"
    ]
    text = ["status", "notes"]
    before = {k: getattr(project, k) for k in numeric + text}
    for field in numeric:
        if field in payload and payload[field] not in (None, ""):
            value = as_float(payload[field])
            if value < 0:
                raise HTTPException(400, f"{field.replace('_',' ').title()} cannot be negative")
            setattr(project, field, value)
    for field in text:
        if field in payload:
            setattr(project, field, str(payload[field] or ""))
    if project.marla_sqft <= 0:
        raise HTTPException(400, "Marla square-foot standard must be greater than zero")
    if project.boundary_json:
        metrics = area_metrics(json.loads(project.boundary_json), project.marla_sqft)
        project.kmz_area_sqm = metrics["sqm"]
        project.kmz_area_marla = metrics["marla"]
    project.version += 1
    db.add(ProjectAreaRevision(
        project_id=project.id, changed_by=context["user"].full_name, change_type="Project Area / Profile Edit",
        old_official_area_marla=before_area, new_official_area_marla=float(project.official_area_marla or 0),
        old_boundary_json=before_boundary, new_boundary_json=project.boundary_json or "[]", reason=reason
    ))
    audit(db, context["user"].full_name, "UPDATE", "Project Overview", project.id, {"before": before, "after": {k: getattr(project,k) for k in numeric + text}, "reason": reason}, ip_of(request))
    db.commit()
    return _project_profile_payload(db, project)


@router.post("/project-overview/boundary")
def update_project_boundary(payload: dict, request: Request, context=Depends(csrf_roles("Finance", "Development")), db: Session = Depends(get_db)):
    project = db.scalar(select(ProjectProfile).order_by(ProjectProfile.id))
    if not project:
        raise HTTPException(404, "Project profile not initialized")
    expected = int(payload.get("version") or project.version)
    if expected != project.version:
        raise HTTPException(409, "Project record changed by another user; refresh and try again")
    reason = str(payload.get("reason") or "").strip()
    if not reason:
        raise HTTPException(400, "Reason for boundary edit is required")
    coords = normalize_coordinates(payload.get("coordinates") or [])
    old_boundary = project.boundary_json or "[]"
    old_area = float(project.official_area_marla or 0)
    metrics = area_metrics(coords, project.marla_sqft or 225)
    project.boundary_json = json.dumps(coords)
    project.kmz_area_sqm = metrics["sqm"]
    project.kmz_area_marla = metrics["marla"]
    if bool(payload.get("update_official_area")):
        project.official_area_marla = metrics["marla"]
    project.version += 1
    db.add(ProjectAreaRevision(
        project_id=project.id, changed_by=context["user"].full_name, change_type="Boundary Edit",
        old_official_area_marla=old_area, new_official_area_marla=float(project.official_area_marla or 0),
        old_boundary_json=old_boundary, new_boundary_json=project.boundary_json, reason=reason
    ))
    audit(db, context["user"].full_name, "BOUNDARY_EDIT", "Project Overview", project.id, {"points": len(coords), "computed_area_marla": metrics["marla"], "update_official_area": bool(payload.get("update_official_area")), "reason": reason}, ip_of(request))
    db.commit()
    return _project_profile_payload(db, project)


@router.post("/project-overview/boundary/reset")
def reset_project_boundary(payload: dict, request: Request, context=Depends(csrf_roles("Finance", "Development")), db: Session = Depends(get_db)):
    project = db.scalar(select(ProjectProfile).order_by(ProjectProfile.id))
    if not project:
        raise HTTPException(404, "Project profile not initialized")
    reason = str(payload.get("reason") or "Reset to original source KMZ").strip()
    coords = normalize_coordinates(json.loads(project.original_boundary_json or "[]"))
    old_boundary = project.boundary_json or "[]"
    old_area = float(project.official_area_marla or 0)
    metrics = area_metrics(coords, project.marla_sqft or 225)
    project.boundary_json = json.dumps(coords)
    project.kmz_area_sqm = metrics["sqm"]
    project.kmz_area_marla = metrics["marla"]
    if bool(payload.get("update_official_area")):
        project.official_area_marla = metrics["marla"]
    project.version += 1
    db.add(ProjectAreaRevision(project_id=project.id, changed_by=context["user"].full_name, change_type="Boundary Reset", old_official_area_marla=old_area, new_official_area_marla=float(project.official_area_marla or 0), old_boundary_json=old_boundary, new_boundary_json=project.boundary_json, reason=reason))
    audit(db, context["user"].full_name, "BOUNDARY_RESET", "Project Overview", project.id, {"reason": reason}, ip_of(request))
    db.commit()
    return _project_profile_payload(db, project)


@router.post("/project-overview/kmz")
async def import_project_kmz(request: Request, file: UploadFile = File(...), context=Depends(csrf_roles("Finance", "Development")), db: Session = Depends(get_db)):
    project = db.scalar(select(ProjectProfile).order_by(ProjectProfile.id))
    if not project:
        raise HTTPException(404, "Project profile not initialized")
    if not (file.filename or "").lower().endswith(".kmz"):
        raise HTTPException(400, "Please upload a .kmz file")
    raw = await file.read()
    if len(raw) > 5_000_000:
        raise HTTPException(400, "KMZ file is too large")
    coords = parse_kmz_bytes(raw)
    metrics = area_metrics(coords, project.marla_sqft or 225)
    safe_name = "project_boundary_" + datetime.utcnow().strftime("%Y%m%d_%H%M%S") + ".kmz"
    PROJECT_SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    (PROJECT_SOURCE_DIR / safe_name).write_bytes(raw)
    old_boundary = project.boundary_json or "[]"
    old_area = float(project.official_area_marla or 0)
    project.boundary_json = json.dumps(coords)
    project.kmz_area_sqm = metrics["sqm"]
    project.kmz_area_marla = metrics["marla"]
    project.source_kmz_name = safe_name
    project.version += 1
    db.add(ProjectAreaRevision(project_id=project.id, changed_by=context["user"].full_name, change_type="KMZ Import", old_official_area_marla=old_area, new_official_area_marla=float(project.official_area_marla or 0), old_boundary_json=old_boundary, new_boundary_json=project.boundary_json, reason=f"Imported KMZ: {file.filename}"))
    audit(db, context["user"].full_name, "KMZ_IMPORT", "Project Overview", project.id, {"file": file.filename, "points": len(coords), "computed_area_marla": metrics["marla"]}, ip_of(request))
    db.commit()
    return _project_profile_payload(db, project)


@router.get("/project-overview/source/{doc_key}")
def project_source_document(doc_key: str, context=Depends(require_roles("Finance", "Sales", "Development", "CRM")), db: Session = Depends(get_db)):
    project = db.scalar(select(ProjectProfile).order_by(ProjectProfile.id))
    if not project:
        raise HTTPException(404, "Project profile not initialized")
    source_map = {
        "deed": (PROJECT_SOURCE_DIR / "deed_of_agreement.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "Horizon_Homes_Deed_of_Agreement.docx"),
        "layout": (PROJECT_SOURCE_DIR / "final_submission.pdf", "application/pdf", "Horizon_Homes_Final_Submission.pdf"),
        "layout-preview": (PROJECT_SOURCE_DIR / "layout_plan_preview.png", "image/png", "Horizon_Homes_Layout_Plan.png"),
        "kmz": (PROJECT_SOURCE_DIR / (project.source_kmz_name or "horizon_homes_28_30k.kmz"), "application/vnd.google-earth.kmz", "Horizon_Homes_Boundary.kmz"),
    }
    if doc_key not in source_map:
        raise HTTPException(404, "Project source document not found")
    path, media_type, download_name = source_map[doc_key]
    if not path.exists():
        raise HTTPException(404, "Project source file is missing from this installation")
    disposition = "inline" if doc_key in {"layout", "layout-preview"} else "attachment"
    return FileResponse(path, media_type=media_type, filename=download_name if disposition == "attachment" else None, headers={"Content-Disposition": f'{disposition}; filename="{download_name}"'})


# ---------------- Development ----------------
@router.get("/development")
def list_development(request: Request, context=Depends(require_roles("Finance", "Development")), db: Session = Depends(get_db)):
    page, size, q = page_params(request); filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(DevelopmentProject.code.ilike(p), DevelopmentProject.name.ilike(p), DevelopmentProject.contractor.ilike(p), DevelopmentProject.status.ilike(p)))
    stmt = select(DevelopmentProject).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "code": DevelopmentProject.code, "name": DevelopmentProject.name, "category": DevelopmentProject.category,
        "contractor": DevelopmentProject.contractor, "budget": DevelopmentProject.budget, "committed_cost": DevelopmentProject.committed_cost,
        "actual_cost": DevelopmentProject.actual_cost, "progress_percent": DevelopmentProject.progress_percent, "status": DevelopmentProject.status,
        "start_date": DevelopmentProject.start_date, "target_date": DevelopmentProject.target_date,
    }, "code", "asc", secondary=DevelopmentProject.id.asc())
    count_stmt = select(func.count()).select_from(DevelopmentProject).where(*filters)
    rows = db.scalars(stmt.offset((page - 1) * size).limit(size)).all(); total = db.scalar(count_stmt) or 0
    fields = ["id", "code", "name", "category", "contractor", "budget", "committed_cost", "actual_cost", "progress_percent", "status", "start_date", "target_date", "remarks", "version"]
    return {"items": [model_dict(x, fields) for x in rows], "total": total, "page": page, "size": size}


@router.post("/development")
def add_development(payload: dict, request: Request, context=Depends(csrf_roles("Development", "Finance")), db: Session = Depends(get_db)):
    name = str(payload.get("name") or "").strip()
    if not name: raise HTTPException(400, "Project name is required")
    project = DevelopmentProject(
        code=str(payload.get("code") or next_number(db, DevelopmentProject, DevelopmentProject.code, "DEV")), name=name,
        category=str(payload.get("category") or "Infrastructure"), contractor=str(payload.get("contractor") or ""), budget=as_float(payload.get("budget")),
        committed_cost=as_float(payload.get("committed_cost")), actual_cost=as_float(payload.get("actual_cost")), progress_percent=as_float(payload.get("progress_percent")),
        status=str(payload.get("status") or "Planned"), start_date=to_date(payload["start_date"]) if payload.get("start_date") else None,
        target_date=to_date(payload["target_date"]) if payload.get("target_date") else None, remarks=str(payload.get("remarks") or "")
    )
    db.add(project); db.flush(); audit(db, context["user"].full_name, "CREATE", "Development", project.id, payload, ip_of(request)); db.commit()
    return {"ok": True, "id": project.id}


@router.patch("/development/{project_id}")
def edit_development(project_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Development", "Finance")), db: Session = Depends(get_db)):
    project = db.get(DevelopmentProject, project_id)
    if not project: raise HTTPException(404, "Development project not found")
    expected = int(payload.pop("version", project.version))
    if expected != project.version: raise HTTPException(409, "Record changed by another user")
    allowed = ["name", "category", "contractor", "budget", "committed_cost", "actual_cost", "progress_percent", "status", "start_date", "target_date", "remarks"]
    before = model_dict(project, allowed)
    for field in allowed:
        if field in payload:
            if field in {"budget", "committed_cost", "actual_cost", "progress_percent"}: value = as_float(payload[field])
            elif field in {"start_date", "target_date"}: value = to_date(payload[field]) if payload[field] else None
            else: value = str(payload[field] or "")
            setattr(project, field, value)
    project.progress_percent = min(100, max(0, project.progress_percent)); project.version += 1
    audit(db, context["user"].full_name, "UPDATE", "Development", project.id, {"before": before, "after": model_dict(project, allowed)}, ip_of(request)); db.commit()
    return {"ok": True, "version": project.version}


@router.post("/development/{project_id}/updates")
def add_development_update(project_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Development", "Finance")), db: Session = Depends(get_db)):
    project = db.get(DevelopmentProject, project_id)
    if not project: raise HTTPException(404, "Development project not found")
    progress = min(100, max(0, as_float(payload.get("progress_percent"))))
    cost = as_float(payload.get("actual_cost_increment"))
    update = DevelopmentUpdate(project_id=project.id, update_date=to_date(payload.get("update_date") or date.today()), progress_percent=progress, actual_cost_increment=cost, description=str(payload.get("description") or ""), photo_url=str(payload.get("photo_url") or ""), created_by=context["user"].full_name)
    db.add(update); project.progress_percent = progress; project.actual_cost = float(project.actual_cost or 0) + cost; project.status = "Completed" if progress >= 100 else "In Progress"
    audit(db, context["user"].full_name, "PROGRESS_UPDATE", "Development", project.id, payload, ip_of(request)); db.commit()
    return {"ok": True, "id": update.id}


# ---------------- Finance ----------------
@router.get("/accounts")
def list_accounts(context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    rows = db.scalars(select(Account).order_by(Account.code)).all()
    return {"items": [model_dict(x, ["id", "code", "name", "type", "statement", "active", "version"]) for x in rows]}


@router.get("/account-cleanup")
def account_cleanup_overview(context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    accounts = db.scalars(select(Account).order_by(Account.type, Account.code)).all()
    line_stats = {
        row.account_id: {"lines": int(row.lines or 0), "debit": float(row.debit or 0), "credit": float(row.credit or 0)}
        for row in db.execute(
            select(
                VoucherLine.account_id.label("account_id"),
                func.count(VoucherLine.id).label("lines"),
                func.sum(VoucherLine.debit).label("debit"),
                func.sum(VoucherLine.credit).label("credit"),
            ).group_by(VoucherLine.account_id)
        ).all()
    }
    mappings = []
    for m in db.scalars(select(AccountAlias).order_by(desc(AccountAlias.id))).all():
        alias = db.get(Account, m.alias_account_id)
        master = db.get(Account, m.master_account_id)
        mappings.append({
            "id": m.id, "alias_account_id": m.alias_account_id, "alias_name": alias.name if alias else m.original_name,
            "master_account_id": m.master_account_id, "master_name": master.name if master else "",
            "reason": m.reason, "mapped_by": m.mapped_by, "mapped_at": m.mapped_at, "active": m.active,
            "moved_lines": len(json.loads(m.moved_line_ids or "[]")),
        })
    items = []
    for a in accounts:
        stat = line_stats.get(a.id, {"lines": 0, "debit": 0, "credit": 0})
        items.append({**model_dict(a, ["id", "code", "name", "type", "statement", "active"]), **stat, "balance": stat["debit"] - stat["credit"]})
    return {"accounts": items, "mappings": mappings}


@router.post("/account-cleanup/map")
def account_cleanup_map(payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    alias = db.get(Account, int(payload.get("alias_account_id") or 0))
    master = db.get(Account, int(payload.get("master_account_id") or 0))
    if not alias or not master:
        raise HTTPException(404, "Alias or master account not found")
    try:
        result = merge_account(db, alias, master, context["user"].full_name, str(payload.get("reason") or "Duplicate account consolidation"), ip_of(request))
        db.commit()
        return result
    except ValueError as exc:
        db.rollback(); error(exc)


@router.post("/account-cleanup/{mapping_id}/restore")
def account_cleanup_restore(mapping_id: int, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    mapping = db.get(AccountAlias, mapping_id)
    if not mapping:
        raise HTTPException(404, "Account mapping not found")
    try:
        result = restore_account_mapping(db, mapping, context["user"].full_name, ip_of(request))
        db.commit()
        return result
    except ValueError as exc:
        db.rollback(); error(exc)


@router.get("/vouchers")
def list_vouchers(request: Request, context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    page, size, q = page_params(request); filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(Voucher.voucher_no.ilike(p), Voucher.party.ilike(p), Voucher.narration.ilike(p)))
    debit_subq = select(VoucherLine.voucher_id, func.sum(VoucherLine.debit).label("amount")).group_by(VoucherLine.voucher_id).subquery()
    stmt = select(Voucher, debit_subq.c.amount).outerjoin(debit_subq, debit_subq.c.voucher_id == Voucher.id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "voucher_no": Voucher.voucher_no, "voucher_date": Voucher.voucher_date, "voucher_type": Voucher.voucher_type,
        "party": Voucher.party, "narration": Voucher.narration, "amount": debit_subq.c.amount, "source_module": Voucher.source_module, "status": Voucher.status,
    }, "voucher_date", "desc", secondary=Voucher.id.desc())
    count_stmt = select(func.count()).select_from(Voucher).where(*filters)
    rows, total = paginated(db, stmt, count_stmt, page, size)
    items = []
    for v, amount in rows:
        x = model_dict(v, ["id", "voucher_no", "voucher_date", "voucher_type", "party", "narration", "status", "source_module", "source_reference", "created_by", "posted_by", "posted_at", "version"]); x["amount"] = float(amount or 0); items.append(x)
    return {"items": items, "total": total, "page": page, "size": size}


@router.get("/vouchers/{voucher_id}")
def voucher_detail(voucher_id: int, context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    v = db.get(Voucher, voucher_id)
    if not v: raise HTTPException(404, "Voucher not found")
    lines = db.execute(select(VoucherLine, Account.name, Account.code).join(Account, Account.id == VoucherLine.account_id).where(VoucherLine.voucher_id == v.id)).all()
    return {"voucher": model_dict(v, ["id", "voucher_no", "voucher_date", "voucher_type", "party", "narration", "status", "source_module", "source_reference", "created_by", "posted_by", "posted_at"]), "lines": [{"account": name, "code": code, "debit": float(line.debit), "credit": float(line.credit), "party": line.party, "plot_no": line.plot_no, "memo": line.memo} for line, name, code in lines]}


@router.post("/vouchers")
def add_voucher(payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    try:
        v = create_voucher(db, voucher_date=payload.get("voucher_date") or date.today(), voucher_type=str(payload.get("voucher_type") or "Journal"), party=str(payload.get("party") or ""), narration=str(payload.get("narration") or ""), lines=payload.get("lines") or [], user_name=context["user"].full_name, source_module="Manual", source_reference="", status=str(payload.get("status") or "Posted"), ip_address=ip_of(request)); db.commit(); return {"ok": True, "id": v.id, "voucher_no": v.voucher_no}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.post("/vouchers/{voucher_id}/reverse")
def reverse_voucher_api(voucher_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    try:
        result = remove_or_reverse_voucher(db, voucher_id, str(payload.get("reason") or "Correction"), context["user"].full_name, ip_of(request))
        db.commit()
        return {"ok": True, **result}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.get("/reports/trial-balance")
def report_tb(request: Request, context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    fd=request.query_params.get("from_date") or None; td=request.query_params.get("to_date") or None
    items = trial_balance(db, fd, td); return {"items": items, "totals": {"debit": sum(x["debit"] for x in items), "credit": sum(x["credit"] for x in items)}}


@router.get("/reports/profit-loss")
def report_pl(request: Request, context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    return profit_loss(db, request.query_params.get("from_date") or None, request.query_params.get("to_date") or None)


@router.get("/reports/balance-sheet")
def report_bs(request: Request, context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    return balance_sheet(db, request.query_params.get("from_date") or None, request.query_params.get("to_date") or None)


def _statutory_export_payload(db: Session, report_type: str, from_date=None, to_date=None):
    if report_type == "trial-balance":
        d = {"items": trial_balance(db, from_date, to_date)}
        d["totals"] = {"debit": sum(x["debit"] for x in d["items"]), "credit": sum(x["credit"] for x in d["items"])}
        headers = ["code", "account", "type", "debit", "credit", "balance"]
        rows = [{h: x.get(h, "") for h in headers} for x in d["items"]]
        rows.append({"code":"", "account":"TOTAL", "type":"", "debit":d["totals"]["debit"], "credit":d["totals"]["credit"], "balance":d["totals"]["debit"]-d["totals"]["credit"]})
        return "Trial Balance", headers, rows
    if report_type == "profit-loss":
        d = profit_loss(db, from_date, to_date); headers = ["section", "account", "amount"]
        rows = ([{"section":"Income", "account":x["account"], "amount":x["amount"]} for x in d["income"]] +
                [{"section":"Expense", "account":x["account"], "amount":x["amount"]} for x in d["expenses"]])
        rows += [{"section":"Summary", "account":"Total Income", "amount":d["total_income"]}, {"section":"Summary", "account":"Total Expense", "amount":d["total_expense"]}, {"section":"Summary", "account":"Net Profit / (Loss)", "amount":d["net_profit"]}]
        return "Profit and Loss", headers, rows
    if report_type == "balance-sheet":
        d = balance_sheet(db, from_date, to_date); headers = ["section", "account", "amount"]
        rows=[]
        for section in ("Asset","Liability","Equity"):
            rows.extend({"section":section, "account":x["account"], "amount":x["amount"]} for x in d["groups"][section])
        rows += [{"section":"Summary", "account":"Total Assets", "amount":d["totals"]["Asset"]}, {"section":"Summary", "account":"Total Liabilities", "amount":d["totals"]["Liability"]}, {"section":"Summary", "account":"Total Equity", "amount":d["totals"]["Equity"]}, {"section":"Summary", "account":"Balance Sheet Difference", "amount":d["totals"]["Difference"]}]
        return "Balance Sheet", headers, rows
    raise HTTPException(400, "Unsupported statutory report")


@router.get("/reports/statutory-export")
def statutory_report_export(request: Request, context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    report_type = request.query_params.get("type", "trial-balance")
    fmt = request.query_params.get("format", "csv").lower()
    title, headers, rows = _statutory_export_payload(db, report_type, request.query_params.get("from_date") or None, request.query_params.get("to_date") or None)
    safe_name = report_type.replace("-", "_")
    if fmt == "csv":
        sio = StringIO(); w = csv.DictWriter(sio, fieldnames=headers); w.writeheader(); w.writerows(rows)
        return Response(sio.getvalue(), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=Horizon_{safe_name}.csv"})
    if fmt == "xlsx":
        from openpyxl import Workbook
        wb=Workbook(); ws=wb.active; ws.title=title[:31]; ws.append([h.replace("_"," ").title() for h in headers])
        for row in rows: ws.append([row.get(h,"") for h in headers])
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=min(48,max(12,max(len(str(c.value or "")) for c in col)+2))
        bio=BytesIO(); wb.save(bio); bio.seek(0)
        return StreamingResponse(bio, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition":f"attachment; filename=Horizon_{safe_name}.xlsx"})
    if fmt == "pdf":
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet
        bio=BytesIO(); doc=SimpleDocTemplate(bio,pagesize=landscape(A4),leftMargin=24,rightMargin=24,topMargin=24,bottomMargin=24); styles=getSampleStyleSheet()
        data=[[h.replace("_"," ").title() for h in headers]]
        for row in rows:
            vals=[]
            for h in headers:
                v=row.get(h,"")
                if h in ("debit","credit","balance","amount") and isinstance(v,(int,float)):
                    v=f"Rs. {v:,.2f}"
                vals.append(str(v))
            data.append(vals)
        widths = [90,260,110,110,110,110] if len(headers)==6 else [110,360,140]
        table=Table(data,repeatRows=1,colWidths=widths[:len(headers)])
        table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#17324d')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),8),('GRID',(0,0),(-1,-1),.25,colors.HexColor('#b8c0c8')),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f5f1e8')])]))
        doc.build([Paragraph(f"Horizon Homes - {title}", styles['Title']), Paragraph("Generated from posted Horizon ERP financial vouchers", styles['Normal']), Spacer(1,10), table]); bio.seek(0)
        return StreamingResponse(bio,media_type="application/pdf",headers={"Content-Disposition":f"attachment; filename=Horizon_{safe_name}.pdf"})
    raise HTTPException(400, "Unsupported export format")


# ---------------- V11 Dealers, Commissions and Reporting Centre ----------------
def _date_filter(request: Request):
    fd = request.query_params.get("from_date")
    td = request.query_params.get("to_date")
    return (to_date(fd) if fd else None, to_date(td) if td else None)


@router.get("/dealers")
def list_dealers(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    filters = [Party.party_type == "Dealer"]
    if q:
        p = f"%{q}%"; filters.append(or_(Party.name.ilike(p), Party.code.ilike(p), Party.mobile.ilike(p)))
    dealers = db.scalars(select(Party).where(*filters)).all()
    items=[]
    for d in dealers:
        bookings = db.scalars(select(Booking).where(func.lower(Booking.dealer_name)==d.name.lower())).all()
        sales=sum(float(x.net_sale_value or 0) for x in bookings)
        comms=db.scalars(select(Commission).where(func.lower(Commission.dealer_name)==d.name.lower())).all()
        earned=sum(float(x.commission_amount or 0) for x in comms); paid=sum(float(x.paid_amount or 0) for x in comms)
        x=model_dict(d,["id","code","name","party_type","mobile","email","address","opening_balance","balance_side","active","remarks","version"])
        x.update({"plots_sold":len(bookings),"sales_value":sales,"commission_earned":earned,"commission_paid":paid,"commission_payable":earned-paid})
        items.append(x)
    sort_by = request.query_params.get("sort_by", "name").strip()
    sort_dir = request.query_params.get("sort_dir", "asc").strip().lower()
    allowed = {"code","name","mobile","email","active","plots_sold","sales_value","commission_earned","commission_paid","commission_payable"}
    if sort_by not in allowed: sort_by = "name"
    if sort_dir not in {"asc","desc"}: sort_dir = "asc"
    def sort_value(row):
        value=row.get(sort_by)
        if value is None: return ""
        if isinstance(value,str): return value.casefold()
        return value
    items.sort(key=sort_value, reverse=sort_dir=="desc")
    total=len(items); items=items[(page-1)*size:page*size]
    return {"items":items,"total":total,"page":page,"size":size,"sort_by":sort_by,"sort_dir":sort_dir}


@router.get("/commissions")
def list_commissions(request: Request, context=Depends(require_roles("Finance", "Sales")), db: Session = Depends(get_db)):
    page,size,q=page_params(request); fd,td=_date_filter(request); filters=[]
    if q:
        p=f"%{q}%"; filters.append(or_(Commission.commission_no.ilike(p),Commission.dealer_name.ilike(p),Commission.status.ilike(p)))
    if fd: filters.append(Commission.commission_date>=fd)
    if td: filters.append(Commission.commission_date<=td)
    stmt=select(Commission,Booking.booking_no,Plot.plot_no).outerjoin(Booking,Booking.id==Commission.booking_id).outerjoin(Plot,Plot.id==Booking.plot_id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "commission_no": Commission.commission_no, "commission_date": Commission.commission_date, "booking_no": Booking.booking_no,
        "plot_no": Plot.plot_no, "dealer_name": Commission.dealer_name, "commission_type": Commission.commission_type, "basis": Commission.basis,
        "base_amount": Commission.base_amount, "rate_percent": Commission.rate_percent, "commission_amount": Commission.commission_amount,
        "paid_amount": Commission.paid_amount, "payable": Commission.commission_amount-Commission.paid_amount, "status": Commission.status,
    }, "commission_date", "desc", secondary=Commission.id.desc())
    count=select(func.count()).select_from(Commission).where(*filters)
    rows,total=paginated(db,stmt,count,page,size); items=[]
    for c,bno,pno in rows:
        x=model_dict(c,["id","commission_no","commission_date","booking_id","dealer_name","commission_type","basis","base_amount","rate_percent","commission_amount","paid_amount","status","approved_by","remarks","posted_voucher_id","version"]); x.update({"booking_no":bno or "","plot_no":pno or "","payable":float(c.commission_amount or 0)-float(c.paid_amount or 0)}); items.append(x)
    return {"items":items,"total":total,"page":page,"size":size}


@router.post("/commissions")
def add_commission(payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    booking = None
    booking_id = payload.get("booking_id")
    if booking_id not in (None, ""):
        booking = db.get(Booking, int(booking_id))
        if not booking:
            raise HTTPException(404, "Booking not found")
    dealer_name = str(payload.get("dealer_name") or "").strip()
    if not dealer_name:
        raise HTTPException(400, "Dealer / director name is required")
    commission_type = str(payload.get("commission_type") or "Dealer").strip()
    basis = str(payload.get("basis") or "Net Sale Value").strip()
    rate = round(as_float(payload.get("rate_percent")), 4)
    if rate < 0:
        raise HTTPException(400, "Commission rate cannot be negative")

    base = round(as_float(payload.get("base_amount")), 2)
    if booking:
        if basis == "Net Sale Value":
            base = round(float(booking.net_sale_value or 0), 2)
        elif basis == "Gross Sale Value":
            base = round(float(booking.sale_price or 0), 2)
        elif basis == "Collection":
            base = round(float(db.scalar(select(func.coalesce(func.sum(Receipt.amount), 0)).where(Receipt.booking_id == booking.id)) or 0), 2)
    amount = round(as_float(payload.get("commission_amount")), 2)
    if amount <= 0 and base > 0 and rate > 0:
        amount = round(base * rate / 100, 2)
    if amount <= 0:
        raise HTTPException(400, "Commission amount must be greater than zero")

    if booking:
        duplicate = db.scalar(select(Commission).where(
            Commission.booking_id == booking.id,
            func.lower(Commission.dealer_name) == dealer_name.lower(),
            Commission.commission_type == commission_type,
            Commission.status != "Cancelled",
        ))
        if duplicate:
            raise HTTPException(409, f"A {commission_type.lower()} commission already exists for this booking and party ({duplicate.commission_no})")

    c = Commission(
        commission_no=next_number(db, Commission, "commission_no", "COM"),
        commission_date=to_date(payload.get("commission_date") or (booking.booking_date if booking else date.today()), "commission_date"),
        booking_id=booking.id if booking else None, dealer_name=dealer_name, commission_type=commission_type,
        basis=basis, base_amount=base, rate_percent=rate, commission_amount=amount, paid_amount=0,
        status=str(payload.get("status") or "Pending"), remarks=str(payload.get("remarks") or ""),
    )
    if c.status not in {"Draft", "Pending"}:
        c.status = "Pending"
    db.add(c); db.flush()
    audit(db, context['user'].full_name, 'CREATE', 'Commission', c.id, {
        'commission_no': c.commission_no, 'booking_id': c.booking_id, 'dealer_name': c.dealer_name,
        'type': c.commission_type, 'basis': c.basis, 'base_amount': float(c.base_amount),
        'rate_percent': float(c.rate_percent), 'commission_amount': float(c.commission_amount),
    }, ip_of(request))
    db.commit()
    return {"ok": True, "id": c.id, "commission_no": c.commission_no}


@router.post("/commissions/sync")
def sync_commissions(request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    existing={x for x in db.scalars(select(Commission.booking_id).where(Commission.booking_id.is_not(None), Commission.commission_type=='Dealer', Commission.status!='Cancelled')).all()}
    made=0
    for b in db.scalars(select(Booking).where(Booking.status.in_(["Posted","Active","Booked"]))).all():
        if b.id in existing or not (b.dealer_name or '').strip(): continue
        base=float(b.net_sale_value or 0); c=Commission(commission_no=next_number(db,Commission,"commission_no","COM"),commission_date=b.booking_date,booking_id=b.id,dealer_name=b.dealer_name,commission_type="Dealer",basis="Net Sale Value",base_amount=base,rate_percent=2,commission_amount=round(base*.02,2),paid_amount=0,status="Pending",remarks=f"Auto-generated from {b.booking_no}")
        db.add(c); made+=1
    audit(db,context['user'].full_name,'SYNC','Commission',None,f'{made} commission records generated',ip_of(request)); db.commit(); return {"ok":True,"created":made}


@router.patch("/commissions/{commission_id}")
def edit_commission(commission_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Finance")),db:Session=Depends(get_db)):
    c=db.get(Commission,commission_id)
    if not c: raise HTTPException(404,"Commission not found")
    if int(payload.get('version') or c.version)!=c.version: raise HTTPException(409,'Record changed by another user. Refresh and try again.')
    for field in ['dealer_name','commission_type','basis','status','approved_by','remarks']:
        if field in payload: setattr(c,field,str(payload[field] or ''))
    for field in ['base_amount','rate_percent','commission_amount','paid_amount']:
        if field in payload: setattr(c,field,round(as_float(payload[field]),2))
    c.version+=1; audit(db,context['user'].full_name,'UPDATE','Commission',c.id,c.commission_no,ip_of(request)); db.commit(); return {"ok":True}


@router.post("/commissions/{commission_id}/approve")
def approve_commission(commission_id:int,request:Request,context=Depends(csrf_roles("Finance")),db:Session=Depends(get_db)):
    c=db.get(Commission,commission_id)
    if not c: raise HTTPException(404,'Commission not found')
    if c.status not in ['Pending','Draft']: raise HTTPException(400,'Only pending commission can be approved')
    expense=db.scalar(select(Account).where(Account.name.ilike('%Commission Expense%'))) or db.scalar(select(Account).where(Account.type=='Expense'))
    payable=db.scalar(select(Account).where(Account.name.ilike('%Commission Payable%'))) or db.scalar(select(Account).where(Account.type=='Liability'))
    if not expense or not payable: raise HTTPException(400,'Commission expense/payable accounts are not configured')
    v=create_voucher(db,voucher_date=c.commission_date,voucher_type='Journal',party=c.dealer_name,narration=f'Commission approved {c.commission_no}',lines=[{'account_id':expense.id,'debit':float(c.commission_amount),'credit':0,'party':c.dealer_name},{'account_id':payable.id,'debit':0,'credit':float(c.commission_amount),'party':c.dealer_name}],user_name=context['user'].full_name,source_module='Commission',source_reference=c.commission_no,status='Posted',ip_address=ip_of(request))
    c.status='Approved'; c.approved_by=context['user'].full_name; c.posted_voucher_id=v.id; c.version+=1; db.commit(); return {'ok':True,'voucher_no':v.voucher_no}


def _report_rows(db, report_type, fd=None, td=None, account_id=None):
    filters=[Voucher.status.in_(['Posted','Reversed'])]
    if fd: filters.append(Voucher.voucher_date>=fd)
    if td: filters.append(Voucher.voucher_date<=td)
    if account_id: filters.append(VoucherLine.account_id==account_id)
    rows=db.execute(select(Voucher.voucher_date,Voucher.voucher_no,Voucher.voucher_type,Voucher.party,Voucher.narration,Account.code,Account.name,VoucherLine.debit,VoucherLine.credit).join(VoucherLine,VoucherLine.voucher_id==Voucher.id).join(Account,Account.id==VoucherLine.account_id).where(*filters).order_by(Voucher.voucher_date,Voucher.id,VoucherLine.id)).all()
    out=[]; balance=0
    for d,vno,vtype,party,narr,code,name,debit,credit in rows:
        debit=float(debit or 0); credit=float(credit or 0); balance += debit-credit
        out.append({'date':d.isoformat(),'voucher_no':vno,'voucher_type':vtype,'party':party,'account_code':code,'account':name,'particular':narr,'debit':debit,'credit':credit,'balance':balance})
    return out


@router.get('/reports/centre')
def report_centre(request:Request,context=Depends(require_roles('Finance')),db:Session=Depends(get_db)):
    fd,td=_date_filter(request); account_id=request.query_params.get('account_id'); account_id=int(account_id) if account_id else None
    rows=_report_rows(db,request.query_params.get('type','day-book'),fd,td,account_id)
    return {'items':rows,'summary':{'transactions':len({x['voucher_no'] for x in rows}),'total_debit':sum(x['debit'] for x in rows),'total_credit':sum(x['credit'] for x in rows),'closing_balance':rows[-1]['balance'] if rows else 0}}


@router.get('/reports/export')
def report_export(request:Request,context=Depends(require_roles('Finance')),db:Session=Depends(get_db)):
    fd,td=_date_filter(request); account_id=request.query_params.get('account_id'); account_id=int(account_id) if account_id else None; fmt=request.query_params.get('format','csv').lower()
    rows=_report_rows(db,request.query_params.get('type','day-book'),fd,td,account_id); headers=['date','voucher_no','voucher_type','party','account_code','account','particular','debit','credit','balance']
    if fmt=='csv':
        sio=StringIO(); w=csv.DictWriter(sio,fieldnames=headers); w.writeheader(); w.writerows(rows); return Response(sio.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename=horizon_report.csv'})
    if fmt=='xlsx':
        from openpyxl import Workbook
        wb=Workbook(); ws=wb.active; ws.title='Report'; ws.append([h.replace('_',' ').title() for h in headers])
        for r in rows: ws.append([r[h] for h in headers])
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=min(42,max(12,max(len(str(c.value or '')) for c in col)+2))
        bio=BytesIO(); wb.save(bio); bio.seek(0); return StreamingResponse(bio,media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':'attachment; filename=horizon_report.xlsx'})
    if fmt=='pdf':
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet
        bio=BytesIO(); doc=SimpleDocTemplate(bio,pagesize=landscape(A4),leftMargin=20,rightMargin=20,topMargin=20,bottomMargin=20); styles=getSampleStyleSheet(); data=[[h.replace('_',' ').title() for h in headers]]
        for r in rows: data.append([str(r[h])[:45] for h in headers])
        table=Table(data,repeatRows=1,colWidths=[55,65,55,70,55,85,165,65,65,70]); table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#17324d')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),7),('GRID',(0,0),(-1,-1),.25,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f5f1e8')])]))
        doc.build([Paragraph('Horizon Homes — Reports & Statements',styles['Title']),Spacer(1,8),table]); bio.seek(0); return StreamingResponse(bio,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename=horizon_report.pdf'})
    raise HTTPException(400,'Unsupported export format')


@router.get("/audit")
def list_audit(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM", "Development")), db: Session = Depends(get_db)):
    page, size, q = page_params(request); filters = []
    if q:
        p = f"%{q}%"; filters.append(or_(AuditLog.user_name.ilike(p), AuditLog.action.ilike(p), AuditLog.module.ilike(p), AuditLog.details.ilike(p)))
    stmt = select(AuditLog).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "at": AuditLog.at, "user_name": AuditLog.user_name, "action": AuditLog.action, "module": AuditLog.module,
        "record_id": AuditLog.record_id, "details": AuditLog.details, "ip_address": AuditLog.ip_address,
    }, "at", "desc", secondary=AuditLog.id.desc())
    count_stmt = select(func.count()).select_from(AuditLog).where(*filters)
    rows = db.scalars(stmt.offset((page - 1) * size).limit(size)).all(); total = db.scalar(count_stmt) or 0
    return {"items": [model_dict(x, ["id", "at", "user_name", "action", "module", "record_id", "details", "ip_address"]) for x in rows], "total": total, "page": page, "size": size}


# ---------------- Financial Integrity / Duplicate Control (V29) ----------------
@router.get("/financial-integrity/summary")
def finance_integrity_summary(context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    return financial_integrity_summary(db)


@router.get("/financial-integrity/duplicates")
def finance_integrity_duplicates(context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    groups = duplicate_groups(db)
    return {"items": groups, "total_groups": len(groups), "duplicate_rows": sum(max(0, x["count"]-1) for x in groups)}


@router.post("/financial-integrity/duplicates/{duplicate_voucher_id}/reverse")
def finance_integrity_reverse_duplicate(duplicate_voucher_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    try:
        keep_id = int(payload.get("keep_voucher_id") or 0)
        if not keep_id:
            raise ValueError("Select the voucher that must be kept")
        reversal = reverse_duplicate_voucher(
            db,
            keep_voucher_id=keep_id,
            duplicate_voucher_id=duplicate_voucher_id,
            reason=str(payload.get("reason") or "Duplicate financial entry removed"),
            user_name=context["user"].full_name,
            ip_address=ip_of(request),
        )
        db.commit()
        return {"ok": True, "reversal_voucher_no": reversal.voucher_no, "summary": financial_integrity_summary(db)}
    except ValueError as exc:
        db.rollback(); error(exc)


@router.post("/financial-integrity/vouchers/{voucher_id}/remove")
def finance_integrity_remove_voucher(voucher_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    try:
        reason = str(payload.get("reason") or "Financial entry correction/removal").strip()
        if not reason:
            raise ValueError("Reason is required")
        result = remove_or_reverse_voucher(db, voucher_id, reason, context["user"].full_name, ip_of(request))
        db.commit()
        result["summary"] = financial_integrity_summary(db)
        return {"ok": True, **result}
    except ValueError as exc:
        db.rollback(); error(exc)


# ---------------- Expenses ----------------
@router.get("/expenses")
def list_expenses(request: Request, context=Depends(require_roles("Finance")), db: Session = Depends(get_db)):
    page, size, q = page_params(request)
    filters = [Account.type == "Expense", Voucher.status.in_(["Posted", "Reversed"]), or_(VoucherLine.debit > 0, VoucherLine.credit > 0)]
    if q:
        p = f"%{q}%"
        filters.append(or_(Voucher.voucher_no.ilike(p), Voucher.party.ilike(p), Voucher.narration.ilike(p), Account.name.ilike(p)))
    stmt = select(VoucherLine, Voucher, Account.name).join(Voucher, Voucher.id == VoucherLine.voucher_id).join(Account, Account.id == VoucherLine.account_id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "voucher_no": Voucher.voucher_no, "expense_date": Voucher.voucher_date, "account": Account.name, "party": Voucher.party,
        "narration": Voucher.narration, "amount": VoucherLine.debit-VoucherLine.credit, "status": Voucher.status, "source_module": Voucher.source_module,
    }, "expense_date", "desc", secondary=Voucher.id.desc())
    count_stmt = select(func.count()).select_from(VoucherLine).join(Voucher).join(Account).where(*filters)
    rows, total = paginated(db, stmt, count_stmt, page, size)
    items = []
    for line, voucher, account_name in rows:
        items.append({
            "id": line.id, "voucher_id": voucher.id, "voucher_no": voucher.voucher_no,
            "expense_date": voucher.voucher_date.isoformat(), "account": account_name,
            "party": voucher.party, "narration": voucher.narration,
            "amount": float(line.debit) - float(line.credit), "status": voucher.status,
            "source_module": voucher.source_module,
        })
    return {"items": items, "total": total, "page": page, "size": size}


@router.post("/expenses")
def add_expense(payload: dict, request: Request, context=Depends(csrf_roles("Finance")), db: Session = Depends(get_db)):
    try:
        amount = round(as_float(payload.get("amount")), 2)
        if amount <= 0: raise ValueError("Expense amount must be greater than zero")
        expense_account = str(payload.get("expense_account") or "").strip()
        paid_from = str(payload.get("paid_from") or "Cash in Hand").strip()
        v = create_voucher(
            db, voucher_date=payload.get("expense_date") or date.today(), voucher_type="Payment",
            party=str(payload.get("party") or ""), narration=str(payload.get("narration") or "Expense posted"),
            lines=[
                {"account": expense_account, "debit": amount, "credit": 0, "party": payload.get("party", "")},
                {"account": paid_from, "debit": 0, "credit": amount, "party": payload.get("party", "")},
            ], user_name=context["user"].full_name, source_module="Expense Register",
            source_reference=str(payload.get("reference") or ""), status="Posted", ip_address=ip_of(request)
        )
        db.commit(); return {"ok": True, "voucher_id": v.id, "voucher_no": v.voucher_no}
    except ValueError as exc:
        db.rollback(); error(exc)


# ---------------- Parties, Procurement, HR and Compliance ----------------
@router.get("/parties")
def list_parties(request: Request, context=Depends(require_roles("Finance", "Development")), db: Session = Depends(get_db)):
    page, size, q = page_params(request); filters=[]
    party_type=request.query_params.get("party_type", "")
    if q:
        p=f"%{q}%"; filters.append(or_(Party.code.ilike(p), Party.name.ilike(p), Party.mobile.ilike(p)))
    if party_type: filters.append(Party.party_type == party_type)
    stmt=select(Party).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "code": Party.code, "name": Party.name, "party_type": Party.party_type, "mobile": Party.mobile, "email": Party.email,
        "opening_balance": Party.opening_balance, "balance_side": Party.balance_side, "active": Party.active,
    }, "party_type", "asc", secondary=Party.name.asc())
    count_stmt=select(func.count()).select_from(Party).where(*filters)
    rows=db.scalars(stmt.offset((page-1)*size).limit(size)).all(); total=db.scalar(count_stmt) or 0
    fields=["id","code","name","party_type","mobile","email","address","opening_balance","balance_side","active","remarks","version"]
    return {"items":[model_dict(x,fields) for x in rows],"total":total,"page":page,"size":size}


@router.post("/parties")
def add_party(payload: dict, request: Request, context=Depends(csrf_roles("Finance", "Development")), db: Session = Depends(get_db)):
    name=str(payload.get("name") or "").strip()
    if not name: raise HTTPException(400,"Party name is required")
    party=Party(code=str(payload.get("code") or next_number(db,Party,Party.code,"PTY")),name=name,party_type=str(payload.get("party_type") or "Vendor"),mobile=str(payload.get("mobile") or ""),email=str(payload.get("email") or ""),address=str(payload.get("address") or ""),opening_balance=as_float(payload.get("opening_balance")),balance_side=str(payload.get("balance_side") or "Credit"),active=bool(payload.get("active",True)),remarks=str(payload.get("remarks") or ""))
    db.add(party);db.flush();audit(db,context["user"].full_name,"CREATE","Parties",party.id,payload,ip_of(request));db.commit();return {"ok":True,"id":party.id}


@router.patch("/parties/{party_id}")
def edit_party(party_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Finance","Development")),db:Session=Depends(get_db)):
    party=db.get(Party,party_id)
    if not party: raise HTTPException(404,"Party not found")
    expected=int(payload.pop("version",party.version))
    if expected!=party.version: raise HTTPException(409,"Record changed by another user")
    allowed=["name","party_type","mobile","email","address","opening_balance","balance_side","active","remarks"]
    before=model_dict(party,allowed)
    for f in allowed:
        if f in payload:
            if f=="opening_balance": val=as_float(payload[f])
            elif f in {"active"}: val=bool(payload[f])
            else: val=str(payload[f] or "")
            setattr(party,f,val)
    party.version+=1;audit(db,context["user"].full_name,"UPDATE","Parties",party.id,{"before":before,"after":model_dict(party,allowed)},ip_of(request));db.commit();return {"ok":True,"version":party.version}


@router.get("/purchase-orders")
def list_purchase_orders(request:Request,context=Depends(require_roles("Finance","Development")),db:Session=Depends(get_db)):
    page,size,q=page_params(request);filters=[]
    if q:
        p=f"%{q}%";filters.append(or_(PurchaseOrder.po_no.ilike(p),Party.name.ilike(p),PurchaseOrder.description.ilike(p)))
    stmt=select(PurchaseOrder,Party.name).join(Party,Party.id==PurchaseOrder.vendor_id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "po_no": PurchaseOrder.po_no, "po_date": PurchaseOrder.po_date, "vendor_name": Party.name, "description": PurchaseOrder.description,
        "amount": PurchaseOrder.amount, "status": PurchaseOrder.status, "expected_date": PurchaseOrder.expected_date, "approved_by": PurchaseOrder.approved_by,
    }, "po_date", "desc", secondary=PurchaseOrder.id.desc())
    count_stmt=select(func.count()).select_from(PurchaseOrder).join(Party).where(*filters)
    rows,total=paginated(db,stmt,count_stmt,page,size);items=[]
    for po,vendor in rows:
        x=model_dict(po,["id","po_no","po_date","vendor_id","description","amount","status","expected_date","approved_by","remarks","version"]);x["vendor_name"]=vendor;items.append(x)
    return {"items":items,"total":total,"page":page,"size":size}


@router.post("/purchase-orders")
def add_purchase_order(payload:dict,request:Request,context=Depends(csrf_roles("Finance","Development")),db:Session=Depends(get_db)):
    vendor=db.get(Party,int(payload.get("vendor_id") or 0))
    if not vendor: raise HTTPException(400,"Select a valid vendor or contractor")
    amount=as_float(payload.get("amount"))
    if amount<=0: raise HTTPException(400,"PO amount must be greater than zero")
    po=PurchaseOrder(po_no=next_number(db,PurchaseOrder,PurchaseOrder.po_no,"PO"),po_date=to_date(payload.get("po_date") or date.today()),vendor_id=vendor.id,description=str(payload.get("description") or ""),amount=amount,status=str(payload.get("status") or "Draft"),expected_date=to_date(payload["expected_date"]) if payload.get("expected_date") else None,remarks=str(payload.get("remarks") or ""))
    db.add(po);db.flush();audit(db,context["user"].full_name,"CREATE","Procurement",po.id,payload,ip_of(request));db.commit();return {"ok":True,"id":po.id,"po_no":po.po_no}


@router.patch("/purchase-orders/{po_id}")
def edit_purchase_order(po_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Finance","Development")),db:Session=Depends(get_db)):
    po=db.get(PurchaseOrder,po_id)
    if not po: raise HTTPException(404,"Purchase order not found")
    expected=int(payload.pop("version",po.version))
    if expected!=po.version: raise HTTPException(409,"Record changed by another user")
    if po.status in {"Approved","Closed"} and context["user"].role!="Admin": raise HTTPException(400,"Approved or closed purchase orders cannot be directly edited")
    allowed=["vendor_id","description","amount","status","expected_date","remarks"]
    for f in allowed:
        if f in payload:
            if f in {"vendor_id"}: val=int(payload[f])
            elif f=="amount": val=as_float(payload[f])
            elif f=="expected_date": val=to_date(payload[f]) if payload[f] else None
            else: val=str(payload[f] or "")
            setattr(po,f,val)
    if po.status=="Approved": po.approved_by=context["user"].full_name
    po.version+=1;audit(db,context["user"].full_name,"UPDATE","Procurement",po.id,payload,ip_of(request));db.commit();return {"ok":True,"version":po.version}


@router.get("/employees")
def list_employees(request:Request,context=Depends(require_roles("Finance")),db:Session=Depends(get_db)):
    page,size,q=page_params(request);filters=[]
    if q:
        p=f"%{q}%";filters.append(or_(Employee.employee_no.ilike(p),Employee.name.ilike(p),Employee.department.ilike(p),Employee.designation.ilike(p)))
    stmt=select(Employee).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "employee_no": Employee.employee_no, "name": Employee.name, "department": Employee.department, "designation": Employee.designation,
        "mobile": Employee.mobile, "cnic": Employee.cnic, "joining_date": Employee.joining_date, "salary": Employee.salary, "status": Employee.status,
    }, "department", "asc", secondary=Employee.name.asc())
    count_stmt=select(func.count()).select_from(Employee).where(*filters)
    rows=db.scalars(stmt.offset((page-1)*size).limit(size)).all();total=db.scalar(count_stmt) or 0
    fields=["id","employee_no","name","department","designation","mobile","cnic","joining_date","salary","status","remarks","version"]
    return {"items":[model_dict(x,fields) for x in rows],"total":total,"page":page,"size":size}


@router.post("/employees")
def add_employee(payload:dict,request:Request,context=Depends(csrf_roles("Finance")),db:Session=Depends(get_db)):
    name=str(payload.get("name") or "").strip()
    if not name: raise HTTPException(400,"Employee name is required")
    e=Employee(employee_no=str(payload.get("employee_no") or next_number(db,Employee,Employee.employee_no,"EMP")),name=name,department=str(payload.get("department") or "Administration"),designation=str(payload.get("designation") or ""),mobile=str(payload.get("mobile") or ""),cnic=str(payload.get("cnic") or ""),joining_date=to_date(payload["joining_date"]) if payload.get("joining_date") else None,salary=as_float(payload.get("salary")),status=str(payload.get("status") or "Active"),remarks=str(payload.get("remarks") or ""))
    db.add(e);db.flush();audit(db,context["user"].full_name,"CREATE","HR",e.id,payload,ip_of(request));db.commit();return {"ok":True,"id":e.id}


@router.patch("/employees/{employee_id}")
def edit_employee(employee_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Finance")),db:Session=Depends(get_db)):
    e=db.get(Employee,employee_id)
    if not e: raise HTTPException(404,"Employee not found")
    expected=int(payload.pop("version",e.version))
    if expected!=e.version: raise HTTPException(409,"Record changed by another user")
    allowed=["name","department","designation","mobile","cnic","joining_date","salary","status","remarks"]
    for f in allowed:
        if f in payload:
            if f=="salary":val=as_float(payload[f])
            elif f=="joining_date":val=to_date(payload[f]) if payload[f] else None
            else:val=str(payload[f] or "")
            setattr(e,f,val)
    e.version+=1;audit(db,context["user"].full_name,"UPDATE","HR",e.id,payload,ip_of(request));db.commit();return {"ok":True,"version":e.version}


@router.get("/payroll")
def list_payroll(request:Request,context=Depends(require_roles("Finance")),db:Session=Depends(get_db)):
    page,size,q=page_params(request);filters=[]
    if q:
        p=f"%{q}%";filters.append(or_(Payroll.payroll_month.ilike(p),Employee.name.ilike(p)))
    stmt=select(Payroll,Employee.name,Employee.employee_no).join(Employee,Employee.id==Payroll.employee_id).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "payroll_month": Payroll.payroll_month, "employee_name": Employee.name, "employee_no": Employee.employee_no,
        "basic_salary": Payroll.basic_salary, "allowances": Payroll.allowances, "deductions": Payroll.deductions, "net_pay": Payroll.net_pay, "status": Payroll.status,
    }, "payroll_month", "desc", secondary=Employee.name.asc())
    count_stmt=select(func.count()).select_from(Payroll).join(Employee).where(*filters)
    rows,total=paginated(db,stmt,count_stmt,page,size);items=[]
    for p,name,no in rows:
        x=model_dict(p,["id","payroll_month","employee_id","basic_salary","allowances","deductions","net_pay","status","version"]);x.update(employee_name=name,employee_no=no);items.append(x)
    return {"items":items,"total":total,"page":page,"size":size}


@router.post("/payroll")
def add_payroll(payload:dict,request:Request,context=Depends(csrf_roles("Finance")),db:Session=Depends(get_db)):
    employee=db.get(Employee,int(payload.get("employee_id") or 0))
    if not employee: raise HTTPException(400,"Employee not found")
    basic=as_float(payload.get("basic_salary") or employee.salary);allowances=as_float(payload.get("allowances"));deductions=as_float(payload.get("deductions"));net=basic+allowances-deductions
    payroll=Payroll(payroll_month=str(payload.get("payroll_month") or date.today().strftime("%Y-%m")),employee_id=employee.id,basic_salary=basic,allowances=allowances,deductions=deductions,net_pay=net,status="Draft")
    db.add(payroll);db.flush();audit(db,context["user"].full_name,"CREATE","Payroll",payroll.id,payload,ip_of(request));db.commit();return {"ok":True,"id":payroll.id}


@router.post("/payroll/{payroll_id}/pay")
def pay_payroll(payroll_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Finance")),db:Session=Depends(get_db)):
    payroll=db.get(Payroll,payroll_id)
    if not payroll or payroll.status!="Draft": raise HTTPException(400,"Draft payroll record not found")
    employee=db.get(Employee,payroll.employee_id);paid_from=str(payload.get("paid_from") or "Bank Account")
    try:
        gross = float(payroll.basic_salary) + float(payroll.allowances)
        deductions = float(payroll.deductions)
        lines = [{"account":"Salary & Wages Expense","debit":gross,"credit":0,"party":employee.name}]
        if deductions > 0:
            lines.append({"account":"Staff Deductions Payable","debit":0,"credit":deductions,"party":employee.name})
        lines.append({"account":paid_from,"debit":0,"credit":float(payroll.net_pay),"party":employee.name})
        v=create_voucher(db,voucher_date=payload.get("payment_date") or date.today(),voucher_type="Payment",party=employee.name,narration=f"Salary paid for {payroll.payroll_month}",lines=lines,user_name=context["user"].full_name,source_module="Payroll",source_reference=f"PAY-{payroll.id}",status="Posted",ip_address=ip_of(request))
        payroll.status="Paid";payroll.paid_voucher_id=v.id;audit(db,context["user"].full_name,"PAY","Payroll",payroll.id,{"voucher":v.voucher_no},ip_of(request));db.commit();return {"ok":True,"voucher_no":v.voucher_no}
    except ValueError as exc:
        db.rollback();error(exc)


@router.get("/compliance")
def list_compliance(request:Request,context=Depends(require_roles("Finance","Development")),db:Session=Depends(get_db)):
    page,size,q=page_params(request);filters=[]
    if q:
        p=f"%{q}%";filters.append(or_(ComplianceItem.reference_no.ilike(p),ComplianceItem.subject.ilike(p),ComplianceItem.authority.ilike(p)))
    stmt=select(ComplianceItem).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "reference_no": ComplianceItem.reference_no, "authority": ComplianceItem.authority, "subject": ComplianceItem.subject,
        "issue_date": ComplianceItem.issue_date, "due_date": ComplianceItem.due_date, "status": ComplianceItem.status, "responsible_person": ComplianceItem.responsible_person,
    }, "due_date", "asc", secondary=ComplianceItem.id.desc())
    count_stmt=select(func.count()).select_from(ComplianceItem).where(*filters)
    rows=db.scalars(stmt.offset((page-1)*size).limit(size)).all();total=db.scalar(count_stmt) or 0
    fields=["id","reference_no","authority","subject","issue_date","due_date","status","responsible_person","remarks","version"]
    return {"items":[model_dict(x,fields) for x in rows],"total":total,"page":page,"size":size}


@router.post("/compliance")
def add_compliance(payload:dict,request:Request,context=Depends(csrf_roles("Development","Finance")),db:Session=Depends(get_db)):
    subject=str(payload.get("subject") or "").strip()
    if not subject: raise HTTPException(400,"Subject is required")
    item=ComplianceItem(reference_no=str(payload.get("reference_no") or next_number(db,ComplianceItem,ComplianceItem.reference_no,"CMP")),authority=str(payload.get("authority") or "RUDA"),subject=subject,issue_date=to_date(payload["issue_date"]) if payload.get("issue_date") else None,due_date=to_date(payload["due_date"]) if payload.get("due_date") else None,status=str(payload.get("status") or "Open"),responsible_person=str(payload.get("responsible_person") or ""),remarks=str(payload.get("remarks") or ""))
    db.add(item);db.flush();audit(db,context["user"].full_name,"CREATE","Compliance",item.id,payload,ip_of(request));db.commit();return {"ok":True,"id":item.id}


@router.patch("/compliance/{item_id}")
def edit_compliance(item_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Development","Finance")),db:Session=Depends(get_db)):
    item=db.get(ComplianceItem,item_id)
    if not item: raise HTTPException(404,"Compliance item not found")
    expected=int(payload.pop("version",item.version))
    if expected!=item.version: raise HTTPException(409,"Record changed by another user")
    allowed=["authority","subject","issue_date","due_date","status","responsible_person","remarks"]
    for f in allowed:
        if f in payload:
            val=to_date(payload[f]) if f in {"issue_date","due_date"} and payload[f] else (None if f in {"issue_date","due_date"} else str(payload[f] or ""));setattr(item,f,val)
    item.version+=1;audit(db,context["user"].full_name,"UPDATE","Compliance",item.id,payload,ip_of(request));db.commit();return {"ok":True,"version":item.version}


@router.get("/documents")
def list_documents(request:Request,context=Depends(require_roles("Finance","Sales","CRM","Development")),db:Session=Depends(get_db)):
    page,size,q=page_params(request);filters=[]
    if q:
        p=f"%{q}%";filters.append(or_(Document.module.ilike(p),Document.document_type.ilike(p),Document.file_name.ilike(p)))
    stmt=select(Document).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "file_name": Document.file_name, "document_type": Document.document_type, "module": Document.module, "record_id": Document.record_id,
        "uploaded_by": Document.uploaded_by, "created_at": Document.created_at,
    }, "created_at", "desc", secondary=Document.id.desc())
    count_stmt=select(func.count()).select_from(Document).where(*filters)
    rows=db.scalars(stmt.offset((page-1)*size).limit(size)).all();total=db.scalar(count_stmt) or 0
    fields=["id","module","record_id","document_type","file_name","storage_url","uploaded_by","created_at","version"]
    return {"items":[model_dict(x,fields) for x in rows],"total":total,"page":page,"size":size}


@router.post("/documents")
def add_document(payload:dict,request:Request,context=Depends(csrf_roles("Finance","Sales","CRM","Development")),db:Session=Depends(get_db)):
    name=str(payload.get("file_name") or "").strip()
    if not name: raise HTTPException(400,"File name is required")
    doc=Document(module=str(payload.get("module") or "General"),record_id=int(payload.get("record_id") or 0),document_type=str(payload.get("document_type") or "Other"),file_name=name,storage_url=str(payload.get("storage_url") or ""),uploaded_by=context["user"].full_name)
    db.add(doc);db.flush();audit(db,context["user"].full_name,"CREATE","Documents",doc.id,payload,ip_of(request));db.commit();return {"ok":True,"id":doc.id}


# ---------------- Client File Making ----------------
@router.get("/bookings/{booking_id}/client-file")
def get_client_file(booking_id: int, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    booking, plot, customer = _client_file_context(db, booking_id)
    item = db.scalar(select(ClientFile).where(ClientFile.booking_id == booking_id))
    if not item:
        raise HTTPException(404, "Client file has not been created for this booking")
    return {"file": model_dict(item, ["id", "file_no", "booking_id", "customer_id", "status", "booking_acknowledgment", "payment_acknowledgment", "terms_and_conditions", "notes", "prepared_by", "version", "created_at", "updated_at"]),
            "booking": {"booking_no": booking.booking_no, "booking_date": booking.booking_date, "payment_plan": booking.payment_plan, "net_sale_value": float(booking.net_sale_value or 0)},
            "customer": model_dict(customer, ["id", "name", "father_name", "cnic", "mobile", "email", "address"]),
            "plot": model_dict(plot, ["id", "plot_no", "block", "category", "size_marla", "received", "outstanding"])}


@router.patch("/client-files/{file_id}")
def update_client_file(file_id: int, payload: dict, request: Request, context=Depends(csrf_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    item = db.get(ClientFile, file_id)
    if not item:
        raise HTTPException(404, "Client file not found")
    if int(payload.get("version", item.version)) != item.version:
        raise HTTPException(409, "Client file changed by another user; reopen it before saving")
    for field in ("booking_acknowledgment", "payment_acknowledgment", "terms_and_conditions", "notes", "status"):
        if field in payload:
            setattr(item, field, str(payload[field] or "").strip())
    item.version += 1
    audit(db, context["user"].full_name, "UPDATE", "Client File", item.id, {"file_no": item.file_no, "status": item.status}, ip_of(request))
    db.commit()
    return {"ok": True, "id": item.id, "version": item.version, "pdf_url": f"/api/client-files/{item.id}/pdf"}


@router.get("/client-files/{file_id}/pdf")
def download_client_file(file_id: int, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    item = db.get(ClientFile, file_id)
    if not item:
        raise HTTPException(404, "Client file not found")
    booking, plot, customer = _client_file_context(db, item.booking_id)
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=16*mm, bottomMargin=16*mm)
    styles = getSampleStyleSheet(); body = styles["BodyText"]; body.leading = 15
    title = styles["Title"]; title.textColor = colors.HexColor("#17365D")
    story = [Paragraph(f"{html_escape(PROJECT_NAME)} - Client File", title), Spacer(1, 4*mm),
             Paragraph(f"<b>Client File No:</b> {html_escape(item.file_no)} &nbsp;&nbsp; <b>Status:</b> {html_escape(item.status)}", body), Spacer(1, 4*mm)]
    table = Table([["Customer", customer.name], ["Father / Guardian", customer.father_name or "-"], ["CNIC", customer.cnic or "-"], ["Mobile", customer.mobile or "-"], ["Booking", booking.booking_no], ["Booking Date", booking.booking_date.strftime("%d-%m-%Y")], ["Plot", f"{plot.plot_no} - {plot.block} ({plot.category}, {plot.size_marla:g} Marla)"], ["Net Sale Value", fmt_money(booking.net_sale_value)], ["Payment Plan", booking.payment_plan], ["Received / Outstanding", f"{fmt_money(plot.received)} / {fmt_money(plot.outstanding)}"]], colWidths=[48*mm, 126*mm])
    table.setStyle(TableStyle([("BACKGROUND", (0,0), (0,-1), colors.HexColor("#EAF1F8")), ("GRID", (0,0), (-1,-1), .35, colors.HexColor("#AAB7C4")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"), ("PADDING", (0,0), (-1,-1), 6)]))
    story += [table, Spacer(1, 7*mm)]
    for heading, text in (("Booking Acknowledgment", item.booking_acknowledgment), ("Final / Down-Payment Acknowledgment", item.payment_acknowledgment), ("Terms & Conditions", item.terms_and_conditions)):
        story += [Paragraph(heading, styles["Heading2"]), Paragraph(html_escape(text or "-").replace("\n", "<br/>"), body), Spacer(1, 5*mm)]
    if item.notes:
        story += [Paragraph("Notes", styles["Heading2"]), Paragraph(html_escape(item.notes).replace("\n", "<br/>"), body)]
    story += [Spacer(1, 12*mm), Table([["Customer Signature: ____________________", "Authorized Signatory: ____________________"]], colWidths=[87*mm, 87*mm])]
    doc.build(story)
    audit(db, context["user"].full_name, "DOWNLOAD", "Client File", item.id, {"file_no": item.file_no}, "")
    db.commit(); buffer.seek(0)
    return StreamingResponse(buffer, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{item.file_no}.pdf"'})


@router.get("/users")
def list_users(request: Request, context=Depends(require_roles("Admin")),db:Session=Depends(get_db)):
    stmt=select(User)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "username": User.username, "full_name": User.full_name, "role": User.role, "customer_id": User.customer_id,
        "active": User.active, "created_at": User.created_at,
    }, "role", "asc", secondary=User.username.asc())
    rows=db.scalars(stmt).all()
    return {"items":[model_dict(x,["id","username","full_name","role","customer_id","active","version","created_at"]) for x in rows]}


@router.post("/users")
def add_user(payload:dict,request:Request,context=Depends(csrf_roles("Admin")),db:Session=Depends(get_db)):
    username=str(payload.get("username") or "").strip().lower();password=str(payload.get("password") or "")
    if not username or len(password)<8: raise HTTPException(400,"Username and a password of at least 8 characters are required")
    user=User(username=username,full_name=str(payload.get("full_name") or username),role=str(payload.get("role") or "Sales"),password_hash=hash_password(password),customer_id=int(payload["customer_id"]) if payload.get("customer_id") else None,active=bool(payload.get("active",True)))
    db.add(user);db.flush();audit(db,context["user"].full_name,"CREATE","Users",user.id,{"username":username,"role":user.role},ip_of(request));db.commit();return {"ok":True,"id":user.id}


@router.patch("/users/{user_id}")
def edit_user(user_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Admin")),db:Session=Depends(get_db)):
    user=db.get(User,user_id)
    if not user: raise HTTPException(404,"User not found")
    for f in ["full_name","role","active"]:
        if f in payload: setattr(user,f,bool(payload[f]) if f=="active" else str(payload[f] or ""))
    if "customer_id" in payload:user.customer_id=int(payload["customer_id"]) if payload["customer_id"] else None
    if payload.get("password"):
        if len(str(payload["password"]))<8:raise HTTPException(400,"Password must have at least 8 characters")
        user.password_hash=hash_password(str(payload["password"]))
    user.version+=1;audit(db,context["user"].full_name,"UPDATE","Users",user.id,{"role":user.role,"active":user.active},ip_of(request));db.commit();return {"ok":True,"version":user.version}


@router.post("/change-password")
def change_password(payload:dict,request:Request,context=Depends(csrf_protect),db:Session=Depends(get_db)):
    user=db.get(User,context["user"].id);current=str(payload.get("current_password") or "");new=str(payload.get("new_password") or "")
    if not verify_password(current,user.password_hash):raise HTTPException(400,"Current password is incorrect")
    if len(new)<8:raise HTTPException(400,"New password must have at least 8 characters")
    user.password_hash=hash_password(new);user.version+=1;audit(db,user.full_name,"CHANGE_PASSWORD","Security",user.id,"Password changed",ip_of(request));db.commit();return {"ok":True}


# ---------------- Customer Portal ----------------
@router.get("/customer/portal")
def customer_portal(context=Depends(require_roles("Customer")), db: Session = Depends(get_db)):
    user = context["user"]
    if not user.customer_id: raise HTTPException(404, "Customer profile is not linked")
    customer = db.get(Customer, user.customer_id)
    plots = db.scalars(select(Plot).where(Plot.customer_id == customer.id).order_by(Plot.plot_no)).all()
    bookings = db.scalars(select(Booking).where(Booking.customer_id == customer.id).order_by(desc(Booking.id))).all()
    booking_ids = [b.id for b in bookings]
    receipts = db.scalars(select(Receipt).where(or_(Receipt.customer_id == customer.id, Receipt.booking_id.in_(booking_ids) if booking_ids else False)).order_by(desc(Receipt.receipt_date))).all()
    installments = db.scalars(select(Installment).where(Installment.booking_id.in_(booking_ids)).order_by(Installment.due_date)).all() if booking_ids else []
    return {
        "customer": model_dict(customer, ["id", "code", "name", "cnic", "mobile", "email", "address"]),
        "summary": {"total_sale_value": sum(float(p.sale_price or 0) for p in plots), "received": sum(float(p.received or 0) for p in plots), "outstanding": sum(float(p.outstanding or 0) for p in plots)},
        "plots": [model_dict(p, ["id", "plot_no", "block", "category", "size_marla", "status", "sale_price", "received", "outstanding", "payment_status", "chz_no"]) for p in plots],
        "receipts": [model_dict(r, ["id", "receipt_no", "receipt_date", "amount", "mode", "reference", "narration"]) for r in receipts],
        "installments": [{**model_dict(i, ["id", "booking_id", "due_no", "due_date", "due_type", "amount", "paid", "status"]), "balance": float(i.amount) - float(i.paid)} for i in installments],
    }


@router.get("/notifications")
def notifications(context=Depends(get_current_context), db: Session = Depends(get_db)):
    user = context["user"]
    rows = db.scalars(select(Notification).where(or_(Notification.user_id == user.id, Notification.role == user.role, Notification.role == "")).order_by(desc(Notification.id)).limit(30)).all()
    return {"items": [model_dict(x, ["id", "title", "message", "link", "read", "created_at"]) for x in rows]}


@router.post("/notifications/{notification_id}/read")
def mark_notification(notification_id: int, context=Depends(csrf_protect), db: Session = Depends(get_db)):
    n = db.get(Notification, notification_id)
    if n: n.read = True; db.commit()
    return {"ok": True}


# ---------------- WhatsApp Business Cloud API ----------------
@router.get("/whatsapp/settings")
def whatsapp_settings(context=Depends(require_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    return public_whatsapp_config(db)


@router.post("/whatsapp/settings")
def update_whatsapp_settings(payload: dict, request: Request, context=Depends(csrf_roles("Admin", "Finance")), db: Session = Depends(get_db)):
    save_whatsapp_config(db, payload)
    audit(db, context["user"].full_name, "UPDATE", "WhatsApp Settings", "config", {
        "enabled": bool(payload.get("enabled")),
        "api_version": payload.get("api_version"),
        "phone_number_id": payload.get("phone_number_id"),
        "booking_template": payload.get("booking_template"),
        "due_template": payload.get("due_template"),
        "auto_booking": bool(payload.get("auto_booking")),
        "token_updated": bool(str(payload.get("access_token") or "").strip()),
    }, ip_of(request))
    db.commit()
    return {"ok": True, **public_whatsapp_config(db)}


@router.get("/whatsapp/logs")
def whatsapp_logs(request: Request, context=Depends(require_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request); filters=[]
    if q:
        p=f"%{q}%"; filters.append(or_(WhatsAppMessageLog.mobile.ilike(p), WhatsAppMessageLog.message_type.ilike(p), WhatsAppMessageLog.status.ilike(p), WhatsAppMessageLog.template_name.ilike(p)))
    stmt=select(WhatsAppMessageLog).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "created_at": WhatsAppMessageLog.created_at, "message_type": WhatsAppMessageLog.message_type, "mobile": WhatsAppMessageLog.mobile,
        "template_name": WhatsAppMessageLog.template_name, "status": WhatsAppMessageLog.status, "sent_by": WhatsAppMessageLog.sent_by,
        "sent_at": WhatsAppMessageLog.sent_at, "booking_id": WhatsAppMessageLog.booking_id, "installment_id": WhatsAppMessageLog.installment_id,
    }, "created_at", "desc", secondary=WhatsAppMessageLog.id.desc())
    count_stmt=select(func.count()).select_from(WhatsAppMessageLog).where(*filters)
    rows=db.scalars(stmt.offset((page-1)*size).limit(size)).all(); total=db.scalar(count_stmt) or 0
    fields=["id","message_type","customer_id","booking_id","installment_id","mobile","template_name","provider_message_id","status","error_message","sent_by","sent_at","created_at"]
    return {"items":[model_dict(x,fields) for x in rows],"total":total,"page":page,"size":size}


@router.get("/whatsapp/bookings/{booking_id}/preview")
def whatsapp_booking_preview(booking_id: int, context=Depends(require_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    try:
        booking, plot, customer = _booking_whatsapp_context(db, booking_id)
        cfg=get_whatsapp_config(db)
        text=(f"Horizon Homes booking confirmation\nCustomer: {customer.name}\nBooking: {booking.booking_no}\n"
              f"Plot: {plot.plot_no}\nSale value: {fmt_money(booking.net_sale_value)}\nReceived: {fmt_money(plot.received)}\n"
              f"Outstanding: {fmt_money(plot.outstanding)}")
        link=make_wa_link(customer.mobile, text, cfg["default_country_code"])
        return {"mobile":customer.mobile,"customer":customer.name,"plot_no":plot.plot_no,"booking_no":booking.booking_no,"message":text,"wa_link":link,"api_enabled":cfg["enabled"]}
    except ValueError as exc:
        error(exc)


@router.get("/whatsapp/installments/{installment_id}/preview")
def whatsapp_due_preview(installment_id: int, context=Depends(require_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    row=db.execute(select(Installment,Booking,Plot,Customer).join(Booking,Booking.id==Installment.booking_id).join(Plot,Plot.id==Booking.plot_id).join(Customer,Customer.id==Booking.customer_id).where(Installment.id==installment_id)).first()
    if not row: raise HTTPException(404,"Installment not found")
    ins,booking,plot,customer=row; due=max(0,float(ins.amount or 0)-float(ins.paid or 0)); cfg=get_whatsapp_config(db)
    text=(f"Horizon Homes payment reminder\nCustomer: {customer.name}\nPlot: {plot.plot_no}\n{ins.due_type}: {fmt_money(due)}\n"
          f"Due date: {ins.due_date.strftime('%d-%m-%Y')}\nTotal outstanding: {fmt_money(plot.outstanding)}")
    try: link=make_wa_link(customer.mobile,text,cfg["default_country_code"])
    except ValueError as exc: error(exc)
    return {"mobile":customer.mobile,"customer":customer.name,"plot_no":plot.plot_no,"due":due,"due_date":ins.due_date,"message":text,"wa_link":link,"api_enabled":cfg["enabled"]}


@router.post("/whatsapp/bookings/{booking_id}/send")
def send_booking_whatsapp(booking_id: int, request: Request, context=Depends(csrf_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    try:
        log=_send_booking_whatsapp(db,booking_id,context["user"].full_name)
        audit(db,context["user"].full_name,"SEND","WhatsApp",log.id,{"type":"Booking Confirmation","booking_id":booking_id,"status":log.status},ip_of(request))
        db.commit(); return {"ok":True,"log_id":log.id,"status":log.status,"message_id":log.provider_message_id}
    except ValueError as exc:
        # Keep the failed-send audit log when the provider returns an error.
        try: db.commit()
        except Exception: db.rollback()
        error(exc)


@router.post("/whatsapp/installments/{installment_id}/send")
def send_due_whatsapp(installment_id: int, request: Request, context=Depends(csrf_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    try:
        log=_send_due_whatsapp(db,installment_id,context["user"].full_name)
        audit(db,context["user"].full_name,"SEND","WhatsApp",log.id,{"type":"Due Reminder","installment_id":installment_id,"status":log.status},ip_of(request))
        db.commit(); return {"ok":True,"log_id":log.id,"status":log.status,"message_id":log.provider_message_id}
    except ValueError as exc:
        try: db.commit()
        except Exception: db.rollback()
        error(exc)


@router.post("/whatsapp/due-reminders/send")
def send_bulk_due_whatsapp(payload: dict, request: Request, context=Depends(csrf_roles("Finance", "Sales")), db: Session = Depends(get_db)):
    days_ahead=max(0,min(60,int(payload.get("days_ahead") or 0)))
    max_messages=max(1,min(100,int(payload.get("max_messages") or 50)))
    force=bool(payload.get("force",False))
    cutoff=date.today()+timedelta(days=days_ahead)
    rows=db.scalars(select(Installment).where(Installment.due_date<=cutoff,(Installment.amount-Installment.paid)>0,Installment.status.in_(["Due","Partial"])).order_by(Installment.due_date,Installment.id).limit(max_messages*2)).all()
    sent=[]; failed=[]; skipped=[]
    recent_cutoff=datetime.utcnow()-timedelta(hours=20)
    for ins in rows:
        if len(sent)+len(failed)>=max_messages: break
        if not force:
            recent=db.scalar(select(WhatsAppMessageLog).where(WhatsAppMessageLog.installment_id==ins.id,WhatsAppMessageLog.message_type=="Due Reminder",WhatsAppMessageLog.status=="Sent",WhatsAppMessageLog.sent_at>=recent_cutoff).order_by(desc(WhatsAppMessageLog.id)))
            if recent:
                skipped.append({"installment_id":ins.id,"reason":"Already sent within 20 hours"}); continue
        try:
            log=_send_due_whatsapp(db,ins.id,context["user"].full_name); sent.append({"installment_id":ins.id,"log_id":log.id,"message_id":log.provider_message_id})
        except Exception as exc:
            failed.append({"installment_id":ins.id,"error":str(exc)})
    audit(db,context["user"].full_name,"BULK_SEND","WhatsApp","due-reminders",{"sent":len(sent),"failed":len(failed),"skipped":len(skipped),"days_ahead":days_ahead},ip_of(request))
    db.commit()
    return {"ok":True,"sent":sent,"failed":failed,"skipped":skipped,"cutoff":cutoff.isoformat()}


@router.post("/whatsapp/test")
def whatsapp_test(payload: dict, request: Request, context=Depends(csrf_roles("Admin", "Finance")), db: Session = Depends(get_db)):
    cfg=get_whatsapp_config(db); template_type=str(payload.get("template_type") or "Booking").strip().lower(); mobile=str(payload.get("mobile") or "").strip()
    if template_type=="due":
        template=cfg["due_template"]; params=["Test Customer","TEST-01","Monthly Installment",date.today().strftime("%d-%m-%Y"),"Rs 100,000","Rs 500,000"]
        message_type="API Test - Due"
    else:
        template=cfg["booking_template"]; params=["Test Customer","TEST-BKG","TEST-01","Rs 4,950,000","Rs 650,000","Rs 4,300,000"]
        message_type="API Test - Booking"
    try:
        log=send_template_message(db,mobile=mobile,template_name=template,parameters=params,message_type=message_type,sent_by=context["user"].full_name)
        audit(db,context["user"].full_name,"TEST","WhatsApp",log.id,{"mobile":mobile,"template":template,"status":log.status},ip_of(request)); db.commit()
        return {"ok":True,"status":log.status,"message_id":log.provider_message_id}
    except ValueError as exc:
        try: db.commit()
        except Exception: db.rollback()
        error(exc)


# ---------------- V12 Data Migration & Reconciliation ----------------

def _migration_batch_dict(x: MigrationBatch):
    return {"id":x.id,"batch_no":x.batch_no,"file_name":x.file_name,"file_hash":x.file_hash,"imported_by":x.imported_by,
      "source_rows":x.source_rows,"imported_count":x.imported_count,"skipped_count":x.skipped_count,"duplicate_count":x.duplicate_count,
      "mismatch_count":x.mismatch_count,"matched_count":x.matched_count,"debit_total":float(x.debit_total or 0),"credit_total":float(x.credit_total or 0),
      "status":x.status,"notes":x.notes,"created_at":x.created_at.isoformat() if x.created_at else None}

def _migration_row_dict(x: MigrationRow):
    return {
        "id": x.id, "batch_id": x.batch_id, "migration_key": x.migration_key,
        "source_workbook": x.source_workbook, "source_sheet": x.source_sheet, "source_row": x.source_row,
        "voucher_no": x.voucher_no, "transaction_date": x.transaction_date.isoformat() if x.transaction_date else None,
        "source_account": x.source_account, "particulars": x.particulars, "paid_received_by": x.paid_received_by,
        "debit_account": x.debit_account, "credit_account": x.credit_account, "debit": float(x.debit or 0),
        "credit": float(x.credit or 0), "customer_reference": x.customer_reference, "plot_no": x.plot_no,
        "party_name": x.party_name, "reconciliation_status": x.reconciliation_status,
        "mismatch_details": x.mismatch_details, "erp_voucher_id": x.erp_voucher_id, "posted": x.posted
    }

def _parse_excel_date(value):
    if value in (None, ""): return None
    if isinstance(value, datetime): return value.date()
    if isinstance(value, date): return value
    if isinstance(value,(int,float)):
        try:
            from openpyxl.utils.datetime import from_excel
            x=from_excel(value); return x.date() if isinstance(x,datetime) else x
        except Exception: return None
    raw=str(value).strip()
    for fmt in ("%d-%m-%y","%d-%m-%Y","%d/%m/%Y","%Y-%m-%d","%m-%d-%Y"):
        try: return datetime.strptime(raw,fmt).date()
        except ValueError: pass
    return None

def _source_counterparty(paid_by: str) -> str:
    who=(paid_by or "").strip().lower()
    if who=="salman": return "Director Current Account - Salman"
    if who=="humayun": return "Director Current Account - Humayun"
    if who=="adnan": return "Adnan Director Current A/C"
    if who=="mustafa": return "Mustafa Imprest / Payable"
    if who in ("chz","crescent horizon","crescent horizon developers"): return "Cash on Hand"
    return "Cash on Hand"

def _map_horizon_source_row(account: str, particulars: str, paid_by: str, dr: float, cr: float):
    a=(account or "").strip().upper(); p=(particulars or "").strip().upper(); who=(paid_by or "").strip()
    amount=float(dr or cr or 0); is_receipt=float(cr or 0)>0 and float(dr or 0)==0
    cash="Cash on Hand" if who.strip().lower() in ("chz","loan","") else ("Cash Held by Salman" if who.strip().lower()=="salman" else ("Cash Held by Humayun" if who.strip().lower()=="humayun" else "Cash on Hand"))
    fund=_source_counterparty(who)
    if a=="SALE PAYMENT": return cash, "Customer Advances / Plot Sale Receipts", amount, "Auto-mapped sale receipt"
    if a in ("SITE EXPENSES","SITE EXPENSE"): return "Development Cost - Site Expenses", fund, amount, "Auto-mapped site expense"
    if a=="CONTRACTOR": return "Development Cost - Contractor & Materials", fund, amount, "Auto-mapped contractor/development cost"
    if a=="LAND PAYMENT": return "Land Inventory - Horizon Homes", fund, amount, "Auto-mapped land payment"
    if a=="RUDA": return "RUDA & Government Charges", fund, amount, "Auto-mapped RUDA/government charge"
    if a=="COMMISSION": return "Sales Commission Expense", fund, amount, "Auto-mapped sales commission"
    if a=="GT ROAD OFFICE EXP":
        if "PETTY CASH" in p and who.strip().lower()=="mustafa" and is_receipt:
            return "Cash on Hand", "Petty Cash - Mustafa", amount, "Petty cash returned by Mustafa"
        return "Administrative Expenses - GT Road Office", fund, amount, "Auto-mapped GT Road office expense"
    if a in ("ASSESTS","ASSETS"): return "Site Equipment / Container", fund, amount, "Auto-mapped site asset"
    if a=="LOAN RETURN":
        if "ADNAN" in p: return "Loan Payable - Adnan", fund, amount, "Loan repayment to Adnan"
        if "HUMAYUN" in p: return "Loan Payable - Humayun", fund, amount, "Loan repayment to Humayun"
        if "QASIM" in p: return "Loan Payable - Qasim", fund, amount, "Loan repayment to Qasim"
        if "SHER" in p or "SHAIR" in p: return "Loan Payable - Sher Bano", fund, amount, "Loan repayment"
        return "", "", amount, "Requires Review: loan return beneficiary is unclear"
    if a in ("LOAN","HUMAYUN LOAN","SALMAN LOAN","ADNAN LOAN"):
        if "RETURN" in p and "ADNAN" in p: return "Loan Payable - Adnan", fund, amount, "Loan repayment to Adnan"
        if "RETURN" in p and "HUMAYUN" in p: return "Loan Payable - Humayun", fund, amount, "Loan repayment to Humayun"
        if "RECEIVED" in p:
            if "HUMAYUN" in p: return "Cash on Hand", "Loan Payable - Humayun", amount, "Loan received from Humayun"
            if "ADNAN" in p: return "Cash on Hand", "Loan Payable - Adnan", amount, "Loan received from Adnan"
            if "SALMAN" in p: return "Cash on Hand", "Loan Payable - Salman", amount, "Loan received from Salman"
        if "TO HUMAYUN" in p: return "Director Receivable - Humayun", fund, amount, "Loan/advance to Humayun"
        if "TO SALMAN" in p: return "Director Receivable - Salman", fund, amount, "Loan/advance to Salman"
        if "TO ADNAN" in p: return "Director Receivable - Adnan", fund, amount, "Loan/advance to Adnan"
    return "", "", amount, f"Requires Review: no approved mapping for source account {account}"

def _read_horizon_fast(path: str):
    import zipfile, re, xml.etree.ElementTree as ET
    ns={"m":"http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with zipfile.ZipFile(path) as z:
        wbroot=ET.fromstring(z.read("xl/workbook.xml")); names=[x.attrib.get("name","") for x in wbroot.findall(".//m:sheets/m:sheet",ns)]
        if "Horizon" not in names: return None
        # Horizon source workbook supplied by the company uses the first worksheet.
        shared=[]
        if "xl/sharedStrings.xml" in z.namelist():
            root=ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si",ns): shared.append("".join(t.text or "" for t in si.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
        root=ET.fromstring(z.read("xl/worksheets/sheet1.xml")); source=[]; journal={}
        for row in root.findall(".//m:sheetData/m:row",ns):
            r=int(row.attrib.get("r","0"))
            if r<4: continue
            vals={}
            for c in row.findall("m:c",ns):
                ref=c.attrib.get("r",""); m=re.match(r"[A-Z]+",ref)
                if not m: continue
                col=m.group(); typ=c.attrib.get("t"); node=c.find("m:v",ns); val=node.text if node is not None else None
                if typ=="s" and val is not None: val=shared[int(val)]
                elif typ=="inlineStr": val="".join(t.text or "" for t in c.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"))
                vals[col]=val
            dt,acct,part,paid,dr,cr=vals.get("A"),vals.get("B"),vals.get("D"),vals.get("E"),vals.get("F"),vals.get("G")
            if not any(v not in (None,"") for v in (dt,acct,part,paid,dr,cr)): continue
            try: drf=float(dr or 0); crf=float(cr or 0)
            except Exception: continue
            if drf and crf: debit_acct=credit_acct=""; note="Requires Review: both DR and CR entered on one source row"; amount=max(abs(drf),abs(crf))
            else: debit_acct,credit_acct,amount,note=_map_horizon_source_row(str(acct or ""),str(part or ""),str(paid or ""),drf,crf)
            vno=f"JV-{r-3:04d}"
            source.append({"Source Row":r,"Date":dt,"Account Name":str(acct or ""),"Particular":str(part or ""),"Paid By / Received By":str(paid or ""),"Source DR":drf,"Source CR":crf,"Mapping Note":note})
            journal[vno]={"Voucher":vno,"Date":dt,"Debit Account":debit_acct,"Credit Account":credit_acct,"Debit":amount,"Credit":amount,"Mapping Note":note}
        return source,journal,[],"horizon"

def _read_master_workbook(path: str):
    fast=_read_horizon_fast(path)
    if fast is not None: return fast
    from openpyxl import load_workbook
    wb=load_workbook(path,read_only=True,data_only=True)
    # Enterprise 3-sheet migration workbook remains supported.
    if all(s in wb.sheetnames for s in ["Source Ledger","Double Entry Journal","Chart of Accounts"]):
        journal={}; ws=wb["Double Entry Journal"]; iterator=ws.iter_rows(values_only=True); headers=[str(v or "").strip() for v in next(iterator)]
        for vals in iterator:
            row=dict(zip(headers,vals)); voucher=str(row.get("Voucher") or "").strip()
            if voucher.startswith("JV-"): journal[voucher]=row
        source=[]; ws=wb["Source Ledger"]; iterator=ws.iter_rows(values_only=True); headers=[str(v or "").strip() for v in next(iterator)]
        for vals in iterator:
            row=dict(zip(headers,vals))
            if row.get("Source Row") in (None,"") or not isinstance(row.get("Source Row"),(int,float)): continue
            source.append(row)
        accounts=[]; ws=wb["Chart of Accounts"]; iterator=ws.iter_rows(values_only=True); headers=[str(v or "").strip() for v in next(iterator)]
        for vals in iterator:
            row=dict(zip(headers,vals))
            if row.get("Account Name"): accounts.append(row)
        return source,journal,accounts,"enterprise"
    # Direct Horizon source ledger template: DATE / Account Name / PARTICULAR / PAID BY / DR / CR.
    if "Horizon" not in wb.sheetnames: raise ValueError("Unsupported workbook. Expected either Horizon sheet or Source Ledger + Double Entry Journal + Chart of Accounts.")
    ws=wb["Horizon"]; source=[]; journal={}
    for r in range(4,ws.max_row+1):
        dt,acct,code,part,paid,dr,cr=[ws.cell(r,c).value for c in range(1,8)]
        if not any(v not in (None,"") for v in (dt,acct,part,paid,dr,cr)): continue
        try: drf=float(dr or 0); crf=float(cr or 0)
        except Exception: continue
        if drf and crf: debit_acct=credit_acct=""; note="Requires Review: both DR and CR entered on one source row"; amount=max(abs(drf),abs(crf))
        else: debit_acct,credit_acct,amount,note=_map_horizon_source_row(str(acct or ""),str(part or ""),str(paid or ""),drf,crf)
        vno=f"JV-{r-3:04d}"
        source.append({"Source Row":r,"Date":dt,"Account Name":str(acct or ""),"Particular":str(part or ""),"Paid By / Received By":str(paid or ""),"Source DR":drf,"Source CR":crf,"Mapping Note":note})
        journal[vno]={"Voucher":vno,"Date":dt,"Debit Account":debit_acct,"Credit Account":credit_acct,"Debit":amount,"Credit":amount,"Mapping Note":note}
    return source,journal,[],"horizon"

def _reconcile_batch(db: Session, batch: MigrationBatch):
    rows=db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch.id)).all()
    matched=duplicates=mismatches=0
    seen=set()
    for row in rows:
        if row.migration_key in seen:
            row.reconciliation_status="Duplicate in ERP"; row.mismatch_details="Duplicate migration key within batch"; duplicates+=1; continue
        seen.add(row.migration_key)
        voucher=db.scalar(select(Voucher).where(Voucher.voucher_no==row.voucher_no))
        if not voucher:
            row.reconciliation_status="Missing in ERP"; row.mismatch_details="Voucher not found"; mismatches+=1; continue
        lines=db.scalars(select(VoucherLine).where(VoucherLine.voucher_id==voucher.id)).all()
        debit=sum(float(x.debit or 0) for x in lines); credit=sum(float(x.credit or 0) for x in lines)
        names={db.get(Account,x.account_id).name for x in lines if db.get(Account,x.account_id)}
        issues=[]
        if abs(debit-float(row.debit or 0))>.005 or abs(credit-float(row.credit or 0))>.005: issues.append("Amount Mismatch")
        if row.debit_account and row.debit_account not in names: issues.append("Debit account mismatch")
        if row.credit_account and row.credit_account not in names: issues.append("Credit account mismatch")
        if row.transaction_date and voucher.voucher_date!=row.transaction_date: issues.append("Date Mismatch")
        if abs(debit-credit)>.005: issues.append("Unbalanced Voucher")
        if issues:
            row.reconciliation_status=issues[0] if issues[0] in ["Amount Mismatch","Date Mismatch","Unbalanced Voucher"] else "Account Mismatch"
            row.mismatch_details="; ".join(issues); mismatches+=1
        else:
            row.reconciliation_status="Matched"; row.mismatch_details=""; row.erp_voucher_id=voucher.id; row.posted=(voucher.status=="Posted"); matched+=1
    batch.matched_count=matched; batch.duplicate_count=duplicates; batch.mismatch_count=mismatches
    batch.skipped_count=matched; batch.status="Completed" if mismatches==0 and duplicates==0 else "Requires Review"
    return batch

def _norm_source_text(value):
    import re
    return re.sub(r"\s+"," ",str(value or "").strip().lower())

def _source_signature(row):
    return (_norm_source_text(row.source_account),_norm_source_text(row.particulars),_norm_source_text(row.paid_received_by),round(float(row.debit or 0),2))

def _reconcile_horizon_batch(db: Session, batch: MigrationBatch):
    """Reconcile the editable single-sheet Horizon ledger by transaction fingerprint, not row position.
    This prevents inserted/reordered Excel rows from being mistaken for hundreds of changed vouchers.
    """
    from collections import defaultdict, deque
    rows=list(db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch.id).order_by(MigrationRow.source_row)).all())
    prior_batch=db.scalar(select(MigrationBatch).where(MigrationBatch.id!=batch.id).order_by(desc(MigrationBatch.id)))
    prior=list(db.scalars(select(MigrationRow).where(MigrationRow.batch_id==prior_batch.id).order_by(MigrationRow.source_row)).all()) if prior_batch else []
    buckets=defaultdict(deque)
    for x in prior: buckets[_source_signature(x)].append(x)
    matched=missing=review=0
    for row in rows:
        q=buckets.get(_source_signature(row))
        if q:
            old=q.popleft(); row.reconciliation_status="Matched"; row.mismatch_details=f"Matched prior source row {old.source_row} by transaction fingerprint"; row.erp_voucher_id=old.erp_voucher_id; row.posted=old.posted
            # Preserve the previously verified accounting classification for an unchanged transaction.
            row.debit_account=old.debit_account; row.credit_account=old.credit_account; matched+=1
        elif not row.debit_account or not row.credit_account:
            row.reconciliation_status="Requires Review"; row.mismatch_details=row.mismatch_details or "New/changed transaction requires account mapping review"; review+=1
        else:
            row.reconciliation_status="Missing in ERP"; row.mismatch_details="New or changed source transaction not yet posted"; missing+=1
    removed=sum(len(q) for q in buckets.values())
    batch.matched_count=matched; batch.mismatch_count=review+removed; batch.duplicate_count=0; batch.skipped_count=matched
    batch.status="Requires Review" if (review or removed) else ("Ready to Import" if missing else "Completed")
    batch.notes=(batch.notes or "")+f" | Fingerprint reconciliation: {matched} unchanged, {missing} new/changed ready, {review} mapping review, {removed} prior transactions no longer present (review before reversal)."
    return batch



def _refresh_migration_batch_counts(db: Session, batch: MigrationBatch):
    import re
    rows=list(db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch.id)).all())
    batch.matched_count=sum(x.reconciliation_status=="Matched" for x in rows)
    batch.duplicate_count=sum(x.reconciliation_status=="Duplicate in ERP" for x in rows)
    review_statuses={"Requires Review","Amount Mismatch","Account Mismatch","Date Mismatch","Unbalanced Voucher"}
    row_review=sum(x.reconciliation_status in review_statuses for x in rows)
    removed_review=0
    matches=re.findall(r"(\d+) prior transactions no longer present",batch.notes or "")
    if matches: removed_review=int(matches[-1])
    batch.mismatch_count=row_review+removed_review
    batch.imported_count=sum(bool(x.posted) and x.erp_voucher_id is not None for x in rows)
    missing=sum(x.reconciliation_status=="Missing in ERP" for x in rows)
    batch.status="Requires Review" if batch.mismatch_count else ("Ready to Import" if missing else "Completed")
    return rows

def _migration_existing_voucher(db: Session, row: MigrationRow):
    if row.erp_voucher_id:
        voucher=db.get(Voucher,row.erp_voucher_id)
        if voucher: return voucher
    voucher=db.scalar(select(Voucher).where(Voucher.source_module=="Master Excel Migration",Voucher.source_reference==row.migration_key).order_by(desc(Voucher.id)))
    if voucher: return voucher
    # Only the legacy 3-sheet import guarantees stable voucher numbers. Horizon single-sheet rows can move when rows are inserted.
    if row.source_sheet!="Horizon" and row.voucher_no:
        return db.scalar(select(Voucher).where(Voucher.voucher_no==row.voucher_no))
    return None

def _migration_voucher_accounts(db: Session, voucher: Voucher):
    rows=db.execute(select(VoucherLine,Account).join(Account,Account.id==VoucherLine.account_id).where(VoucherLine.voucher_id==voucher.id)).all()
    debit=[a.name for l,a in rows if float(l.debit or 0)>0]
    credit=[a.name for l,a in rows if float(l.credit or 0)>0]
    return debit,credit,round(sum(float(l.debit or 0) for l,a in rows),2),round(sum(float(l.credit or 0) for l,a in rows),2)

@router.get("/migration/summary")
def migration_summary(context=Depends(require_roles("Finance")), db: Session=Depends(get_db)):
    batches=db.scalars(select(MigrationBatch).order_by(desc(MigrationBatch.id))).all()
    latest=batches[0] if batches else None
    return {"control_totals":{"source_rows":latest.source_rows if latest else 364,"vouchers":latest.source_rows if latest else 364,"debit":float(latest.debit_total or 0) if latest else 138234677,"credit":float(latest.credit_total or 0) if latest else 138234677,"difference":round(float((latest.debit_total or 0)-(latest.credit_total or 0)),2) if latest else 0},
      "latest": _migration_batch_dict(latest) if latest else None, "batches":[_migration_batch_dict(x) for x in batches[:20]],
      "erp":{"vouchers":db.scalar(select(func.count()).select_from(Voucher)) or 0,
             "debit":float(db.scalar(select(func.coalesce(func.sum(VoucherLine.debit),0))) or 0),
             "credit":float(db.scalar(select(func.coalesce(func.sum(VoucherLine.credit),0))) or 0)}}

@router.get("/migration/rows")
def migration_rows(request: Request, context=Depends(require_roles("Finance")), db: Session=Depends(get_db)):
    page,size,q=page_params(request); status=request.query_params.get("status","").strip(); batch_id=request.query_params.get("batch_id")
    filters=[]
    if status: filters.append(MigrationRow.reconciliation_status==status)
    if batch_id: filters.append(MigrationRow.batch_id==int(batch_id))
    if q: filters.append(or_(MigrationRow.voucher_no.ilike(f"%{q}%"),MigrationRow.particulars.ilike(f"%{q}%"),MigrationRow.source_account.ilike(f"%{q}%")))
    stmt=select(MigrationRow).where(*filters)
    stmt, sort_by, sort_dir = apply_sort(request, stmt, {
        "source_row": MigrationRow.source_row, "voucher_no": MigrationRow.voucher_no, "transaction_date": MigrationRow.transaction_date,
        "source_account": MigrationRow.source_account, "particulars": MigrationRow.particulars, "paid_received_by": MigrationRow.paid_received_by,
        "debit_account": MigrationRow.debit_account, "credit_account": MigrationRow.credit_account, "debit": MigrationRow.debit, "credit": MigrationRow.credit,
        "reconciliation_status": MigrationRow.reconciliation_status,
    }, "source_row", "asc", secondary=MigrationRow.id.asc())
    total=db.scalar(select(func.count()).select_from(MigrationRow).where(*filters)) or 0
    items=db.scalars(stmt.offset((page-1)*size).limit(size)).all()
    return {"items":[_migration_row_dict(x) for x in items],"total":total,"page":page,"size":size}



@router.get("/migration/row/{row_id}")
def migration_row_detail(row_id:int, context=Depends(require_roles("Finance")), db: Session=Depends(get_db)):
    row=db.get(MigrationRow,row_id)
    if not row: raise HTTPException(404,"Migration transaction not found")
    data=_migration_row_dict(row)
    voucher=_migration_existing_voucher(db,row)
    if voucher:
        debit_accounts,credit_accounts,total_debit,total_credit=_migration_voucher_accounts(db,voucher)
        data["existing_voucher"]={"id":voucher.id,"voucher_no":voucher.voucher_no,"date":voucher.voucher_date.isoformat(),"status":voucher.status,"debit_accounts":debit_accounts,"credit_accounts":credit_accounts,"debit":total_debit,"credit":total_credit}
    else: data["existing_voucher"]=None
    return data

@router.post("/migration/row/{row_id}/approve-post")
def migration_approve_post(row_id:int, payload:dict, request:Request, context=Depends(csrf_roles("Finance")), db: Session=Depends(get_db)):
    row=db.get(MigrationRow,row_id)
    if not row: raise HTTPException(404,"Migration transaction not found")
    if row.reconciliation_status=="Duplicate in ERP":
        raise HTTPException(400,"Duplicate transactions cannot be approved for posting")

    debit_account=str(payload.get("debit_account") or row.debit_account or "").strip()
    credit_account=str(payload.get("credit_account") or row.credit_account or "").strip()
    if not debit_account or not credit_account:
        raise HTTPException(400,"Select both Debit Account and Credit Account before approval")
    if debit_account==credit_account:
        raise HTTPException(400,"Debit and credit accounts must be different")
    debit=round(float(row.debit or 0),2); credit=round(float(row.credit or 0),2)
    if debit<=0 or credit<=0 or abs(debit-credit)>.005:
        raise HTTPException(400,f"Transaction is not balanced. Debit {debit:,.2f}, Credit {credit:,.2f}")

    # Validate account names before any financial posting.
    debit_obj=db.scalar(select(Account).where(Account.name==debit_account))
    credit_obj=db.scalar(select(Account).where(Account.name==credit_account))
    if not debit_obj or not debit_obj.active: raise HTTPException(400,f"Debit account is invalid or inactive: {debit_account}")
    if not credit_obj or not credit_obj.active: raise HTTPException(400,f"Credit account is invalid or inactive: {credit_account}")

    tx_date=_parse_excel_date(payload.get("transaction_date")) or row.transaction_date
    narration=str(payload.get("particulars") or row.particulars or "").strip()
    party=str(payload.get("party_name") or row.party_name or row.paid_received_by or "").strip()
    plot_no=str(payload.get("plot_no") or row.plot_no or "").strip()
    customer_reference=str(payload.get("customer_reference") or row.customer_reference or "").strip()

    existing=_migration_existing_voucher(db,row)
    if existing:
        debit_accounts,credit_accounts,existing_debit,existing_credit=_migration_voucher_accounts(db,existing)
        same_accounts=(debit_account in debit_accounts and credit_account in credit_accounts)
        same_amount=(abs(existing_debit-debit)<=.005 and abs(existing_credit-credit)<=.005)
        same_date=(not tx_date or existing.voucher_date==tx_date)
        if not (same_accounts and same_amount and same_date):
            raise HTTPException(400,"The selected mapping does not match the existing posted ERP voucher. Select the existing Debit/Credit accounts to approve the match. If the posted voucher itself is wrong, reverse/repost it from Finance before approving this source row.")
        row.debit_account=debit_account; row.credit_account=credit_account; row.transaction_date=tx_date or existing.voucher_date
        row.particulars=narration; row.party_name=party; row.plot_no=plot_no; row.customer_reference=customer_reference
        row.erp_voucher_id=existing.id; row.posted=(existing.status=="Posted"); row.reconciliation_status="Matched"; row.mismatch_details="Approved against existing ERP voucher by "+context["user"].full_name
        batch=db.get(MigrationBatch,row.batch_id); _refresh_migration_batch_counts(db,batch)
        audit(db,context["user"].full_name,"APPROVE_EXISTING_MIGRATION","Data Migration",row.id,{"voucher":existing.voucher_no,"source_row":row.source_row},ip_of(request)); db.commit()
        return {"ok":True,"action":"matched_existing","voucher_no":existing.voucher_no,"message":"Approved and matched to the existing posted ERP voucher. No duplicate voucher was created."}

    # Prevent repeat source-reference posting even if the row linkage was lost.
    duplicate=db.scalar(select(Voucher).where(Voucher.source_module=="Master Excel Migration",Voucher.source_reference==row.migration_key))
    if duplicate:
        raise HTTPException(400,f"This source transaction is already posted as {duplicate.voucher_no}")

    voucher=create_voucher(db,voucher_date=tx_date or date(2026,1,1),voucher_type="Journal",party=party,narration=narration,
        lines=[{"account":debit_account,"debit":debit,"credit":0,"party":party,"plot_no":plot_no,"memo":customer_reference or narration},
               {"account":credit_account,"debit":0,"credit":credit,"party":party,"plot_no":plot_no,"memo":customer_reference or narration}],
        user_name=context["user"].full_name,source_module="Master Excel Migration",source_reference=row.migration_key,status="Posted",ip_address=ip_of(request))
    row.debit_account=debit_account; row.credit_account=credit_account; row.transaction_date=tx_date; row.particulars=narration; row.party_name=party; row.plot_no=plot_no; row.customer_reference=customer_reference
    row.erp_voucher_id=voucher.id; row.posted=True; row.reconciliation_status="Matched"; row.mismatch_details="Approved & posted by "+context["user"].full_name; row.voucher_no=voucher.voucher_no
    batch=db.get(MigrationBatch,row.batch_id); _refresh_migration_batch_counts(db,batch)
    audit(db,context["user"].full_name,"APPROVE_POST_MIGRATION","Data Migration",row.id,{"voucher":voucher.voucher_no,"source_row":row.source_row,"debit_account":debit_account,"credit_account":credit_account},ip_of(request)); db.commit()
    return {"ok":True,"action":"posted","voucher_no":voucher.voucher_no,"message":f"Approved and posted as {voucher.voucher_no}"}

@router.post("/migration/upload")
def migration_upload(file: UploadFile=File(...), context=Depends(csrf_roles("Finance")), db: Session=Depends(get_db)):
    if not file.filename.lower().endswith((".xlsx",".xlsm")): raise HTTPException(400,"Upload an Excel .xlsx or .xlsm workbook")
    content=file.file.read(); digest=hashlib.sha256(content).hexdigest()
    existing=db.scalar(select(MigrationBatch).where(MigrationBatch.file_hash==digest))
    if existing: return {"ok":True,"batch_id":existing.id,"batch_no":existing.batch_no,"message":"Workbook already validated; existing batch returned."}
    uploads=Path(__file__).resolve().parents[2]/"data"/"imports"; uploads.mkdir(parents=True,exist_ok=True)
    target=uploads/(datetime.utcnow().strftime("%Y%m%d_%H%M%S_")+Path(file.filename).name); target.write_bytes(content)
    source,journal,accounts,workbook_type=_read_master_workbook(str(target))
    batch=MigrationBatch(batch_no=next_number(db,MigrationBatch,"batch_no","MIG"),file_name=file.filename,file_hash=digest,imported_by=context["user"].full_name,source_rows=len(source),debit_total=sum(float((journal.get(f"JV-{int(x['Source Row'])-3:04d}") or {}).get("Debit") or 0) for x in source) if workbook_type=="horizon" else sum(float((journal.get(f"JV-{i+1:04d}") or {}).get("Debit") or 0) for i in range(len(source))),credit_total=sum(float((journal.get(f"JV-{int(x['Source Row'])-3:04d}") or {}).get("Credit") or 0) for x in source) if workbook_type=="horizon" else sum(float((journal.get(f"JV-{i+1:04d}") or {}).get("Credit") or 0) for i in range(len(source))),status="Validated",notes=f"Workbook type: {workbook_type}")
    db.add(batch); db.flush()
    for idx,s in enumerate(source,1):
        vno=f"JV-{int(s['Source Row'])-3:04d}" if workbook_type=="horizon" else f"JV-{idx:04d}"; j=journal.get(vno,{})
        source_sheet="Horizon" if workbook_type=="horizon" else "Source Ledger"
        key=f"{file.filename}|{source_sheet}|{int(s['Source Row'])}|{vno}"
        db.add(MigrationRow(batch_id=batch.id,migration_key=key,source_workbook=file.filename,source_sheet=source_sheet,source_row=int(s["Source Row"]),voucher_no=vno,transaction_date=_parse_excel_date(j.get("Date") or s.get("Date")),source_account=str(s.get("Account Name") or ""),particulars=str(s.get("Particular") or ""),paid_received_by=str(s.get("Paid By / Received By") or ""),debit_account=str(j.get("Debit Account") or ""),credit_account=str(j.get("Credit Account") or ""),debit=float(j.get("Debit") or 0),credit=float(j.get("Credit") or 0),party_name=str(s.get("Paid By / Received By") or ""),reconciliation_status="Requires Review"))
    db.flush()
    for mr in db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch.id)).all():
        if not mr.debit_account or not mr.credit_account:
            mr.mismatch_details=(journal.get(mr.voucher_no,{}) or {}).get("Mapping Note") or "Account mapping required"
    if workbook_type=="horizon": _reconcile_horizon_batch(db,batch)
    else: _reconcile_batch(db,batch)
    audit(db,context["user"].full_name,"UPLOAD_RECONCILE","Data Migration",batch.id,f"{file.filename}: {batch.source_rows} rows ({workbook_type})")
    db.commit(); return {"ok":True,"batch_id":batch.id,"batch_no":batch.batch_no,"status":batch.status,"matched":batch.matched_count,"mismatches":batch.mismatch_count}

@router.post("/migration/reconcile/{batch_id}")
def migration_reconcile(batch_id:int, context=Depends(csrf_roles("Finance")), db: Session=Depends(get_db)):
    batch=db.get(MigrationBatch,batch_id)
    if not batch: raise HTTPException(404,"Migration batch not found")
    has_horizon=db.scalar(select(func.count()).select_from(MigrationRow).where(MigrationRow.batch_id==batch.id,MigrationRow.source_sheet=="Horizon")) or 0
    if has_horizon: _reconcile_horizon_batch(db,batch)
    else: _reconcile_batch(db,batch)
    audit(db,context["user"].full_name,"RECONCILE","Data Migration",batch.id,batch.status); db.commit()
    return _migration_batch_dict(batch)

@router.post("/migration/post-verified/{batch_id}")
def migration_post_verified(batch_id:int, context=Depends(csrf_roles("Finance")), db: Session=Depends(get_db)):
    batch=db.get(MigrationBatch,batch_id)
    if not batch: raise HTTPException(404,"Migration batch not found")
    candidates=db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch_id,MigrationRow.reconciliation_status=="Missing in ERP",MigrationRow.posted.is_(False))).all()
    posted=0; failed=[]
    for row in candidates:
        try:
            voucher=create_voucher(db,voucher_date=row.transaction_date or date(2026,1,1),voucher_type="Journal",party=row.party_name,narration=row.particulars,
              lines=[{"account":row.debit_account,"debit":float(row.debit or 0),"credit":0,"party":row.party_name,"plot_no":row.plot_no},
                     {"account":row.credit_account,"debit":0,"credit":float(row.credit or 0),"party":row.party_name,"plot_no":row.plot_no}],
              user_name=context["user"].full_name,source_module="Master Excel Migration",source_reference=row.migration_key,status="Posted",voucher_no=None if row.source_sheet=="Horizon" else row.voucher_no)
            row.erp_voucher_id=voucher.id; row.posted=True; row.reconciliation_status="Matched"; row.mismatch_details=""; row.voucher_no=voucher.voucher_no; posted+=1
        except Exception as exc:
            row.reconciliation_status="Requires Review"; row.mismatch_details=str(exc); failed.append({"voucher":row.voucher_no,"error":str(exc)})
    if any(x.source_sheet=="Horizon" for x in candidates):
        allrows=list(db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch.id)).all())
        batch.matched_count=sum(x.reconciliation_status=="Matched" for x in allrows); batch.mismatch_count=sum(x.reconciliation_status=="Requires Review" for x in allrows); batch.status="Requires Review" if batch.mismatch_count else "Completed"
    else: _reconcile_batch(db,batch)
    batch.imported_count += posted
    audit(db,context["user"].full_name,"POST_VERIFIED","Data Migration",batch.id,{"posted":posted,"failed":len(failed)}); db.commit()
    return {"ok":True,"posted":posted,"failed":failed,"batch":_migration_batch_dict(batch)}

@router.post("/migration/rollback/{batch_id}")
def migration_rollback(batch_id:int, context=Depends(csrf_roles("Finance")), db: Session=Depends(get_db)):
    batch=db.get(MigrationBatch,batch_id)
    if not batch: raise HTTPException(404,"Migration batch not found")
    rows=db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch_id,MigrationRow.erp_voucher_id.is_not(None))).all()
    removed=0; protected=0
    for row in rows:
        voucher=db.get(Voucher,row.erp_voucher_id)
        if voucher and voucher.source_module=="Master Excel Migration" and voucher.status=="Draft":
            db.delete(voucher); row.erp_voucher_id=None; row.posted=False; row.reconciliation_status="Missing in ERP"; removed+=1
        elif voucher and voucher.source_module=="Master Excel Migration": protected+=1
    batch.status="Rolled Back" if removed else batch.status
    audit(db,context["user"].full_name,"ROLLBACK_BATCH","Data Migration",batch.id,{"draft_vouchers_removed":removed,"posted_protected":protected}); db.commit()
    return {"ok":True,"draft_vouchers_removed":removed,"posted_vouchers_protected":protected,"message":"Posted vouchers were not deleted. Use controlled reversal for posted entries."}

@router.get("/migration/export.xlsx")
def migration_export_xlsx(batch_id:int|None=None, context=Depends(require_roles("Finance")), db: Session=Depends(get_db)):
    from openpyxl import Workbook
    rows=db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch_id) if batch_id else select(MigrationRow).order_by(MigrationRow.batch_id,MigrationRow.source_row)).all()
    wb=Workbook(); ws=wb.active; ws.title="Reconciliation"
    headers=["Batch","Source Row","Voucher","Date","Source Account","Particulars","Paid/Received By","Debit Account","Credit Account","Debit","Credit","Status","Mismatch Details"]
    ws.append(headers)
    for x in rows: ws.append([x.batch_id,x.source_row,x.voucher_no,x.transaction_date,x.source_account,x.particulars,x.paid_received_by,x.debit_account,x.credit_account,float(x.debit or 0),float(x.credit or 0),x.reconciliation_status,x.mismatch_details])
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
    for c,w in enumerate([10,12,14,13,24,38,20,30,30,16,16,20,45],1): ws.column_dimensions[chr(64+c)].width=w
    bio=BytesIO(); wb.save(bio); bio.seek(0)
    return StreamingResponse(bio,media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",headers={"Content-Disposition":"attachment; filename=Horizon_Migration_Reconciliation.xlsx"})

@router.get("/migration/export.pdf")
def migration_export_pdf(batch_id:int|None=None, context=Depends(require_roles("Finance")), db: Session=Depends(get_db)):
    from reportlab.lib.pagesizes import landscape,A4
    from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet
    rows=db.scalars(select(MigrationRow).where(MigrationRow.batch_id==batch_id) if batch_id else select(MigrationRow).order_by(MigrationRow.batch_id,MigrationRow.source_row)).all()
    bio=BytesIO(); doc=SimpleDocTemplate(bio,pagesize=landscape(A4),leftMargin=18,rightMargin=18,topMargin=20,bottomMargin=20)
    styles=getSampleStyleSheet(); data=[["Row","Voucher","Date","Account","Particulars","Debit","Credit","Status"]]
    for x in rows: data.append([x.source_row,x.voucher_no,str(x.transaction_date or ""),x.source_account,Paragraph(x.particulars[:80],styles["BodyText"]),f"{float(x.debit):,.0f}",f"{float(x.credit):,.0f}",x.reconciliation_status])
    t=Table(data,repeatRows=1,colWidths=[35,55,55,95,230,65,65,95]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#16283a")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.25,colors.grey),("FONTSIZE",(0,0),(-1,-1),7),("VALIGN",(0,0),(-1,-1),"TOP")]))
    doc.build([Paragraph("Horizon ERP — Migration Reconciliation",styles["Title"]),t]); bio.seek(0)
    return StreamingResponse(bio,media_type="application/pdf",headers={"Content-Disposition":"attachment; filename=Horizon_Migration_Reconciliation.pdf"})


# ---------------- Payment Plan Templates (V21) ----------------
@router.get("/payment-plans")
def list_payment_plans(request: Request, context=Depends(require_roles("Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    page, size, q = page_params(request); filters=[]
    if q:
        p=f"%{q}%"; filters.append(or_(PaymentPlanTemplate.code.ilike(p), PaymentPlanTemplate.name.ilike(p), PaymentPlanTemplate.category.ilike(p)))
    line_count=select(func.count(PaymentPlanTemplateLine.id)).where(PaymentPlanTemplateLine.template_id==PaymentPlanTemplate.id).correlate(PaymentPlanTemplate).scalar_subquery()
    used_count=select(func.count(BookingPaymentPlan.id)).where(BookingPaymentPlan.template_id==PaymentPlanTemplate.id).correlate(PaymentPlanTemplate).scalar_subquery()
    stmt=select(PaymentPlanTemplate,line_count.label("line_count"),used_count.label("used_count")).where(*filters)
    stmt,sort_by,sort_dir=apply_sort(request,stmt,{"code":PaymentPlanTemplate.code,"name":PaymentPlanTemplate.name,"category":PaymentPlanTemplate.category,"size_marla":PaymentPlanTemplate.size_marla,"active":PaymentPlanTemplate.active,"created_at":PaymentPlanTemplate.created_at},"code","asc",secondary=PaymentPlanTemplate.id.asc())
    count_stmt=select(func.count()).select_from(PaymentPlanTemplate).where(*filters)
    rows,total=paginated(db,stmt,count_stmt,page,size); items=[]
    for plan,lines,used in rows:
        x=model_dict(plan,["id","code","name","category","size_marla","description","active","source_filename","version","created_at"]); x.update(line_count=int(lines or 0),used_count=int(used or 0)); items.append(x)
    return {"items":items,"total":total,"page":page,"size":size,"sort_by":sort_by,"sort_dir":sort_dir}

@router.get("/payment-plans/{plan_id}")
def payment_plan_detail(plan_id:int, context=Depends(require_roles("Finance","Sales","CRM")), db:Session=Depends(get_db)):
    plan=db.get(PaymentPlanTemplate,plan_id)
    if not plan: raise HTTPException(404,"Payment plan not found")
    lines=db.scalars(select(PaymentPlanTemplateLine).where(PaymentPlanTemplateLine.template_id==plan.id).order_by(PaymentPlanTemplateLine.due_no)).all()
    return {"plan":model_dict(plan,["id","code","name","category","size_marla","description","active","source_filename","version"]),"lines":[model_dict(x,["id","due_no","due_type","offset_months","amount_type","amount_value","remarks"]) for x in lines]}

@router.patch("/payment-plans/{plan_id}")
def edit_payment_plan_metadata(plan_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Finance","Sales")),db:Session=Depends(get_db)):
    plan=db.get(PaymentPlanTemplate,plan_id)
    if not plan: raise HTTPException(404,"Payment plan not found")
    expected=int(payload.get("version") or plan.version)
    if expected!=plan.version: raise HTTPException(409,"Payment plan changed by another user")
    before=model_dict(plan,["name","category","size_marla","description","active"])
    if "name" in payload: plan.name=str(payload.get("name") or '').strip() or plan.name
    if "category" in payload: plan.category=str(payload.get("category") or 'All').strip()
    if "size_marla" in payload: plan.size_marla=as_float(payload.get("size_marla"))
    if "description" in payload: plan.description=str(payload.get("description") or '')
    if "active" in payload: plan.active=bool(payload.get("active"))
    plan.version+=1; audit(db,context["user"].full_name,"UPDATE","Payment Plans",plan.id,{"before":before,"after":model_dict(plan,["name","category","size_marla","description","active"])},ip_of(request)); db.commit()
    return {"ok":True,"version":plan.version}

@router.get("/payment-plans-template.xlsx")
def download_payment_plan_template(context=Depends(require_roles("Finance","Sales"))):
    path = BASE_DIR / "templates" / "Horizon_Payment_Plan_Upload_Template.xlsx"
    return FileResponse(path, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename="Horizon_Payment_Plan_Upload_Template.xlsx")

@router.post("/payment-plans/upload")
async def upload_payment_plans(request:Request,file:UploadFile=File(...),context=Depends(csrf_roles("Finance","Sales")),db:Session=Depends(get_db)):
    try:
        data=await file.read()
        if len(data)>5*1024*1024: raise ValueError("Payment-plan file exceeds 5 MB")
        result=import_plans(db,data,file.filename or "payment_plans.xlsx",context["user"].full_name,ip_of(request)); db.commit(); return {"ok":True,**result}
    except ValueError as exc:
        db.rollback(); error(exc)

@router.post("/bookings/{booking_id}/apply-payment-plan")
def apply_booking_payment_plan(booking_id:int,payload:dict,request:Request,context=Depends(csrf_roles("Finance","Sales")),db:Session=Depends(get_db)):
    try:
        booking=db.get(Booking,booking_id)
        if not booking or booking.status not in {"Posted","Active","Booked"}: raise ValueError("Active booking not found")
        assignment=apply_template_to_booking(db,booking,int(payload.get("plan_template_id") or 0),context["user"].full_name,ip_of(request),True)
        booking.version+=1; db.commit(); return {"ok":True,"booking_id":booking.id,"plan":assignment.plan_name_snapshot,"version":booking.version}
    except ValueError as exc:
        db.rollback(); error(exc)

# ---------------- Customer Biometric / Passkey Verification (V22) ----------------
def _biometric_transfer_mode(db: Session) -> str:
    row = db.get(Setting, "biometric_transfer_mode")
    mode = (row.value if row else "Both Parties").strip()
    return mode if mode in {"Both Parties", "Outgoing Only", "Disabled"} else "Both Parties"


def _biometric_public_settings(db: Session, request: Request) -> dict:
    available, dependency_error = webauthn_available()
    try:
        rp_id, origin = request_webauthn_context(request, WEBAUTHN_RP_ID, WEBAUTHN_ORIGIN)
        context_error = ""
    except Exception as exc:
        rp_id, origin, context_error = "", "", str(exc)
    return {
        "provider": "WebAuthn / Passkey",
        "transfer_mode": _biometric_transfer_mode(db),
        "rp_id": rp_id,
        "origin": origin,
        "rp_name": WEBAUTHN_RP_NAME,
        "verification_minutes": BIOMETRIC_VERIFICATION_MINUTES,
        "dependency_available": available,
        "ready": bool(available and not context_error),
        "error": dependency_error or context_error,
        "privacy": "Horizon ERP stores only the passkey public credential and verification audit data. Raw fingerprint or face images are never stored or received by the ERP.",
    }


def _get_biometric_challenge(db: Session, challenge_id: int, customer_id: int, challenge_type: str, user_id: int) -> BiometricChallenge:
    ch = db.get(BiometricChallenge, challenge_id)
    if not ch or ch.customer_id != customer_id or ch.challenge_type != challenge_type:
        raise ValueError("Biometric challenge is invalid")
    if ch.created_by_user_id != user_id:
        raise ValueError("Biometric challenge belongs to another ERP user session")
    if ch.used_at is not None:
        raise ValueError("Biometric challenge has already been used")
    if ch.expires_at < biometric_now():
        raise ValueError("Biometric challenge has expired. Start verification again.")
    return ch


def _validate_transfer_biometric_token(db: Session, token: str, customer_id: int, booking_id: int, purpose: str) -> BiometricVerification:
    if not token:
        raise ValueError(f"Biometric verification required for {purpose.replace('_', ' ')}")
    verification = db.scalar(select(BiometricVerification).where(BiometricVerification.verification_token_hash == token_hash(token)))
    if not verification:
        raise ValueError("Biometric verification token is invalid")
    if verification.customer_id != customer_id or verification.booking_id != booking_id or verification.purpose != purpose:
        raise ValueError("Biometric verification does not match this customer/plot transfer")
    if verification.used_at is not None:
        raise ValueError("Biometric verification has already been used")
    if verification.expires_at < biometric_now():
        raise ValueError("Biometric verification expired. Verify the customer again.")
    return verification


@router.get("/biometrics/settings")
def biometric_settings(request: Request, context=Depends(require_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    return _biometric_public_settings(db, request)


@router.post("/biometrics/settings")
def update_biometric_settings(payload: dict, request: Request, context=Depends(csrf_roles("Admin")), db: Session = Depends(get_db)):
    mode = str(payload.get("transfer_mode") or "Both Parties").strip()
    if mode not in {"Both Parties", "Outgoing Only", "Disabled"}:
        raise HTTPException(status_code=400, detail="Invalid biometric transfer mode")
    row = db.get(Setting, "biometric_transfer_mode")
    if row:
        row.value = mode
    else:
        db.add(Setting(key="biometric_transfer_mode", value=mode))
    audit(db, context["user"].full_name, "UPDATE_BIOMETRIC_SETTINGS", "Security", None, {"transfer_mode": mode}, ip_of(request))
    db.commit()
    return _biometric_public_settings(db, request)


@router.get("/biometrics/customers/{customer_id}")
def customer_biometrics(customer_id: int, context=Depends(require_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    customer = db.get(Customer, customer_id)
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    creds = db.scalars(select(BiometricCredential).where(BiometricCredential.customer_id == customer.id).order_by(BiometricCredential.created_at.desc())).all()
    return {
        "customer": {"id": customer.id, "code": customer.code, "name": customer.name, "cnic": customer.cnic},
        "enrolled": any(x.active for x in creds),
        "active_count": sum(1 for x in creds if x.active),
        "credentials": [model_dict(x, ["id", "label", "transports", "rp_id", "active", "enrolled_by", "created_at", "last_used_at"]) for x in creds],
    }


@router.post("/biometrics/customers/{customer_id}/registration/options")
def customer_biometric_registration_options(customer_id: int, payload: dict, request: Request,
        context=Depends(csrf_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    try:
        customer = db.get(Customer, customer_id)
        if not customer or customer.status != "Active":
            raise ValueError("Select an active customer")
        rp_id, origin = request_webauthn_context(request, WEBAUTHN_RP_ID, WEBAUTHN_ORIGIN)
        options, challenge = registration_options(
            rp_id=rp_id, rp_name=WEBAUTHN_RP_NAME, customer_id=customer.id,
            customer_name=customer.name, customer_code=customer.code,
        )
        ch = BiometricChallenge(
            challenge=b64url_encode(challenge), challenge_type="registration", customer_id=customer.id,
            purpose="customer_enrollment", rp_id=rp_id, expected_origin=origin,
            created_by_user_id=context["user"].id, expires_at=biometric_expires(5),
        )
        db.add(ch); db.commit(); db.refresh(ch)
        audit(db, context["user"].full_name, "START_BIOMETRIC_ENROLLMENT", "Customer", customer.id,
              {"customer": customer.name, "rp_id": rp_id}, ip_of(request)); db.commit()
        return {"challenge_id": ch.id, "publicKey": options, "customer": customer.name, "label": str(payload.get("label") or "Customer device")}
    except ValueError as exc:
        db.rollback(); error(exc)
    except RuntimeError as exc:
        db.rollback(); error(exc, 503)


@router.post("/biometrics/customers/{customer_id}/registration/verify")
def customer_biometric_registration_verify(customer_id: int, payload: dict, request: Request,
        context=Depends(csrf_roles("Admin", "Finance", "Sales", "CRM")), db: Session = Depends(get_db)):
    try:
        customer = db.get(Customer, customer_id)
        if not customer:
            raise ValueError("Customer not found")
        ch = _get_biometric_challenge(db, int(payload.get("challenge_id") or 0), customer.id, "registration", context["user"].id)
        credential = payload.get("credential")
        if not isinstance(credential, dict):
            raise ValueError("Biometric credential response is missing")
        verified = verify_registration(
            credential=credential, expected_challenge=b64url_decode(ch.challenge),
            expected_rp_id=ch.rp_id, expected_origin=ch.expected_origin,
        )
        existing = db.scalar(select(BiometricCredential).where(BiometricCredential.credential_id == verified["credential_id"]))
        if existing and existing.customer_id != customer.id:
            raise ValueError("This passkey is already registered to another customer")
        transports = credential.get("response", {}).get("transports") or []
        if existing:
            existing.public_key = verified["credential_public_key"]
            existing.sign_count = verified["sign_count"]
            existing.active = True
            existing.label = str(payload.get("label") or existing.label or "Customer device")[:160]
            existing.transports = json.dumps(transports)
            existing.rp_id = ch.rp_id
            cred = existing
        else:
            cred = BiometricCredential(
                customer_id=customer.id, credential_id=verified["credential_id"], public_key=verified["credential_public_key"],
                sign_count=verified["sign_count"], label=str(payload.get("label") or "Customer device")[:160],
                transports=json.dumps(transports), rp_id=ch.rp_id, active=True, enrolled_by=context["user"].full_name,
            )
            db.add(cred); db.flush()
        ch.used_at = biometric_now()
        audit(db, context["user"].full_name, "ENROLL_CUSTOMER_BIOMETRIC", "Customer", customer.id,
              {"customer": customer.name, "credential_id": cred.id, "label": cred.label, "provider": "WebAuthn"}, ip_of(request))
        db.commit()
        return {"ok": True, "credential_id": cred.id, "customer": customer.name, "label": cred.label}
    except ValueError as exc:
        db.rollback(); error(exc)
    except Exception as exc:
        db.rollback(); error(exc, 400)


@router.patch("/biometrics/credentials/{credential_db_id}")
def update_biometric_credential(credential_db_id: int, payload: dict, request: Request,
        context=Depends(csrf_roles("Admin", "Finance")), db: Session = Depends(get_db)):
    cred = db.get(BiometricCredential, credential_db_id)
    if not cred:
        raise HTTPException(status_code=404, detail="Biometric credential not found")
    if "active" in payload:
        cred.active = bool(payload.get("active"))
    if payload.get("label") is not None:
        cred.label = str(payload.get("label") or "Customer device")[:160]
    cred.version += 1
    audit(db, context["user"].full_name, "UPDATE_BIOMETRIC_CREDENTIAL", "Customer", cred.customer_id,
          {"credential_id": cred.id, "active": cred.active, "label": cred.label}, ip_of(request))
    db.commit()
    return {"ok": True}


@router.post("/biometrics/authentication/options")
def biometric_authentication_options(payload: dict, request: Request,
        context=Depends(csrf_roles("Admin", "Finance", "Sales")), db: Session = Depends(get_db)):
    try:
        customer_id = int(payload.get("customer_id") or 0)
        booking_id = int(payload.get("booking_id") or 0) if payload.get("booking_id") else None
        purpose = str(payload.get("purpose") or "customer_identity").strip()
        customer = db.get(Customer, customer_id)
        if not customer or customer.status != "Active":
            raise ValueError("Active customer not found")
        if booking_id and not db.get(Booking, booking_id):
            raise ValueError("Booking not found")
        creds = db.scalars(select(BiometricCredential).where(
            BiometricCredential.customer_id == customer.id, BiometricCredential.active.is_(True)
        )).all()
        if not creds:
            raise ValueError(f"{customer.name} has no active biometric/passkey enrollment")
        rp_id, origin = request_webauthn_context(request, WEBAUTHN_RP_ID, WEBAUTHN_ORIGIN)
        matching = [x for x in creds if not x.rp_id or x.rp_id == rp_id]
        if not matching:
            raise ValueError(f"{customer.name}'s biometric credential was enrolled for a different ERP domain. Re-enroll on this domain.")
        options, challenge = authentication_options(rp_id=rp_id, credential_ids=[x.credential_id for x in matching])
        ch = BiometricChallenge(
            challenge=b64url_encode(challenge), challenge_type="authentication", customer_id=customer.id,
            booking_id=booking_id, purpose=purpose, rp_id=rp_id, expected_origin=origin,
            created_by_user_id=context["user"].id, expires_at=biometric_expires(5),
        )
        db.add(ch); db.commit(); db.refresh(ch)
        return {"challenge_id": ch.id, "publicKey": options, "customer": customer.name, "purpose": purpose}
    except ValueError as exc:
        db.rollback(); error(exc)
    except RuntimeError as exc:
        db.rollback(); error(exc, 503)


@router.post("/biometrics/authentication/verify")
def biometric_authentication_verify(payload: dict, request: Request,
        context=Depends(csrf_roles("Admin", "Finance", "Sales")), db: Session = Depends(get_db)):
    try:
        customer_id = int(payload.get("customer_id") or 0)
        ch = _get_biometric_challenge(db, int(payload.get("challenge_id") or 0), customer_id, "authentication", context["user"].id)
        credential = payload.get("credential")
        if not isinstance(credential, dict):
            raise ValueError("Biometric credential response is missing")
        credential_id = str(credential.get("id") or "")
        cred = db.scalar(select(BiometricCredential).where(
            BiometricCredential.customer_id == customer_id,
            BiometricCredential.credential_id == credential_id,
            BiometricCredential.active.is_(True),
        ))
        if not cred:
            raise ValueError("The selected biometric credential is not registered to this customer")
        verified = verify_authentication(
            credential=credential, expected_challenge=b64url_decode(ch.challenge), expected_rp_id=ch.rp_id,
            expected_origin=ch.expected_origin, credential_public_key=cred.public_key, current_sign_count=cred.sign_count,
        )
        cred.sign_count = verified["new_sign_count"]
        cred.last_used_at = biometric_now()
        ch.used_at = biometric_now()
        token = new_verification_token()
        v = BiometricVerification(
            customer_id=customer_id, booking_id=ch.booking_id, credential_id=cred.id, purpose=ch.purpose,
            verification_token_hash=token_hash(token), verified_by=context["user"].full_name,
            verified_at=biometric_now(), expires_at=biometric_expires(BIOMETRIC_VERIFICATION_MINUTES), ip_address=ip_of(request),
        )
        db.add(v); db.flush()
        customer = db.get(Customer, customer_id)
        audit(db, context["user"].full_name, "VERIFY_CUSTOMER_BIOMETRIC", "Customer", customer_id,
              {"customer": customer.name if customer else customer_id, "booking_id": ch.booking_id, "purpose": ch.purpose,
               "credential_id": cred.id, "valid_minutes": BIOMETRIC_VERIFICATION_MINUTES}, ip_of(request))
        db.commit()
        return {"ok": True, "verification_token": token, "customer": customer.name if customer else "Customer",
                "purpose": ch.purpose, "expires_in_minutes": BIOMETRIC_VERIFICATION_MINUTES}
    except ValueError as exc:
        db.rollback(); error(exc)
    except Exception as exc:
        db.rollback(); error(exc, 400)


# ---------------- Plot Transfers (V22) ----------------
def _transfer_dues(db:Session,booking:Booking,plot:Plot)->float:
    schedule_due=float(db.scalar(select(func.coalesce(func.sum(Installment.amount-Installment.paid),0)).where(Installment.booking_id==booking.id)) or 0)
    financial_due=max(0.0,round(float(booking.net_sale_value or 0)-float(plot.received or 0),2))
    return round(max(float(plot.outstanding or 0),schedule_due,financial_due),2)

@router.get("/transfers")
def list_transfers(request:Request,context=Depends(require_roles("Finance","Sales","CRM")),db:Session=Depends(get_db)):
    page,size,q=page_params(request); FC=Customer.__table__.alias("fc"); TC=Customer.__table__.alias("tc")
    filters=[]
    if q:
        p=f"%{q}%"; filters.append(or_(PlotTransfer.transfer_no.ilike(p),Plot.plot_no.ilike(p),FC.c.name.ilike(p),TC.c.name.ilike(p)))
    stmt=select(PlotTransfer,Plot.plot_no,Booking.booking_no,FC.c.name.label("from_name"),TC.c.name.label("to_name")).join(Plot,Plot.id==PlotTransfer.plot_id).join(Booking,Booking.id==PlotTransfer.booking_id).join(FC,FC.c.id==PlotTransfer.from_customer_id).join(TC,TC.c.id==PlotTransfer.to_customer_id).where(*filters)
    stmt,sort_by,sort_dir=apply_sort(request,stmt,{"transfer_no":PlotTransfer.transfer_no,"transfer_date":PlotTransfer.transfer_date,"plot_no":Plot.plot_no,"booking_no":Booking.booking_no,"from_customer":FC.c.name,"to_customer":TC.c.name,"dues_at_transfer":PlotTransfer.dues_at_transfer,"status":PlotTransfer.status},"transfer_date","desc",secondary=PlotTransfer.id.desc())
    count_stmt=select(func.count()).select_from(PlotTransfer).join(Plot).join(Booking).join(FC,FC.c.id==PlotTransfer.from_customer_id).join(TC,TC.c.id==PlotTransfer.to_customer_id).where(*filters)
    rows,total=paginated(db,stmt,count_stmt,page,size); items=[]
    for tr,plot_no,booking_no,from_name,to_name in rows:
        biometric_count=int(db.scalar(select(func.count()).select_from(BiometricVerification).where(BiometricVerification.transfer_id==tr.id)) or 0)
        x=model_dict(tr,["id","transfer_no","transfer_date","plot_id","booking_id","from_customer_id","to_customer_id","dues_at_transfer","status","reason","approved_by","created_at"]); x.update(plot_no=plot_no,booking_no=booking_no,from_customer=from_name,to_customer=to_name,biometric_count=biometric_count); items.append(x)
    return {"items":items,"total":total,"page":page,"size":size,"sort_by":sort_by,"sort_dir":sort_dir}

@router.get("/transfers/eligibility")
def transfer_eligibility(context=Depends(require_roles("Finance","Sales","CRM")),db:Session=Depends(get_db)):
    rows=db.execute(select(Booking,Plot,Customer).join(Plot,Plot.id==Booking.plot_id).join(Customer,Customer.id==Booking.customer_id).where(Booking.status.in_(["Posted","Active","Booked"])).order_by(Plot.plot_no)).all(); items=[]
    for booking,plot,customer in rows:
        dues=_transfer_dues(db,booking,plot)
        biometric_count=int(db.scalar(select(func.count()).select_from(BiometricCredential).where(BiometricCredential.customer_id==customer.id,BiometricCredential.active.is_(True))) or 0)
        items.append({"booking_id":booking.id,"booking_no":booking.booking_no,"plot_id":plot.id,"plot_no":plot.plot_no,"customer_id":customer.id,"customer_name":customer.name,"net_sale_value":float(booking.net_sale_value or 0),"received":float(plot.received or 0),"outstanding":dues,"eligible":dues<=0.01,"status":plot.status,"biometric_enrolled":biometric_count>0,"biometric_count":biometric_count})
    return {"items":items,"biometric_transfer_mode":_biometric_transfer_mode(db)}

@router.post("/transfers")
def create_plot_transfer(payload:dict,request:Request,context=Depends(csrf_roles("Finance","Sales")),db:Session=Depends(get_db)):
    try:
        booking=db.get(Booking,int(payload.get("booking_id") or 0)); new_customer=db.get(Customer,int(payload.get("to_customer_id") or 0))
        if not booking or booking.status not in {"Posted","Active","Booked"}: raise ValueError("Active booking not found")
        if not new_customer or new_customer.status!="Active": raise ValueError("Select an active receiving customer")
        plot=db.get(Plot,booking.plot_id); old_customer=db.get(Customer,booking.customer_id)
        if not plot or not old_customer: raise ValueError("Plot/customer record is incomplete")
        if new_customer.id==old_customer.id: raise ValueError("Receiving customer must be different from the current owner")
        dues=_transfer_dues(db,booking,plot)
        if dues>0.01: raise ValueError(f"TRANSFER BLOCKED: Plot {plot.plot_no} has outstanding dues of Rs {dues:,.2f}. Clear all remaining dues before transfer.")
        biometric_mode=_biometric_transfer_mode(db)
        biometric_records=[]
        if biometric_mode != "Disabled":
            biometric_records.append(_validate_transfer_biometric_token(db,str(payload.get("from_biometric_token") or ""),old_customer.id,booking.id,"plot_transfer_outgoing"))
            if biometric_mode == "Both Parties":
                biometric_records.append(_validate_transfer_biometric_token(db,str(payload.get("to_biometric_token") or ""),new_customer.id,booking.id,"plot_transfer_incoming"))
        tr=PlotTransfer(transfer_no=next_number(db,PlotTransfer,PlotTransfer.transfer_no,"TRF"),transfer_date=to_date(payload.get("transfer_date") or date.today(),"transfer_date"),plot_id=plot.id,booking_id=booking.id,from_customer_id=old_customer.id,to_customer_id=new_customer.id,dues_at_transfer=dues,status="Completed",reason=str(payload.get("reason") or "Customer-requested transfer"),approved_by=context["user"].full_name)
        db.add(tr); db.flush()
        for verification in biometric_records:
            verification.used_at=biometric_now(); verification.transfer_id=tr.id
        booking.customer_id=new_customer.id; booking.version+=1; plot.customer_id=new_customer.id; plot.version+=1
        audit(db,context["user"].full_name,"TRANSFER_PLOT","Plot Transfer",tr.id,{"transfer_no":tr.transfer_no,"plot":plot.plot_no,"booking":booking.booking_no,"from":old_customer.name,"to":new_customer.name,"outstanding_verified":dues,"biometric_mode":biometric_mode,"biometric_verifications":[x.id for x in biometric_records],"rule":"Transfer permitted only when dues <= Rs 0.01. Biometric/passkey verification is enforced according to the configured transfer mode. Historical receipts remain unchanged."},ip_of(request))
        db.add(Notification(role="Admin",title="Plot transferred",message=f"Plot {plot.plot_no} transferred from {old_customer.name} to {new_customer.name}. All dues verified clear.",link="#transfers")); db.commit()
        return {"ok":True,"id":tr.id,"transfer_no":tr.transfer_no,"plot_no":plot.plot_no,"from_customer":old_customer.name,"to_customer":new_customer.name}
    except ValueError as exc:
        db.rollback(); error(exc)
