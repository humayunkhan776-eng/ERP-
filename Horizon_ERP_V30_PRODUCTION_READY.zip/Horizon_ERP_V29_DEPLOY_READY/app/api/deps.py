from __future__ import annotations

import hashlib
from datetime import datetime, timezone

from fastapi import Cookie, Depends, Header, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import SessionLocal
from ..models import AuthSession, User


def _as_utc(value: datetime) -> datetime:
    """Accept older SQLite timestamps as UTC and normalize PostgreSQL values."""
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_context(
    request: Request,
    db: Session = Depends(get_db),
    horizon_session: str | None = Cookie(default=None),
):
    if not horizon_session:
        raise HTTPException(status_code=401, detail="Authentication required")
    token_hash = hashlib.sha256(horizon_session.encode()).hexdigest()
    auth = db.scalar(select(AuthSession).where(AuthSession.token_hash == token_hash))
    if not auth or _as_utc(auth.expires_at) < datetime.now(timezone.utc):
        if auth:
            db.delete(auth)
            db.commit()
        raise HTTPException(status_code=401, detail="Session expired")
    user = db.get(User, auth.user_id)
    if not user or not user.active:
        raise HTTPException(status_code=401, detail="User is inactive")
    auth.last_seen_at = datetime.now(timezone.utc)
    db.commit()
    return {"user": user, "session": auth, "request": request}


def current_user(context=Depends(get_current_context)) -> User:
    return context["user"]


def require_roles(*roles):
    def dependency(context=Depends(get_current_context)):
        user = context["user"]
        if user.role not in roles and user.role != "Admin":
            raise HTTPException(status_code=403, detail="You do not have permission for this action")
        return context
    return dependency


def csrf_protect(
    context=Depends(get_current_context),
    x_csrf_token: str | None = Header(default=None),
):
    if not x_csrf_token or x_csrf_token != context["session"].csrf_token:
        raise HTTPException(status_code=403, detail="Invalid CSRF token")
    return context


def csrf_roles(*roles):
    def dependency(
        context=Depends(get_current_context),
        x_csrf_token: str | None = Header(default=None),
    ):
        if not x_csrf_token or x_csrf_token != context["session"].csrf_token:
            raise HTTPException(status_code=403, detail="Invalid CSRF token")
        user = context["user"]
        if user.role not in roles and user.role != "Admin":
            raise HTTPException(status_code=403, detail="You do not have permission for this action")
        return context
    return dependency
