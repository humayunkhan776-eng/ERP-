from __future__ import annotations

import base64
import hashlib
import json
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def b64url_decode(text: str) -> bytes:
    text = str(text or "")
    return base64.urlsafe_b64decode(text + "=" * ((4 - len(text) % 4) % 4))


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def new_verification_token() -> str:
    return secrets.token_urlsafe(40)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def expires(minutes: int = 10) -> datetime:
    return utcnow() + timedelta(minutes=max(1, min(int(minutes), 60)))


def webauthn_available() -> tuple[bool, str]:
    try:
        import webauthn  # noqa: F401
        return True, ""
    except Exception as exc:
        return False, f"WebAuthn dependency is not installed: {exc}. Re-run pip install -r requirements.txt."


def _imports():
    try:
        from webauthn import (
            generate_authentication_options,
            generate_registration_options,
            options_to_json,
            verify_authentication_response,
            verify_registration_response,
        )
        from webauthn.helpers.structs import (
            AuthenticatorSelectionCriteria,
            PublicKeyCredentialDescriptor,
            ResidentKeyRequirement,
            UserVerificationRequirement,
        )
    except Exception as exc:
        raise RuntimeError(
            "Biometric/passkey support requires the Python 'webauthn' package. "
            "Run pip install -r requirements.txt and restart Horizon ERP."
        ) from exc
    return {
        "generate_authentication_options": generate_authentication_options,
        "generate_registration_options": generate_registration_options,
        "options_to_json": options_to_json,
        "verify_authentication_response": verify_authentication_response,
        "verify_registration_response": verify_registration_response,
        "AuthenticatorSelectionCriteria": AuthenticatorSelectionCriteria,
        "PublicKeyCredentialDescriptor": PublicKeyCredentialDescriptor,
        "ResidentKeyRequirement": ResidentKeyRequirement,
        "UserVerificationRequirement": UserVerificationRequirement,
    }


def request_webauthn_context(request, configured_rp_id: str = "", configured_origin: str = "") -> tuple[str, str]:
    """Resolve RP ID and exact origin. Production deployments should set env vars."""
    forwarded_host = (request.headers.get("x-forwarded-host") or "").split(",")[0].strip()
    host_header = forwarded_host or request.headers.get("host") or request.url.netloc
    host_only = host_header.split(":", 1)[0].strip().lower()
    forwarded_proto = (request.headers.get("x-forwarded-proto") or "").split(",")[0].strip()
    scheme = forwarded_proto or request.url.scheme
    rp_id = (configured_rp_id or host_only).strip().lower()
    origin = (configured_origin or f"{scheme}://{host_header}").rstrip("/")
    if not rp_id:
        raise ValueError("Unable to determine WebAuthn relying-party ID")
    if not origin.startswith(("https://", "http://localhost", "http://127.0.0.1")):
        raise ValueError("Biometric/passkey verification requires HTTPS (localhost is allowed for testing)")
    return rp_id, origin


def registration_options(*, rp_id: str, rp_name: str, customer_id: int, customer_name: str, customer_code: str) -> tuple[dict[str, Any], bytes]:
    w = _imports()
    selection = w["AuthenticatorSelectionCriteria"](
        resident_key=w["ResidentKeyRequirement"].PREFERRED,
        user_verification=w["UserVerificationRequirement"].REQUIRED,
    )
    options = w["generate_registration_options"](
        rp_id=rp_id,
        rp_name=rp_name,
        user_id=f"horizon-customer:{customer_id}".encode("utf-8"),
        user_name=(customer_code or f"customer-{customer_id}"),
        user_display_name=customer_name,
        authenticator_selection=selection,
    )
    return json.loads(w["options_to_json"](options)), bytes(options.challenge)


def verify_registration(*, credential: dict[str, Any], expected_challenge: bytes, expected_rp_id: str, expected_origin: str) -> dict[str, Any]:
    w = _imports()
    result = w["verify_registration_response"](
        credential=credential,
        expected_challenge=expected_challenge,
        expected_rp_id=expected_rp_id,
        expected_origin=expected_origin,
        require_user_verification=True,
    )
    return {
        "credential_id": b64url_encode(bytes(result.credential_id)),
        "credential_public_key": b64url_encode(bytes(result.credential_public_key)),
        "sign_count": int(result.sign_count or 0),
    }


def authentication_options(*, rp_id: str, credential_ids: list[str]) -> tuple[dict[str, Any], bytes]:
    w = _imports()
    descriptors = [w["PublicKeyCredentialDescriptor"](id=b64url_decode(x)) for x in credential_ids]
    options = w["generate_authentication_options"](
        rp_id=rp_id,
        allow_credentials=descriptors,
        user_verification=w["UserVerificationRequirement"].REQUIRED,
    )
    return json.loads(w["options_to_json"](options)), bytes(options.challenge)


def verify_authentication(*, credential: dict[str, Any], expected_challenge: bytes, expected_rp_id: str,
                          expected_origin: str, credential_public_key: str, current_sign_count: int) -> dict[str, Any]:
    w = _imports()
    result = w["verify_authentication_response"](
        credential=credential,
        expected_challenge=expected_challenge,
        expected_rp_id=expected_rp_id,
        expected_origin=expected_origin,
        credential_public_key=b64url_decode(credential_public_key),
        credential_current_sign_count=int(current_sign_count or 0),
        require_user_verification=True,
    )
    return {"new_sign_count": int(result.new_sign_count or 0)}
