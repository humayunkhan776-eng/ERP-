"""Controlled, one-time financial ledger import.

This module is intentionally invoked only through a maintenance request protected
by a high-entropy environment token.  It is never called from FastAPI startup,
so opening a Render port is not delayed by a large financial import.
"""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from sqlalchemy import text

from ..core.config import BASE_DIR
from ..db import SessionLocal


logger = logging.getLogger(__name__)

IMPORT_RUN_KEY = "HORIZON_MASTER_LEDGER_2026_09_30"
WORKBOOK_NAME = "Horizon Ledger 6 Sep till.xlsx"
JOB_TABLE = "financial_import_jobs"


def _ensure_job_table(db) -> None:
    db.execute(text(
        f"CREATE TABLE IF NOT EXISTS {JOB_TABLE} ("
        "run_key VARCHAR(100) PRIMARY KEY, status VARCHAR(20) NOT NULL, "
        "started_at TIMESTAMP, completed_at TIMESTAMP, error_message TEXT, "
        "voucher_count INTEGER)"
    ))


def request_import() -> dict[str, str]:
    """Atomically claim the import job without touching accounting rows."""
    with SessionLocal() as db:
        _ensure_job_table(db)
        row = db.execute(text(
            f"SELECT status FROM {JOB_TABLE} WHERE run_key=:key"
        ), {"key": IMPORT_RUN_KEY}).mappings().first()
        if row and row["status"] == "Completed":
            db.commit()
            return {"status": "already_completed"}
        if row and row["status"] == "Running":
            db.commit()
            return {"status": "already_running"}
        if row:
            db.execute(text(
                f"UPDATE {JOB_TABLE} SET status='Running', started_at=CURRENT_TIMESTAMP, "
                "completed_at=NULL, error_message=NULL, voucher_count=NULL WHERE run_key=:key"
            ), {"key": IMPORT_RUN_KEY})
        else:
            db.execute(text(
                f"INSERT INTO {JOB_TABLE} (run_key, status, started_at) "
                "VALUES (:key, 'Running', CURRENT_TIMESTAMP)"
            ), {"key": IMPORT_RUN_KEY})
        db.commit()
    return {"status": "queued"}


def run_import() -> None:
    """Run the approved import in a worker thread and record a durable result."""
    workbook = BASE_DIR / WORKBOOK_NAME
    try:
        # The import script validates all 552 source rows before changing the
        # ledger, creates financial backup tables, and commits as one unit.
        from scripts.reset_financial_from_horizon import main as reset_ledger
        reset_ledger(str(workbook))

        with SessionLocal() as db:
            _ensure_job_table(db)
            run = db.execute(text(
                "SELECT voucher_count FROM financial_reset_runs WHERE run_key=:key"
            ), {"key": IMPORT_RUN_KEY}).mappings().first()
            if not run:
                raise RuntimeError("The ledger import ended without its completion marker.")
            db.execute(text(
                f"UPDATE {JOB_TABLE} SET status='Completed', completed_at=CURRENT_TIMESTAMP, "
                "error_message=NULL, voucher_count=:count WHERE run_key=:key"
            ), {"key": IMPORT_RUN_KEY, "count": int(run["voucher_count"])})
            db.commit()
        logger.warning("Approved financial ledger import completed: %s vouchers", run["voucher_count"])
    except Exception as exc:
        logger.exception("Approved financial ledger import failed")
        try:
            with SessionLocal() as db:
                _ensure_job_table(db)
                db.execute(text(
                    f"UPDATE {JOB_TABLE} SET status='Failed', completed_at=CURRENT_TIMESTAMP, "
                    "error_message=:message WHERE run_key=:key"
                ), {"key": IMPORT_RUN_KEY, "message": str(exc)[:1500]})
                db.commit()
        except Exception:
            logger.exception("Could not record the financial import failure")


def import_status() -> dict[str, str | int | None]:
    with SessionLocal() as db:
        _ensure_job_table(db)
        row = db.execute(text(
            f"SELECT status, started_at, completed_at, error_message, voucher_count "
            f"FROM {JOB_TABLE} WHERE run_key=:key"
        ), {"key": IMPORT_RUN_KEY}).mappings().first()
        db.commit()
    if not row:
        return {"status": "not_requested", "voucher_count": None}
    return {
        "status": row["status"],
        "started_at": row["started_at"].isoformat() if row["started_at"] else None,
        "completed_at": row["completed_at"].isoformat() if row["completed_at"] else None,
        "error": row["error_message"],
        "voucher_count": row["voucher_count"],
    }
