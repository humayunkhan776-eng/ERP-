"""One-time, explicitly enabled recovery for the legacy V6 financial reset.

This module is deliberately inert unless an operator sets the exact recovery
token in the service environment. It is not part of normal ERP startup.
"""
from __future__ import annotations

import logging
import os

from sqlalchemy import inspect, text

from ..db import SessionLocal
from ..models import MigrationBatch, MigrationRow, Voucher, VoucherLine


logger = logging.getLogger(__name__)

# A literal token prevents an accidental environment setting from running a
# ledger restore. Clear or change the setting immediately after recovery.
RECOVERY_TOKEN = "RESTORE_V6_FINANCIAL_RESET_BACKUP_20261005"
RECOVERY_ENV = "HORIZON_LEDGER_RECOVERY"


def _table_exists(db, table_name: str) -> bool:
    return inspect(db.bind).has_table(table_name)


def _count(db, table_name: str) -> int:
    return int(db.execute(text(f"SELECT count(*) FROM {table_name}")).scalar_one())


def _copy_table(db, source: str, destination: str) -> None:
    # The table names are internal constants, never request data. This keeps
    # the V6 reset ledger as a second, recoverable snapshot before restoring.
    db.execute(text(f"CREATE TABLE IF NOT EXISTS {destination} AS TABLE {source} WITH NO DATA"))
    db.execute(text(f"DELETE FROM {destination}"))
    db.execute(text(f"INSERT INTO {destination} SELECT * FROM {source}"))


def _restore_model_table(db, model, backup_table: str, null_columns: set[str] | None = None) -> None:
    null_columns = null_columns or set()
    target = model.__tablename__
    columns = [column.name for column in model.__table__.columns]
    column_sql = ", ".join(columns)
    source_sql = ", ".join("NULL" if column in null_columns else column for column in columns)
    db.execute(text(f"INSERT INTO {target} ({column_sql}) SELECT {source_sql} FROM {backup_table}"))


def _sync_sequence(db, table_name: str) -> None:
    # Restored primary keys must not collide with the next user-created entry.
    db.execute(text(
        "SELECT setval(pg_get_serial_sequence(:table_name, 'id'), "
        "GREATEST(COALESCE((SELECT MAX(id) FROM " + table_name + "), 1), 1), "
        "(SELECT count(*) > 0 FROM " + table_name + "))"
    ), {"table_name": table_name})


def restore_legacy_financial_reset_backup_if_requested() -> dict[str, int | str] | None:
    """Restore the pre-V6 ledger atomically only when the recovery token is set.

    V6 created ``financial_reset_backup_*`` tables before replacing active
    vouchers. The complete restore, including a backup of the V6 result and
    re-linking operational records, is one PostgreSQL transaction. An error
    rolls back everything, leaving the database untouched.
    """
    if os.getenv(RECOVERY_ENV) != RECOVERY_TOKEN:
        return None

    source_tables = {
        "vouchers": "financial_reset_backup_vouchers",
        "voucher_lines": "financial_reset_backup_voucher_lines",
        "migration_batches": "financial_reset_backup_migration_batches",
        "migration_rows": "financial_reset_backup_migration_rows",
    }
    capture_tables = {
        "vouchers": "financial_recovery_v6_reset_vouchers",
        "voucher_lines": "financial_recovery_v6_reset_voucher_lines",
        "migration_batches": "financial_recovery_v6_reset_migration_batches",
        "migration_rows": "financial_recovery_v6_reset_migration_rows",
    }

    with SessionLocal() as db:
        try:
            with db.begin():
                missing = [name for name in source_tables.values() if not _table_exists(db, name)]
                if missing:
                    raise RuntimeError(f"Cannot restore ledger: missing V6 backup table(s): {', '.join(missing)}")

                db.execute(text(
                    "CREATE TABLE IF NOT EXISTS financial_reset_recovery_runs ("
                    "recovery_key VARCHAR(100) PRIMARY KEY, recovered_at TIMESTAMP, "
                    "backup_voucher_count INTEGER NOT NULL, restored_voucher_count INTEGER NOT NULL)"
                ))
                recovery_key = "RESTORE_V6_FINANCIAL_RESET_BACKUP_20261005"
                if db.execute(text("SELECT 1 FROM financial_reset_recovery_runs WHERE recovery_key=:key"), {"key": recovery_key}).first():
                    logger.warning("Financial reset recovery was already completed; skipping duplicate request.")
                    return {"status": "already_completed"}

                source_counts = {key: _count(db, table) for key, table in source_tables.items()}
                if source_counts["vouchers"] < 1 or source_counts["voucher_lines"] < 1:
                    raise RuntimeError("Cannot restore ledger: V6 backup is empty.")

                # Preserve the current reset result before replacing it.
                for key, capture in capture_tables.items():
                    _copy_table(db, key, capture)

                # Remove foreign-key references in active operational tables.
                db.execute(text("UPDATE bookings SET posted_voucher_id=NULL"))
                db.execute(text("UPDATE receipts SET posted_voucher_id=NULL"))
                db.execute(text("UPDATE payroll SET paid_voucher_id=NULL"))
                db.execute(text("UPDATE commissions SET posted_voucher_id=NULL"))
                db.execute(text("UPDATE migration_rows SET erp_voucher_id=NULL"))
                db.execute(text("UPDATE vouchers SET reversed_voucher_id=NULL"))
                db.execute(text("DELETE FROM voucher_lines"))
                db.execute(text("DELETE FROM migration_rows"))
                db.execute(text("DELETE FROM vouchers"))
                db.execute(text("DELETE FROM migration_batches"))

                # Restore the exact prior ledger. Self-reversal links are set
                # after the vouchers exist, so normal FK enforcement remains on.
                _restore_model_table(db, Voucher, source_tables["vouchers"], {"reversed_voucher_id"})
                db.execute(text(
                    "UPDATE vouchers AS current SET reversed_voucher_id=backup.reversed_voucher_id "
                    "FROM financial_reset_backup_vouchers AS backup WHERE current.id=backup.id"
                ))
                _restore_model_table(db, VoucherLine, source_tables["voucher_lines"])
                _restore_model_table(db, MigrationBatch, source_tables["migration_batches"])
                _restore_model_table(db, MigrationRow, source_tables["migration_rows"])

                # Restore operational links that V6 intentionally cleared.
                db.execute(text(
                    "UPDATE bookings AS booking SET posted_voucher_id=voucher.id FROM vouchers AS voucher "
                    "WHERE voucher.source_module='Booking' AND voucher.source_reference=booking.booking_no"
                ))
                db.execute(text(
                    "UPDATE receipts AS receipt SET posted_voucher_id=voucher.id FROM vouchers AS voucher "
                    "WHERE voucher.source_module='Receipt' AND voucher.source_reference=receipt.receipt_no"
                ))
                db.execute(text(
                    "UPDATE commissions AS commission SET posted_voucher_id=voucher.id FROM vouchers AS voucher "
                    "WHERE voucher.source_module='Commission' AND voucher.source_reference=commission.commission_no"
                ))
                db.execute(text(
                    "UPDATE payroll AS item SET paid_voucher_id=voucher.id FROM vouchers AS voucher "
                    "WHERE voucher.source_module='Payroll' AND voucher.source_reference=('PAY-' || item.id::text)"
                ))

                for table_name in ("vouchers", "voucher_lines", "migration_batches", "migration_rows"):
                    _sync_sequence(db, table_name)

                restored_counts = {key: _count(db, key) for key in source_tables}
                if restored_counts != source_counts:
                    raise RuntimeError(f"Ledger restore verification failed: expected {source_counts}, got {restored_counts}")

                db.execute(text(
                    "INSERT INTO financial_reset_recovery_runs "
                    "(recovery_key, recovered_at, backup_voucher_count, restored_voucher_count) "
                    "VALUES (:key, CURRENT_TIMESTAMP, :backup_count, :restored_count)"
                ), {
                    "key": recovery_key,
                    "backup_count": source_counts["vouchers"],
                    "restored_count": restored_counts["vouchers"],
                })
                logger.warning("Financial ledger restored from V6 backup: %s", restored_counts)
                return {"status": "completed", **restored_counts}
        except Exception:
            logger.exception("Financial reset recovery failed; the transaction was rolled back.")
            raise
