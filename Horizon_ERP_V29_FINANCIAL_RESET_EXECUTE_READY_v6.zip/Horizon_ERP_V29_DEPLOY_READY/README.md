# Horizon ERP Enterprise V24

V24 retains all V23 receivables and biometric controls and adds audit-safe booking-date correction with automatic payment-schedule regeneration and receipt reallocation.

A role-based, responsive ERP and installable Progressive Web App for **Crescent Horizon Developers (Pvt.) Limited** and **Horizon Homes**.

## V20 universal sorting and WhatsApp notifications

- Sort all major ERP data tables by clicking column headings; paginated modules use server-side sorting across the full dataset.
- Plain report/portal/mapping tables also support local ascending/descending sorting.
- New **Sales & Collections → WhatsApp Notifications** centre for Meta WhatsApp Business Cloud API configuration, booking confirmations, due reminders, bulk reminder control and delivery logs.
- Booking and Installment screens include direct WhatsApp actions.
- Manual `wa.me` fallback is available when API delivery is not configured.
- Actual Cloud API delivery requires a Meta Phone Number ID, access token, approved message templates and verified customer mobile numbers.


## V13 account cleanup and mapping

Finance now includes **Account Cleanup & Mapping**. Known duplicate director-current ledger names are consolidated into the standard master accounts without changing voucher amounts. The original alias names, mapping reason, moved voucher-line IDs, user and mapping time are retained for audit and optional restoration.

Standard director structure:

- Cash Held by Humayun — separate company asset
- Director Current Account - Humayun — standardized current account
- Cash Held by Salman — separate company asset
- Director Current Account - Salman — standardized current account
- Director Receivable and Loan Payable accounts remain separate because they represent different accounting relationships.

## What this release delivers

This is a working web application, not an Excel file. It uses a transaction-driven architecture: reservation, booking, receipt, expense and voucher transactions update the related operational and accounting records together.

### Management modules

- Executive dashboard with plot, sales, collection, overdue, CRM and development KPIs
- Customer master and real-time plot inventory
- Plot reservation with optional refundable deposit accounting
- Booking, installment schedule generation and sale-value amendments
- Receipt posting and automatic allocation against installments
- Twelve-month expected-versus-actual collection forecast
- CRM leads, assignments, stages and follow-up activities
- Development work packages, budgets, actual costs and progress updates
- Double-entry accounting, vouchers, reversals, trial balance, P&L and balance sheet
- Dedicated expense register, including director-paid expenses
- Parties, vendors, contractors, dealers and directors
- Purchase orders and approval status
- Employee master, payroll preparation and salary payment posting
- RUDA and regulatory compliance tracking
- Document metadata register
- Audit trail and role-based users

### Mobile application

The web application is a PWA. After it is hosted through HTTPS, management and customers can install it on a phone from the browser without maintaining separate Android and iOS codebases.

- Management roles see finance, CRM, development and operational modules according to permission.
- Customer accounts see only their own plots, receipts, balances and installment schedule.
- The service worker caches the application shell; financial data remains network-controlled and is not silently edited offline.

## Technology

- FastAPI
- SQLAlchemy 2
- SQLite for local pilot
- PostgreSQL-ready through `DATABASE_URL`
- Responsive vanilla JavaScript frontend
- PWA manifest and service worker
- HttpOnly session cookies and CSRF protection
- PBKDF2-SHA256 password hashing
- GZip response compression and indexed database fields

## Local setup

### Windows

Run:

```text
START_HORIZON_ERP_WINDOWS.bat
```

The launcher creates `.venv`, installs dependencies and starts the server on:

```text
http://127.0.0.1:8000
```

### Linux or macOS

```bash
chmod +x start_linux_mac.sh
./start_linux_mac.sh
```

### Manual start

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

## Initial users

| Username | Password | Role |
|---|---|---|
| admin | Admin@123 | Admin |
| finance | Finance@123 | Finance |
| sales | Sales@123 | Sales |
| crm | CRM@123 | CRM |
| site | Site@123 | Development |
| customer | Customer@123 | Customer portal |

Change all initial passwords before real use.

## Core accounting rules implemented

### Plot reserved without deposit

No accounting voucher is posted. The plot changes from `Available` to `Reserved` and the status history is recorded.

### Refundable reservation deposit

```text
Dr Cash / Bank
    Cr Customer Reservation Deposits
```

### Reservation converted into booking

```text
Dr Customer Receivable
    Cr Residential or Commercial Plot Sales
```

The reservation liability is then adjusted against receivable.

### Customer receipt

```text
Dr Cash / Bank
    Cr Customer Receivable
```

### Director-paid expense

Example: Salman personally pays a RUDA penalty.

```text
Dr RUDA Penalty Expense
    Cr Director Current Account - Salman
```

### Corrections

Posted vouchers cannot be edited. Use **Reverse** and post the corrected voucher. Booked sale values use **Sale Amendment**, which posts the accounting difference and rebuilds the outstanding installment schedule.

## API documentation

When running locally:

```text
http://127.0.0.1:8000/api/docs
```

## Data migration

The bundle includes the V7 source database and the current migrated V21 Horizon Homes database. On a clean database, startup migrates V7 customers, plots, bookings, receipts, accounts, vouchers and voucher lines.

## Verification

Run:

```bash
python scripts/verify_system.py
```

The verifier checks record counts, journal balance and the WhatsApp integration schema in addition to core ERP data.

## Deployment

See `docs/DEPLOY_FREE_PILOT.md` and the included `render.yaml`.

For production accounting, use PostgreSQL, paid always-on hosting, encrypted backups, a custom domain, HTTPS, password rotation and independent reconciliation of migrated opening balances.


## DATA MIGRATION & RECONCILIATION
Open Finance → Data Migration & Reconciliation. The migration module retains the historical master reconciliation while the live ERP now contains 370 vouchers after subsequent controlled transactions/amendments. Re-uploading the same workbook is safely skipped by SHA-256 file hash. Exceptions are never silently ignored and appear by status. Posted financial vouchers cannot be deleted by batch rollback.


## V20 Project Overview

A new management-only Project Overview combines the supplied land deed, final-submission layout and KMZ boundary. ERP-controlled area and current boundary geometry can be edited with reasons and revision history while the original source geometry remains retained for audit comparison.


## V21 Custom Payment Plans & Plot Transfers

V21 adds an upload-driven payment plan master and strict plot transfer control. Download the Excel template from Sales & Collections > Payment Plans, fill one or more Plan Codes and upload the file. Payment lines may be Fixed rupees, Percent of booking net sale value, or one final Balance line. Uploaded plans can be selected on new bookings or applied to existing bookings, with existing receipts automatically reapplied to the regenerated schedule.

Plot Transfers are available under Sales & Collections > Plot Transfers. The system rechecks plot outstanding, booking financial balance, and installment balances at posting time. If any dues exceed Rs 0.01, transfer is rejected with no override. Completed transfers update the current booking and plot owner while preserving the historical receipt and audit trail.
