## V23 — Receivables, aging & future forecast
- Added Receivables & Aging module.
- Added due-through-current-month and true overdue controls.
- Added Booking / Down Payment and Confirmation overdue breakdowns.
- Added plot-wise overdue / outstanding analysis.
- Added date-range forecast grouped by month, year, or plot.
- Added due-type filtering, CSV export and print.
- Preserved the user-uploaded V22 database and current posted transactions.


## V22 — Biometric customer transfer security

- Added privacy-safe WebAuthn/passkey enrollment to Customer Master.
- Added configurable biometric transfer policy: Both Parties, Outgoing Only, or Disabled.
- Added single-use, short-lived biometric verification tokens tied to exact customer + booking + transfer purpose.
- Plot transfer still requires zero remaining dues and now consumes required biometric approvals before ownership changes.
- Added biometric credential/audit tables without storing raw fingerprint or face images.
- Added HTTPS/RP-ID deployment settings for hosted biometric use.
## V20 - Project Overview & KMZ Control
- Added source-controlled Horizon Homes Project Overview.
- Added editable ERP area, editable current boundary, KMZ re-import/reset, layout preview, source-document access and revision history.
- Added deed/layout/KMZ cross-checks without silently changing source records.

# Changelog

## V19.0.0
- Added universal sortable headers across all major ERP windows.
- Added allow-listed server-side sorting across paginated modules and local sorting for report/portal/mapping tables.
- Added Meta WhatsApp Business Cloud API configuration and secure environment-variable credential support.
- Added booking confirmation and installment due reminder WhatsApp actions.
- Added controlled bulk due reminders, duplicate-send protection and WhatsApp delivery audit log.
- Added manual WhatsApp-link fallback when API credentials are unavailable.
- Preserved the uploaded V18 database and verified 370 vouchers / 740 voucher lines remain balanced at Rs.169,504,677 debit and credit.

## V13.0.0
- Added Account Cleanup & Mapping module.
- Consolidated Humayun Director Current A/C into Director Current Account - Humayun.
- Consolidated Salman Director Current A/C into Director Current Account - Salman.
- Preserved Cash Held, Director Receivable and Loan Payable as distinct accounts.
- Added account alias audit records and restore capability.
- Inactive alias accounts are excluded from new vouchers, expenses, report account selectors and trial balance.
- Verified financial control totals remain Rs.138,234,677 debit and credit.


## V12.0.0

- Rebuilt the former local prototype as FastAPI + SQLAlchemy application.
- Added responsive professional management interface.
- Added role-based management and customer PWA portals.
- Migrated V7 customers, plots, bookings, receipts, accounts and vouchers.
- Added CSRF-protected database sessions and PBKDF2 password hashing.
- Added optimistic table-edit controls.
- Added reservation, booking, receipt and sale-amendment transaction engine.
- Added expense register and director-paid expense support.
- Added CRM, development, parties, procurement, HR, payroll, RUDA compliance and documents.
- Added voucher reversal and accounting statements.
- Added Render, Docker and PostgreSQL deployment configuration.

## V24 - Booking Date Correction
- Booking date is now editable from Sales & Collections > Bookings > Edit.
- Date corrections require a reason/approval reference.
- Corrected dates automatically regenerate built-in and custom-template due schedules.
- Existing reservation deposits and receipts are reapplied after rescheduling.
- Future dates, dates before a linked reservation, and dates after an existing posted receipt are blocked.
- Posted accounting voucher dates remain audit-protected.
