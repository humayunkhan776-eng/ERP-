HORIZON ERP ENTERPRISE V29 — FINANCIAL INTEGRITY CONTROL

HORIZON ERP ENTERPRISE V24
Crescent Horizon Developers (Pvt.) Limited — Horizon Homes

This package is a working multi-user web ERP and installable mobile PWA. It is not an Excel workbook and it is not licensed SAP software.

QUICK START ON WINDOWS
1. Extract the complete ZIP into a new folder.
2. Double-click START_HORIZON_ERP_WINDOWS.bat.
3. The first run creates a private Python environment and installs required packages.
4. Open http://127.0.0.1:8000 if the browser does not open automatically.
5. Login with admin / Admin@123.
6. Immediately change the password from Settings & Deployment.

INITIAL ROLE ACCOUNTS
admin     / Admin@123     Full administration
finance   / Finance@123   Finance, expenses, reports, HR and procurement
sales     / Sales@123     Customers, plots, reservations, bookings and receipts
crm       / CRM@123       CRM and customer records
site      / Site@123      Development, procurement and compliance
customer  / Customer@123 Customer mobile portal linked to the first migrated customer

CURRENT DATA PRESERVED FROM THE UPLOADED V18 ERP
- 31 customers
- 103 plots
- 31 bookings
- 31 receipts
- 370 accounting vouchers
- 740 voucher lines
- 61 chart-of-accounts records
- Parties, installment schedules, development, HR and RUDA records



NEW IN V24 - BOOKING DATE CORRECTION
------------------------------------
Sales & Collections > Bookings > Edit now contains an editable Booking Date field.
If the date changes, enter a reason / approval reference. The ERP automatically regenerates
confirmation, installment, bulk-payment and possession due dates and reapplies all existing receipts.
Customer, plot and posted sale values remain protected.

NEW IN V23 - RECEIVABLES & AGING
---------------------------------
- Due through current month
- Overdue as-of-today
- Booking / Down Payment overdue
- Confirmation overdue
- Future receivable forecast with user-entered date range
- Receivables grouped by Plot, Month, or Year
- Due-type filter and CSV export

NEW IN V22 - BIOMETRIC TRANSFER SECURITY
- Customer biometric/passkey enrollment from Customer Master.
- Plot Transfer can require outgoing and incoming customer biometric verification.
- Raw fingerprint/face data is never stored; only public passkey credentials and audit results are kept.
- Production biometric use requires HTTPS and configured WEBAUTHN_RP_ID / WEBAUTHN_ORIGIN.
- Transfer dues control remains mandatory.

MAIN MODULES
- Executive dashboard
- Plot inventory
- Reservations
- Sales bookings and controlled sale amendments
- Receipts and installment allocation
- Expected collection forecast
- WhatsApp Notifications
- Dealer and commission management
- Customer CRM
- Development control
- Expense register
- Double-entry vouchers and professional financial reports
- Parties, vendors and contractors
- Procurement and purchase orders
- HR and payroll
- RUDA and compliance register
- Document register
- Data Migration & Reconciliation
- Account Cleanup & Mapping
- Audit trail
- Users and role permissions
- Management and customer mobile portals through one installable PWA

NEW IN V20 — SORTING IN ALL ERP TABLES
- Click sortable table headings to sort ascending/descending.
- Major paginated modules sort on the server across the entire dataset.
- Report tables, account mappings and portal tables also support local heading sorting.
- Search and pagination keep the selected order.
- Actions/Link columns remain unsorted by design.

NEW IN V20 — WHATSAPP BUSINESS NOTIFICATIONS
Open Sales & Collections -> WhatsApp Notifications.
The module supports Meta WhatsApp Business Cloud API booking confirmations and installment due reminders, plus a manual WhatsApp-link fallback.

API configuration requires:
- Meta WhatsApp Phone Number ID
- Access Token (prefer WHATSAPP_ACCESS_TOKEN environment variable for production)
- Approved booking message template
- Approved due-reminder template
- Customer mobile numbers in international format or Pakistan local format (default country code 92)

Default booking template variables:
1 Customer Name | 2 Booking No | 3 Plot No | 4 Net Sale | 5 Received | 6 Outstanding

Default due template variables:
1 Customer Name | 2 Plot No | 3 Due Type | 4 Due Date | 5 Due Balance | 6 Total Outstanding

You can:
- Send a booking notification from Bookings -> WhatsApp.
- Send an outstanding installment reminder from Installments & Forecast -> WhatsApp.
- Send controlled bulk due reminders from the WhatsApp Notifications centre.
- Review success/failure history and provider message IDs in the delivery log.
- Enable automatic booking notification after API/template setup.

IMPORTANT: Existing migrated customer mobile fields are currently blank. Add verified mobile numbers before using notification sending.

FINANCIAL CONTROL VERIFIED FOR THIS PACKAGE
- Trial Balance Debit: Rs 169,504,677
- Trial Balance Credit: Rs 169,504,677
- Difference: Rs 0
- 370 vouchers / 740 voucher lines

IMPORTANT ACCOUNTING CONTROL
Posted financial values are not edited directly in inventory tables. Use reservations, bookings, receipts, sale amendments, vouchers or reversals so plot balances, ledgers and audit trails remain synchronized.

PRODUCTION WARNING
The included SQLite database is suitable for a local office pilot. For internet hosting and multiple offices, configure PostgreSQL using DATABASE_URL. Use HTTPS, strong passwords, restricted roles, backups and preferably environment variables for API secrets.

PROJECT OVERVIEW / KMZ
The ERP can be extended with a map-driven Project Overview after the Horizon Homes KMZ and land-contract documents are supplied. Do not enter guessed land/title data before source documents are reviewed.


NEW IN V21 — CUSTOM PAYMENT PLANS
- Download Excel upload template from Payment Plans.
- Upload multiple customized plan codes in one file.
- Use Fixed, Percent, or Balance schedule lines.
- Select uploaded plan when booking or editing an existing booking.

NEW IN V21 — PLOT TRANSFERS
- Transfer fully-paid plots between customers.
- Transfer is blocked if any plot/booking/installment dues remain.
- No dues override is provided.
