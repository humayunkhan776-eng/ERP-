# Horizon ERP V29 — Deployment Ready

This bundle has been checked locally with Python bytecode compilation and a local FastAPI health test.

## Production runtime
- FastAPI + Uvicorn
- PostgreSQL via `DATABASE_URL`
- HTTPS provided by the hosting platform
- `render.yaml` is included
- Health check: `/api/health`

## Render settings
- Service: `horizon-erp-enterprise`
- Runtime: Python
- Build: `pip install -r requirements.txt`
- Start: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
- Python: 3.12.4
- Health: `/api/health`
- Required secrets: `DATABASE_URL`, `DEFAULT_ADMIN_PASSWORD`
- `COOKIE_SECURE=1`
- `SESSION_HOURS=12`

## Important data note
The package contains `data/v7_source.db` because the application uses it as its built-in migration source. The older local runtime database `data/horizon_erp_v10.db` is deliberately excluded from the production bundle so an obsolete SQLite runtime database is not accidentally treated as production data.

Before declaring production live, the production PostgreSQL database must be initialized and the required business data migration/reconciliation must be verified.
