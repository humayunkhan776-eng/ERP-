from __future__ import annotations

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import shutil
from datetime import datetime

from app.core.config import BASE_DIR, DATABASE_URL

if not DATABASE_URL.startswith("sqlite:///"):
    raise SystemExit("This script is for local SQLite mode. Use your PostgreSQL provider's backup system in cloud mode.")

source = Path(DATABASE_URL.replace("sqlite:///", "", 1))
backup_dir = BASE_DIR / "backups"
backup_dir.mkdir(exist_ok=True)
target = backup_dir / f"horizon_erp_{datetime.now():%Y%m%d_%H%M%S}.db"
shutil.copy2(source, target)
print(f"Backup created: {target}")
