from __future__ import annotations

import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import func, select
from app.init_db import initialize_database
from app.db import SessionLocal
from app.models import Booking, Plot, ProjectProfile, Receipt, Voucher, VoucherLine
from app.services.project_overview import area_metrics

initialize_database()
db=SessionLocal()
try:
    p=db.scalar(select(ProjectProfile).order_by(ProjectProfile.id))
    assert p, 'Project profile is missing'
    coords=json.loads(p.original_boundary_json)
    m=area_metrics(coords,225)
    assert abs(float(p.legal_area_marla)-566)<0.001
    assert abs(float(p.layout_area_marla)-566)<0.001
    assert 567 < m['marla'] < 568
    sources=Path(__file__).resolve().parents[1]/'data'/'project_sources'
    for name in ['deed_of_agreement.docx','final_submission.pdf','horizon_homes_28_30k.kmz','layout_plan_preview.png']:
        assert (sources/name).is_file(), f'Missing source file: {name}'
    debit,credit=db.execute(select(func.coalesce(func.sum(VoucherLine.debit),0),func.coalesce(func.sum(VoucherLine.credit),0)).join(Voucher,Voucher.id==VoucherLine.voucher_id).where(Voucher.status=='Posted')).one()
    print('HORIZON ERP V20 PROJECT OVERVIEW VERIFICATION')
    print('='*48)
    print(f'Legal / ERP initial area : {float(p.legal_area_marla)/20:.2f} K')
    print(f'Layout area              : {float(p.layout_area_marla)/20:.2f} K')
    print(f'Original KMZ area        : {m["kanal"]:.3f} K / {m["sqm"]:,.0f} sqm')
    print(f'ERP plot inventory       : {db.scalar(select(func.count()).select_from(Plot))}')
    print(f'Bookings                 : {db.scalar(select(func.count()).select_from(Booking))}')
    print(f'Receipts                 : {db.scalar(select(func.count()).select_from(Receipt))}')
    print(f'Posted journal debit     : Rs.{float(debit):,.2f}')
    print(f'Posted journal credit    : Rs.{float(credit):,.2f}')
    print(f'Journal difference       : Rs.{float(debit-credit):,.2f}')
    print('Source pack              : OK')
    print('Project profile          : OK')
    print('Boundary geometry        : OK')
finally:
    db.close()
