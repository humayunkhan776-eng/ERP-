from sqlalchemy import func, select
from app.db import SessionLocal
from app.models import Booking, BookingPaymentPlan, PaymentPlanTemplate, PaymentPlanTemplateLine, PlotTransfer, VoucherLine

with SessionLocal() as db:
    debit=float(db.scalar(select(func.coalesce(func.sum(VoucherLine.debit),0))) or 0)
    credit=float(db.scalar(select(func.coalesce(func.sum(VoucherLine.credit),0))) or 0)
    print('HORIZON ERP V21 VERIFICATION')
    print('Payment plan templates:', db.scalar(select(func.count()).select_from(PaymentPlanTemplate)))
    print('Payment plan lines:', db.scalar(select(func.count()).select_from(PaymentPlanTemplateLine)))
    print('Booking plan assignments:', db.scalar(select(func.count()).select_from(BookingPaymentPlan)))
    print('Plot transfers:', db.scalar(select(func.count()).select_from(PlotTransfer)))
    print('Bookings:', db.scalar(select(func.count()).select_from(Booking)))
    print('Debit:', debit)
    print('Credit:', credit)
    print('Difference:', round(debit-credit,2))
    assert round(debit-credit,2)==0
    assert db.scalar(select(func.count()).select_from(PaymentPlanTemplate)) >= 1
