from pathlib import Path
from sqlalchemy import func, select
from app.db import SessionLocal
from app.models import Booking, Installment, Voucher, VoucherLine

BASE = Path(__file__).resolve().parents[1]
with SessionLocal() as db:
    debit=float(db.scalar(select(func.coalesce(func.sum(VoucherLine.debit),0)).join(Voucher).where(Voucher.status=="Posted")) or 0)
    credit=float(db.scalar(select(func.coalesce(func.sum(VoucherLine.credit),0)).join(Voucher).where(Voucher.status=="Posted")) or 0)
    bookings=db.scalar(select(func.count()).select_from(Booking))
    installments=db.scalar(select(func.count()).select_from(Installment))
    assert round(debit-credit,2)==0
    print("HORIZON ERP V24 VERIFICATION")
    print("Bookings:",bookings)
    print("Installment lines:",installments)
    print("Posted debit:",debit)
    print("Posted credit:",credit)
    print("Difference:",round(debit-credit,2))

js=(BASE/"app/static/app-v24.js").read_text(encoding="utf-8")
idx=(BASE/"app/static/index.html").read_text(encoding="utf-8")
erp=(BASE/"app/services/erp.py").read_text(encoding="utf-8")
assert "name:'booking_date',label:'Booking date',type:'date'" in js
assert "date_change_reason" in js
assert "booking-date correction" in erp.lower()
assert "schedule_regenerated" in erp
assert "app-v24.js" in idx and "styles-v24.css" in idx and "ENTERPRISE V24" in idx
print("Booking-date UI/backend controls: PASS")
