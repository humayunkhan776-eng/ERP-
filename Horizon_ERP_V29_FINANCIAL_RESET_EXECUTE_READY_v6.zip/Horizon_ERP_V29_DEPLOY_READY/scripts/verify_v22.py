from pathlib import Path
from sqlalchemy import func, select

from app.db import SessionLocal
from app.models import (
    BiometricChallenge, BiometricCredential, BiometricVerification, Booking, Customer,
    Plot, PlotTransfer, Setting, Voucher, VoucherLine,
)

BASE = Path(__file__).resolve().parents[1]

with SessionLocal() as db:
    mode = db.get(Setting, "biometric_transfer_mode")
    debit = float(db.scalar(select(func.coalesce(func.sum(VoucherLine.debit), 0)).join(Voucher).where(Voucher.status == "Posted")) or 0)
    credit = float(db.scalar(select(func.coalesce(func.sum(VoucherLine.credit), 0)).join(Voucher).where(Voucher.status == "Posted")) or 0)
    print("HORIZON ERP V22 VERIFICATION")
    print("Customers:", db.scalar(select(func.count()).select_from(Customer)))
    print("Plots:", db.scalar(select(func.count()).select_from(Plot)))
    print("Bookings:", db.scalar(select(func.count()).select_from(Booking)))
    print("Plot transfers:", db.scalar(select(func.count()).select_from(PlotTransfer)))
    print("Biometric credentials:", db.scalar(select(func.count()).select_from(BiometricCredential)))
    print("Biometric challenges:", db.scalar(select(func.count()).select_from(BiometricChallenge)))
    print("Biometric verifications:", db.scalar(select(func.count()).select_from(BiometricVerification)))
    print("Biometric transfer mode:", mode.value if mode else "MISSING")
    print("Debit:", debit)
    print("Credit:", credit)
    print("Difference:", round(debit-credit, 2))

js = (BASE / "app/static/app-v22.js").read_text(encoding="utf-8")
idx = (BASE / "app/static/index.html").read_text(encoding="utf-8")
assert "verifyCustomerBiometric" in js
assert "plot_transfer_outgoing" in js
assert "plot_transfer_incoming" in js
assert "app-v22.js" in idx and "styles-v22.css" in idx
assert (BASE / "app/services/biometrics.py").exists()
print("Static biometric workflow: PASS")
