from __future__ import annotations

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import func, select

from app.init_db import initialize_database
from app.db import SessionLocal
from app.models import (
    Account, Booking, ComplianceItem, Customer, DevelopmentProject, Employee, Party,
    Plot, Receipt, User, Voucher, VoucherLine, WhatsAppMessageLog, Setting, ProjectProfile, ProjectAreaRevision
)
from app.services.accounting import trial_balance

initialize_database()
db = SessionLocal()
try:
    checks = {
        "Users": db.scalar(select(func.count()).select_from(User)),
        "Customers": db.scalar(select(func.count()).select_from(Customer)),
        "Plots": db.scalar(select(func.count()).select_from(Plot)),
        "Bookings": db.scalar(select(func.count()).select_from(Booking)),
        "Receipts": db.scalar(select(func.count()).select_from(Receipt)),
        "Accounts": db.scalar(select(func.count()).select_from(Account)),
        "Vouchers": db.scalar(select(func.count()).select_from(Voucher)),
        "Voucher lines": db.scalar(select(func.count()).select_from(VoucherLine)),
        "Parties": db.scalar(select(func.count()).select_from(Party)),
        "Employees": db.scalar(select(func.count()).select_from(Employee)),
        "Development packages": db.scalar(select(func.count()).select_from(DevelopmentProject)),
        "Compliance items": db.scalar(select(func.count()).select_from(ComplianceItem)),
        "WhatsApp message logs": db.scalar(select(func.count()).select_from(WhatsAppMessageLog)),
        "Project profiles": db.scalar(select(func.count()).select_from(ProjectProfile)),
        "Project area revisions": db.scalar(select(func.count()).select_from(ProjectAreaRevision)),
    }
    tb = trial_balance(db)
    debit = sum(x["debit"] for x in tb)
    credit = sum(x["credit"] for x in tb)
    print("HORIZON ERP V20 SYSTEM VERIFICATION")
    print("=" * 42)
    for label, count in checks.items():
        print(f"{label:24} {count:>8}  OK")
    print(f"{'Trial balance debit':24} {debit:>14,.2f}")
    print(f"{'Trial balance credit':24} {credit:>14,.2f}")
    print(f"{'Journal difference':24} {debit-credit:>14,.2f}  {'OK' if abs(debit-credit)<0.01 else 'REVIEW'}")
    wa_table = WhatsAppMessageLog.__tablename__
    wa_enabled = (db.get(Setting, "whatsapp_enabled").value if db.get(Setting, "whatsapp_enabled") else "0")
    print(f"{'WhatsApp integration':24} {'ENABLED' if wa_enabled == '1' else 'READY / DISABLED':>14}  OK")
    print(f"{'WhatsApp log table':24} {wa_table:>14}  OK")
    if abs(debit-credit) >= 0.01:
        raise SystemExit(1)
finally:
    db.close()
