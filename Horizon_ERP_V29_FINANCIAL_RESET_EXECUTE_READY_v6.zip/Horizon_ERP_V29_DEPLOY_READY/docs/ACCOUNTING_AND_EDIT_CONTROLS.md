# Accounting and edit controls

## Master-table edits

Edit buttons are available on customer, plot, CRM, development, party, purchase order, employee, compliance and user tables.

Optimistic locking checks the record version. If another user changed the same record, the second user is asked to refresh rather than silently overwriting data.

## Fields not editable directly

The following plot fields are transaction-controlled:

- Status
- Customer
- Sale value
- Received amount
- Outstanding amount
- Payment status

They update through reservation, booking, receipt, cancellation/release or sale-amendment actions.

## Posted accounting records

Posted vouchers are immutable. Corrections use a full reversal voucher and a corrected repost. This preserves:

- Original voucher
- Reversal link
- User and time
- Reason
- Balanced double entry

## Reservation control

- Zero deposit: no journal entry
- Refundable deposit: liability
- Booking conversion: deposit liability adjusted against receivable
- Release: deposit refund and plot returned to available

## Sale amendment

Only Finance or Admin can amend a posted sale value. The system:

1. Posts the increase or decrease between customer receivable and plot sales.
2. Updates plot sale value and outstanding balance.
3. Rebuilds the remaining installment schedule.
4. Reallocates received amounts.
5. Records an audit log.

## Expense control

The Expense Register asks for:

- Expense date
- Expense account
- Amount
- Cash, bank or director current account
- Recipient
- Reference
- Narration

It creates a balanced posted voucher. The expense table remains a report of vouchers rather than a separate unconnected ledger.
