# Free pilot hosting and mobile installation

## Recommended pilot architecture

- **Web application:** Render web service
- **Database:** Supabase PostgreSQL
- **Mobile delivery:** Installable Horizon ERP PWA from the hosted HTTPS URL
- **Source control:** Private GitHub repository

This is suitable for testing and internal demonstrations. It is not the recommended permanent hosting arrangement for company accounting.

## 1. Create the PostgreSQL database

1. Create a Supabase project.
2. Open the database connection settings.
3. Copy a PostgreSQL connection string appropriate for a server application.
4. Keep the password private.
5. Use it as the `DATABASE_URL` environment variable.

Example shape:

```text
postgresql://USER:PASSWORD@HOST:5432/postgres
```

The application automatically changes this to SQLAlchemy's psycopg driver format.

## 2. Put the project in a private GitHub repository

Upload the complete project except local secrets and the generated `.venv` folder. Do not publish customer CNIC data or a production database in a public repository.

## 3. Deploy on Render

The package includes `render.yaml`.

Set these environment variables in Render:

```text
DATABASE_URL=<Supabase connection string>
COOKIE_SECURE=1
SESSION_HOURS=12
DEFAULT_ADMIN_PASSWORD=<strong unique password>
```

Build command:

```text
pip install -r requirements.txt
```

Start command:

```text
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Health check:

```text
/api/health
```

## 4. Install on Android

1. Open the hosted HTTPS URL in Chrome.
2. Sign in.
3. Tap the browser menu.
4. Choose **Install app** or **Add to Home screen**.

## 5. Install on iPhone or iPad

1. Open the hosted HTTPS URL in Safari.
2. Tap **Share**.
3. Choose **Add to Home Screen**.
4. Open the Horizon ERP icon from the Home Screen.

## 6. Customer app accounts

Create a user with role `Customer` and link the user to the matching customer record. That user will see only:

- Their plots
- Sale values
- Paid and outstanding balances
- Receipts
- Installment schedule

## Important free-tier limitations

- Free web services may sleep after inactivity and take time to wake.
- A free web service's local filesystem is not a safe place for uploaded files or SQLite accounting data.
- Free database projects have usage and inactivity limits.
- Free services may not provide the backup, uptime and recovery guarantees required for production accounts.

For live operations, upgrade to always-on hosting and a backed-up PostgreSQL database.
