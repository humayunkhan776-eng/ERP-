# Production security checklist

- Change all seeded passwords.
- Disable demo accounts that are not needed.
- Use HTTPS and set `COOKIE_SECURE=1`.
- Store secrets only in hosting environment variables.
- Use a private source repository.
- Use PostgreSQL instead of SQLite for internet deployment.
- Restrict database network access.
- Schedule encrypted daily backups and perform restore tests.
- Review user roles monthly.
- Do not permit shared usernames.
- Reconcile the trial balance and customer receivables before go-live.
- Review the audit trail for unauthorized edits.
- Use private object storage for CNIC and customer documents.
- Obtain appropriate consent and follow Pakistan data-protection and tax requirements.
