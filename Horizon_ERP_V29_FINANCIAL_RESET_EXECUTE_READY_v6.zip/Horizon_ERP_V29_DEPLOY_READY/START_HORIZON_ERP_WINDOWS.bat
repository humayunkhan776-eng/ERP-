@echo off
setlocal
cd /d "%~dp0"
title Horizon ERP Enterprise V28
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  py -m venv .venv 2>nul || python -m venv .venv
  call .venv\Scripts\activate.bat
  python -m pip install --upgrade pip
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate.bat
)
python -c "import webauthn" >nul 2>nul || (
  echo Installing biometric/passkey dependency...
  pip install -r requirements.txt
)
start "" http://127.0.0.1:8000
python run.py
pause
