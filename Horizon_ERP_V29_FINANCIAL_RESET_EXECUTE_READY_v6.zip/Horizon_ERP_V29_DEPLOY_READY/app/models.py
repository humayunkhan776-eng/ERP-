from __future__ import annotations

from datetime import date, datetime
from typing import Optional

from sqlalchemy import (
    Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, Numeric, String, Text,
    UniqueConstraint
)
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)
    version: Mapped[int] = mapped_column(Integer, default=1)


class User(Base, TimestampMixin):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    role: Mapped[str] = mapped_column(String(40), index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    customer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("customers.id"), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class AuthSession(Base):
    __tablename__ = "auth_sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    csrf_token: Mapped[str] = mapped_column(String(96))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)


class Customer(Base, TimestampMixin):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    father_name: Mapped[str] = mapped_column(String(180), default="")
    cnic: Mapped[str] = mapped_column(String(30), default="", index=True)
    mobile: Mapped[str] = mapped_column(String(30), default="", index=True)
    email: Mapped[str] = mapped_column(String(180), default="")
    address: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(30), default="Active", index=True)


class Plot(Base, TimestampMixin):
    __tablename__ = "plots"
    id: Mapped[int] = mapped_column(primary_key=True)
    plot_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    block: Mapped[str] = mapped_column(String(40), default="")
    category: Mapped[str] = mapped_column(String(40), default="Residential", index=True)
    size_marla: Mapped[float] = mapped_column(Float, default=0)
    status: Mapped[str] = mapped_column(String(30), default="Available", index=True)
    list_price: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    sale_price: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    chz_no: Mapped[str] = mapped_column(String(60), default="", index=True)
    customer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("customers.id"), nullable=True, index=True)
    received: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    outstanding: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    payment_status: Mapped[str] = mapped_column(String(30), default="Not Sold")
    remarks: Mapped[str] = mapped_column(Text, default="")


class PlotStatusHistory(Base):
    __tablename__ = "plot_status_history"
    id: Mapped[int] = mapped_column(primary_key=True)
    plot_id: Mapped[int] = mapped_column(ForeignKey("plots.id", ondelete="CASCADE"), index=True)
    old_status: Mapped[str] = mapped_column(String(30))
    new_status: Mapped[str] = mapped_column(String(30))
    change_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    changed_by: Mapped[str] = mapped_column(String(120))
    remarks: Mapped[str] = mapped_column(Text, default="")


class Reservation(Base, TimestampMixin):
    __tablename__ = "reservations"
    id: Mapped[int] = mapped_column(primary_key=True)
    reservation_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    reservation_date: Mapped[date] = mapped_column(Date)
    expiry_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    plot_id: Mapped[int] = mapped_column(ForeignKey("plots.id"), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    refundable: Mapped[bool] = mapped_column(Boolean, default=True)
    payment_mode: Mapped[str] = mapped_column(String(30), default="Cash")
    reference: Mapped[str] = mapped_column(String(100), default="")
    dealer_name: Mapped[str] = mapped_column(String(160), default="")
    status: Mapped[str] = mapped_column(String(30), default="Active", index=True)
    remarks: Mapped[str] = mapped_column(Text, default="")


class Booking(Base, TimestampMixin):
    __tablename__ = "bookings"
    id: Mapped[int] = mapped_column(primary_key=True)
    booking_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    booking_date: Mapped[date] = mapped_column(Date)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    plot_id: Mapped[int] = mapped_column(ForeignKey("plots.id"), index=True)
    sale_price: Mapped[float] = mapped_column(Numeric(16, 2))
    discount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    net_sale_value: Mapped[float] = mapped_column(Numeric(16, 2))
    payment_plan: Mapped[str] = mapped_column(String(50), default="Full Paid")
    dealer_name: Mapped[str] = mapped_column(String(160), default="")
    status: Mapped[str] = mapped_column(String(30), default="Posted", index=True)
    reservation_id: Mapped[Optional[int]] = mapped_column(ForeignKey("reservations.id"), nullable=True)
    posted_voucher_id: Mapped[Optional[int]] = mapped_column(ForeignKey("vouchers.id"), nullable=True)


class Installment(Base, TimestampMixin):
    __tablename__ = "installments"
    id: Mapped[int] = mapped_column(primary_key=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id", ondelete="CASCADE"), index=True)
    due_no: Mapped[int] = mapped_column(Integer)
    due_date: Mapped[date] = mapped_column(Date, index=True)
    due_type: Mapped[str] = mapped_column(String(40))
    amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    paid: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    status: Mapped[str] = mapped_column(String(30), default="Due", index=True)

    __table_args__ = (UniqueConstraint("booking_id", "due_no", name="uq_installment_booking_due"),)


class Receipt(Base, TimestampMixin):
    __tablename__ = "receipts"
    id: Mapped[int] = mapped_column(primary_key=True)
    receipt_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    receipt_date: Mapped[date] = mapped_column(Date, index=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id"), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    amount: Mapped[float] = mapped_column(Numeric(16, 2))
    mode: Mapped[str] = mapped_column(String(30), default="Cash")
    reference: Mapped[str] = mapped_column(String(100), default="")
    narration: Mapped[str] = mapped_column(Text, default="")
    posted_voucher_id: Mapped[Optional[int]] = mapped_column(ForeignKey("vouchers.id"), nullable=True)


class PaymentAllocation(Base):
    __tablename__ = "payment_allocations"
    id: Mapped[int] = mapped_column(primary_key=True)
    receipt_id: Mapped[int] = mapped_column(ForeignKey("receipts.id", ondelete="CASCADE"), index=True)
    installment_id: Mapped[Optional[int]] = mapped_column(ForeignKey("installments.id"), nullable=True, index=True)
    amount: Mapped[float] = mapped_column(Numeric(16, 2))


class Account(Base, TimestampMixin):
    __tablename__ = "accounts"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    type: Mapped[str] = mapped_column(String(30), index=True)
    statement: Mapped[str] = mapped_column(String(30), default="Balance Sheet")
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class AccountAlias(Base):
    __tablename__ = "account_aliases"
    id: Mapped[int] = mapped_column(primary_key=True)
    alias_account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"), unique=True, index=True)
    master_account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"), index=True)
    original_name: Mapped[str] = mapped_column(String(180), default="")
    reason: Mapped[str] = mapped_column(Text, default="")
    moved_line_ids: Mapped[str] = mapped_column(Text, default="[]")
    mapped_by: Mapped[str] = mapped_column(String(120), default="System")
    mapped_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Voucher(Base, TimestampMixin):
    __tablename__ = "vouchers"
    id: Mapped[int] = mapped_column(primary_key=True)
    voucher_no: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    voucher_date: Mapped[date] = mapped_column(Date, index=True)
    voucher_type: Mapped[str] = mapped_column(String(40), index=True)
    party: Mapped[str] = mapped_column(String(180), default="")
    narration: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(30), default="Draft", index=True)
    source_module: Mapped[str] = mapped_column(String(50), default="Manual")
    source_reference: Mapped[str] = mapped_column(String(80), default="", index=True)
    created_by: Mapped[str] = mapped_column(String(120), default="")
    posted_by: Mapped[str] = mapped_column(String(120), default="")
    posted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    reversed_voucher_id: Mapped[Optional[int]] = mapped_column(ForeignKey("vouchers.id"), nullable=True)


class VoucherLine(Base):
    __tablename__ = "voucher_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    voucher_id: Mapped[int] = mapped_column(ForeignKey("vouchers.id", ondelete="CASCADE"), index=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"), index=True)
    debit: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    credit: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    party: Mapped[str] = mapped_column(String(180), default="")
    plot_no: Mapped[str] = mapped_column(String(40), default="")
    memo: Mapped[str] = mapped_column(Text, default="")


class Lead(Base, TimestampMixin):
    __tablename__ = "leads"
    id: Mapped[int] = mapped_column(primary_key=True)
    lead_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    lead_date: Mapped[date] = mapped_column(Date, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    mobile: Mapped[str] = mapped_column(String(30), index=True)
    source: Mapped[str] = mapped_column(String(80), default="Walk-in")
    interest: Mapped[str] = mapped_column(String(120), default="3 Marla Residential")
    budget: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    stage: Mapped[str] = mapped_column(String(40), default="New", index=True)
    assigned_to: Mapped[str] = mapped_column(String(120), default="")
    next_followup: Mapped[Optional[date]] = mapped_column(Date, nullable=True, index=True)
    remarks: Mapped[str] = mapped_column(Text, default="")


class CRMActivity(Base, TimestampMixin):
    __tablename__ = "crm_activities"
    id: Mapped[int] = mapped_column(primary_key=True)
    lead_id: Mapped[int] = mapped_column(ForeignKey("leads.id", ondelete="CASCADE"), index=True)
    activity_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    activity_type: Mapped[str] = mapped_column(String(40), default="Call")
    outcome: Mapped[str] = mapped_column(Text, default="")
    next_followup: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    user_name: Mapped[str] = mapped_column(String(120), default="")


class DevelopmentProject(Base, TimestampMixin):
    __tablename__ = "development_projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    category: Mapped[str] = mapped_column(String(80), default="Infrastructure")
    contractor: Mapped[str] = mapped_column(String(180), default="")
    budget: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    committed_cost: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    actual_cost: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    progress_percent: Mapped[float] = mapped_column(Float, default=0)
    status: Mapped[str] = mapped_column(String(40), default="Planned", index=True)
    start_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    target_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    remarks: Mapped[str] = mapped_column(Text, default="")


class DevelopmentUpdate(Base, TimestampMixin):
    __tablename__ = "development_updates"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("development_projects.id", ondelete="CASCADE"), index=True)
    update_date: Mapped[date] = mapped_column(Date, index=True)
    progress_percent: Mapped[float] = mapped_column(Float)
    actual_cost_increment: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    description: Mapped[str] = mapped_column(Text)
    photo_url: Mapped[str] = mapped_column(String(500), default="")
    created_by: Mapped[str] = mapped_column(String(120), default="")


class Document(Base, TimestampMixin):
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    module: Mapped[str] = mapped_column(String(50), index=True)
    record_id: Mapped[int] = mapped_column(Integer, index=True)
    document_type: Mapped[str] = mapped_column(String(80))
    file_name: Mapped[str] = mapped_column(String(255))
    storage_url: Mapped[str] = mapped_column(String(500), default="")
    uploaded_by: Mapped[str] = mapped_column(String(120), default="")


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, index=True)
    user_name: Mapped[str] = mapped_column(String(120), index=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    module: Mapped[str] = mapped_column(String(80), index=True)
    record_id: Mapped[str] = mapped_column(String(80), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    ip_address: Mapped[str] = mapped_column(String(80), default="")


class Notification(Base, TimestampMixin):
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    role: Mapped[str] = mapped_column(String(40), default="")
    title: Mapped[str] = mapped_column(String(180))
    message: Mapped[str] = mapped_column(Text)
    link: Mapped[str] = mapped_column(String(255), default="")
    read: Mapped[bool] = mapped_column(Boolean, default=False, index=True)


class WhatsAppMessageLog(Base, TimestampMixin):
    __tablename__ = "whatsapp_message_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    message_type: Mapped[str] = mapped_column(String(40), index=True)
    customer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("customers.id"), nullable=True, index=True)
    booking_id: Mapped[Optional[int]] = mapped_column(ForeignKey("bookings.id"), nullable=True, index=True)
    installment_id: Mapped[Optional[int]] = mapped_column(ForeignKey("installments.id"), nullable=True, index=True)
    mobile: Mapped[str] = mapped_column(String(40), default="", index=True)
    template_name: Mapped[str] = mapped_column(String(120), default="")
    request_payload: Mapped[str] = mapped_column(Text, default="")
    provider_message_id: Mapped[str] = mapped_column(String(180), default="", index=True)
    status: Mapped[str] = mapped_column(String(30), default="Pending", index=True)
    error_message: Mapped[str] = mapped_column(Text, default="")
    sent_by: Mapped[str] = mapped_column(String(120), default="")
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True, index=True)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text)




class ProjectProfile(Base, TimestampMixin):
    __tablename__ = "project_profiles"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    developer: Mapped[str] = mapped_column(String(220), default="")
    status: Mapped[str] = mapped_column(String(40), default="Active", index=True)
    mouza: Mapped[str] = mapped_column(String(120), default="")
    deed_location: Mapped[str] = mapped_column(String(300), default="")
    layout_location: Mapped[str] = mapped_column(String(300), default="")
    khasra_numbers: Mapped[str] = mapped_column(Text, default="")
    khewat_numbers: Mapped[str] = mapped_column(Text, default="")
    khatooni_numbers: Mapped[str] = mapped_column(Text, default="")
    landowners_json: Mapped[str] = mapped_column(Text, default="[]")
    legal_area_marla: Mapped[float] = mapped_column(Float, default=0)
    layout_area_marla: Mapped[float] = mapped_column(Float, default=0)
    official_area_marla: Mapped[float] = mapped_column(Float, default=0)
    marla_sqft: Mapped[float] = mapped_column(Float, default=225)
    kmz_area_sqm: Mapped[float] = mapped_column(Float, default=0)
    kmz_area_marla: Mapped[float] = mapped_column(Float, default=0)
    residential_area_marla: Mapped[float] = mapped_column(Float, default=0)
    commercial_area_marla: Mapped[float] = mapped_column(Float, default=0)
    public_building_area_marla: Mapped[float] = mapped_column(Float, default=0)
    roads_parking_area_marla: Mapped[float] = mapped_column(Float, default=0)
    land_rate_per_marla: Mapped[float] = mapped_column(Numeric(18, 2), default=0)
    land_consideration: Mapped[float] = mapped_column(Numeric(18, 2), default=0)
    landowner_profit_share: Mapped[float] = mapped_column(Float, default=0)
    developer_profit_share: Mapped[float] = mapped_column(Float, default=0)
    original_boundary_json: Mapped[str] = mapped_column(Text, default="[]")
    boundary_json: Mapped[str] = mapped_column(Text, default="[]")
    source_kmz_name: Mapped[str] = mapped_column(String(255), default="")
    notes: Mapped[str] = mapped_column(Text, default="")


class ProjectAreaRevision(Base):
    __tablename__ = "project_area_revisions"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("project_profiles.id", ondelete="CASCADE"), index=True)
    changed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, index=True)
    changed_by: Mapped[str] = mapped_column(String(120), default="")
    change_type: Mapped[str] = mapped_column(String(50), default="Area Edit", index=True)
    old_official_area_marla: Mapped[float] = mapped_column(Float, default=0)
    new_official_area_marla: Mapped[float] = mapped_column(Float, default=0)
    old_boundary_json: Mapped[str] = mapped_column(Text, default="[]")
    new_boundary_json: Mapped[str] = mapped_column(Text, default="[]")
    reason: Mapped[str] = mapped_column(Text, default="")

Index("ix_plot_status_category", Plot.status, Plot.category)
Index("ix_booking_customer_plot", Booking.customer_id, Booking.plot_id)
Index("ix_voucher_status_date", Voucher.status, Voucher.voucher_date)


class Party(Base, TimestampMixin):
    __tablename__ = "parties"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    party_type: Mapped[str] = mapped_column(String(40), default="Vendor", index=True)
    mobile: Mapped[str] = mapped_column(String(30), default="")
    email: Mapped[str] = mapped_column(String(180), default="")
    address: Mapped[str] = mapped_column(Text, default="")
    opening_balance: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    balance_side: Mapped[str] = mapped_column(String(10), default="Credit")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    remarks: Mapped[str] = mapped_column(Text, default="")


class PurchaseOrder(Base, TimestampMixin):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    po_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    po_date: Mapped[date] = mapped_column(Date, index=True)
    vendor_id: Mapped[int] = mapped_column(ForeignKey("parties.id"), index=True)
    description: Mapped[str] = mapped_column(Text)
    amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    status: Mapped[str] = mapped_column(String(30), default="Draft", index=True)
    expected_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    approved_by: Mapped[str] = mapped_column(String(120), default="")
    remarks: Mapped[str] = mapped_column(Text, default="")


class Employee(Base, TimestampMixin):
    __tablename__ = "employees"
    id: Mapped[int] = mapped_column(primary_key=True)
    employee_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    department: Mapped[str] = mapped_column(String(80), default="Administration", index=True)
    designation: Mapped[str] = mapped_column(String(120), default="")
    mobile: Mapped[str] = mapped_column(String(30), default="")
    cnic: Mapped[str] = mapped_column(String(30), default="")
    joining_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    salary: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    status: Mapped[str] = mapped_column(String(30), default="Active", index=True)
    remarks: Mapped[str] = mapped_column(Text, default="")


class Payroll(Base, TimestampMixin):
    __tablename__ = "payroll"
    id: Mapped[int] = mapped_column(primary_key=True)
    payroll_month: Mapped[str] = mapped_column(String(7), index=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("employees.id"), index=True)
    basic_salary: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    allowances: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    deductions: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    net_pay: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    status: Mapped[str] = mapped_column(String(30), default="Draft", index=True)
    paid_voucher_id: Mapped[Optional[int]] = mapped_column(ForeignKey("vouchers.id"), nullable=True)

    __table_args__ = (UniqueConstraint("payroll_month", "employee_id", name="uq_payroll_month_employee"),)


class ComplianceItem(Base, TimestampMixin):
    __tablename__ = "compliance_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    reference_no: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    authority: Mapped[str] = mapped_column(String(80), default="RUDA", index=True)
    subject: Mapped[str] = mapped_column(String(220), index=True)
    issue_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    due_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(30), default="Open", index=True)
    responsible_person: Mapped[str] = mapped_column(String(120), default="")
    remarks: Mapped[str] = mapped_column(Text, default="")


class Commission(Base, TimestampMixin):
    __tablename__ = "commissions"
    id: Mapped[int] = mapped_column(primary_key=True)
    commission_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    commission_date: Mapped[date] = mapped_column(Date, index=True)
    booking_id: Mapped[Optional[int]] = mapped_column(ForeignKey("bookings.id"), nullable=True, index=True)
    dealer_name: Mapped[str] = mapped_column(String(180), index=True)
    commission_type: Mapped[str] = mapped_column(String(40), default="Dealer", index=True)
    basis: Mapped[str] = mapped_column(String(40), default="Net Sale Value")
    base_amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    rate_percent: Mapped[float] = mapped_column(Numeric(8, 4), default=0)
    commission_amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    paid_amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    status: Mapped[str] = mapped_column(String(30), default="Pending", index=True)
    approved_by: Mapped[str] = mapped_column(String(120), default="")
    remarks: Mapped[str] = mapped_column(Text, default="")
    posted_voucher_id: Mapped[Optional[int]] = mapped_column(ForeignKey("vouchers.id"), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)




class PaymentPlanTemplate(Base, TimestampMixin):
    __tablename__ = "payment_plan_templates"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    category: Mapped[str] = mapped_column(String(40), default="All", index=True)
    size_marla: Mapped[float] = mapped_column(Float, default=0)
    description: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    source_filename: Mapped[str] = mapped_column(String(255), default="")


class PaymentPlanTemplateLine(Base, TimestampMixin):
    __tablename__ = "payment_plan_template_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    template_id: Mapped[int] = mapped_column(ForeignKey("payment_plan_templates.id", ondelete="CASCADE"), index=True)
    due_no: Mapped[int] = mapped_column(Integer)
    due_type: Mapped[str] = mapped_column(String(100))
    offset_months: Mapped[int] = mapped_column(Integer, default=0)
    amount_type: Mapped[str] = mapped_column(String(20), default="Fixed")
    amount_value: Mapped[float] = mapped_column(Numeric(16, 4), default=0)
    remarks: Mapped[str] = mapped_column(Text, default="")
    __table_args__ = (UniqueConstraint("template_id", "due_no", name="uq_payment_plan_template_due"),)


class BookingPaymentPlan(Base, TimestampMixin):
    __tablename__ = "booking_payment_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id", ondelete="CASCADE"), unique=True, index=True)
    template_id: Mapped[int] = mapped_column(ForeignKey("payment_plan_templates.id"), index=True)
    plan_code_snapshot: Mapped[str] = mapped_column(String(60), default="")
    plan_name_snapshot: Mapped[str] = mapped_column(String(180), default="")
    assigned_by: Mapped[str] = mapped_column(String(120), default="")


class PlotTransfer(Base, TimestampMixin):
    __tablename__ = "plot_transfers"
    id: Mapped[int] = mapped_column(primary_key=True)
    transfer_no: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    transfer_date: Mapped[date] = mapped_column(Date, index=True)
    plot_id: Mapped[int] = mapped_column(ForeignKey("plots.id"), index=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id"), index=True)
    from_customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    to_customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    dues_at_transfer: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    status: Mapped[str] = mapped_column(String(30), default="Completed", index=True)
    reason: Mapped[str] = mapped_column(Text, default="")
    approved_by: Mapped[str] = mapped_column(String(120), default="")

class BiometricCredential(Base, TimestampMixin):
    """WebAuthn/passkey public credential for a customer. No fingerprint/face image is stored."""
    __tablename__ = "biometric_credentials"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id", ondelete="CASCADE"), index=True)
    credential_id: Mapped[str] = mapped_column(String(1024), unique=True, index=True)
    public_key: Mapped[str] = mapped_column(Text)  # base64url encoded COSE public key
    sign_count: Mapped[int] = mapped_column(Integer, default=0)
    label: Mapped[str] = mapped_column(String(160), default="Customer device")
    transports: Mapped[str] = mapped_column(Text, default="[]")
    rp_id: Mapped[str] = mapped_column(String(255), default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    enrolled_by: Mapped[str] = mapped_column(String(120), default="")
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)


class BiometricChallenge(Base):
    __tablename__ = "biometric_challenges"
    id: Mapped[int] = mapped_column(primary_key=True)
    challenge: Mapped[str] = mapped_column(Text)  # base64url
    challenge_type: Mapped[str] = mapped_column(String(30), index=True)  # registration/authentication
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id", ondelete="CASCADE"), index=True)
    booking_id: Mapped[Optional[int]] = mapped_column(ForeignKey("bookings.id"), nullable=True, index=True)
    purpose: Mapped[str] = mapped_column(String(80), default="customer_identity")
    rp_id: Mapped[str] = mapped_column(String(255), default="")
    expected_origin: Mapped[str] = mapped_column(String(500), default="")
    created_by_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)


class BiometricVerification(Base):
    __tablename__ = "biometric_verifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    booking_id: Mapped[Optional[int]] = mapped_column(ForeignKey("bookings.id"), nullable=True, index=True)
    credential_id: Mapped[int] = mapped_column(ForeignKey("biometric_credentials.id"), index=True)
    purpose: Mapped[str] = mapped_column(String(80), index=True)
    verification_token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    verified_by: Mapped[str] = mapped_column(String(120), default="")
    verified_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    transfer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("plot_transfers.id"), nullable=True, index=True)
    ip_address: Mapped[str] = mapped_column(String(80), default="")

class MigrationBatch(Base, TimestampMixin):
    __tablename__ = "migration_batches"
    id: Mapped[int] = mapped_column(primary_key=True)
    batch_no: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    file_name: Mapped[str] = mapped_column(String(255))
    file_hash: Mapped[str] = mapped_column(String(64), index=True)
    imported_by: Mapped[str] = mapped_column(String(120))
    source_rows: Mapped[int] = mapped_column(Integer, default=0)
    imported_count: Mapped[int] = mapped_column(Integer, default=0)
    skipped_count: Mapped[int] = mapped_column(Integer, default=0)
    duplicate_count: Mapped[int] = mapped_column(Integer, default=0)
    mismatch_count: Mapped[int] = mapped_column(Integer, default=0)
    matched_count: Mapped[int] = mapped_column(Integer, default=0)
    debit_total: Mapped[float] = mapped_column(Numeric(18, 2), default=0)
    credit_total: Mapped[float] = mapped_column(Numeric(18, 2), default=0)
    status: Mapped[str] = mapped_column(String(40), default="Validated", index=True)
    notes: Mapped[str] = mapped_column(Text, default="")


class MigrationRow(Base, TimestampMixin):
    __tablename__ = "migration_rows"
    id: Mapped[int] = mapped_column(primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey("migration_batches.id", ondelete="CASCADE"), index=True)
    migration_key: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    source_workbook: Mapped[str] = mapped_column(String(255))
    source_sheet: Mapped[str] = mapped_column(String(120))
    source_row: Mapped[int] = mapped_column(Integer, index=True)
    voucher_no: Mapped[str] = mapped_column(String(60), index=True)
    transaction_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True, index=True)
    source_account: Mapped[str] = mapped_column(String(180), default="")
    particulars: Mapped[str] = mapped_column(Text, default="")
    paid_received_by: Mapped[str] = mapped_column(String(180), default="")
    debit_account: Mapped[str] = mapped_column(String(180), default="")
    credit_account: Mapped[str] = mapped_column(String(180), default="")
    debit: Mapped[float] = mapped_column(Numeric(18, 2), default=0)
    credit: Mapped[float] = mapped_column(Numeric(18, 2), default=0)
    customer_reference: Mapped[str] = mapped_column(String(180), default="")
    plot_no: Mapped[str] = mapped_column(String(40), default="")
    party_name: Mapped[str] = mapped_column(String(180), default="")
    reconciliation_status: Mapped[str] = mapped_column(String(40), default="Requires Review", index=True)
    mismatch_details: Mapped[str] = mapped_column(Text, default="")
    erp_voucher_id: Mapped[Optional[int]] = mapped_column(ForeignKey("vouchers.id"), nullable=True, index=True)
    posted: Mapped[bool] = mapped_column(Boolean, default=False, index=True)

    __table_args__ = (Index("ix_migration_batch_status", "batch_id", "reconciliation_status"),)
