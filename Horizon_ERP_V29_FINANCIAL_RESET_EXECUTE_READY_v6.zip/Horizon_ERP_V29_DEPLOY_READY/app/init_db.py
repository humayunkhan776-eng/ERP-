from __future__ import annotations

import sqlite3
from datetime import date, datetime
from pathlib import Path

from sqlalchemy import func, select

from .core.config import BASE_DIR, DEFAULT_ADMIN_PASSWORD
from .core.security import hash_password
from .db import Base, SessionLocal, engine
from .models import (
    Account, Booking, ComplianceItem, Customer, DevelopmentProject, Employee, Installment,
    Notification, Party, Plot, PurchaseOrder, Receipt, Setting, User, Voucher, VoucherLine
)
from .services.accounting import ensure_default_accounts
from .services.account_cleanup import ensure_director_account_cleanup
from .services.project_overview import seed_project_profile
from .services.payment_plans import seed_default_payment_plan

SOURCE_DB = BASE_DIR / "data" / "v7_source.db"


def parse_date(value, fallback=None):
    fallback = fallback or date.today()
    if not value:
        return fallback
    text = str(value)[:10]
    try:
        return date.fromisoformat(text)
    except Exception:
        return fallback


def _row_dicts(conn, table):
    try:
        return [dict(row) for row in conn.execute(f"SELECT * FROM {table}")]
    except sqlite3.Error:
        return []


def migrate_v7(db):
    if not SOURCE_DB.exists():
        return {"migrated": False, "reason": "Source V7 database not found"}
    src = sqlite3.connect(SOURCE_DB)
    src.row_factory = sqlite3.Row
    try:
        account_by_name = {a.name: a for a in db.scalars(select(Account)).all()}
        next_code_no = 9000
        for row in _row_dicts(src, "accounts"):
            name = (row.get("name") or "").strip()
            if not name or name in account_by_name:
                continue
            code = str(row.get("code") or next_code_no)
            while db.scalar(select(Account).where(Account.code == code)):
                next_code_no += 1
                code = str(next_code_no)
            acc = Account(
                code=code,
                name=name,
                type=row.get("type") or "Asset",
                statement=row.get("statement") or ("Profit & Loss" if row.get("type") in {"Income", "Expense"} else "Balance Sheet"),
                active=bool(row.get("active", 1)),
            )
            db.add(acc)
            db.flush()
            account_by_name[name] = acc

        customer_map = {}
        customer_by_name = {}
        for row in _row_dicts(src, "customers"):
            customer = Customer(
                code=row.get("code") or f"CUS-{row['id']:05d}",
                name=row.get("name") or f"Customer {row['id']}",
                cnic=row.get("cnic") or "",
                mobile=row.get("mobile") or "",
                address=row.get("address") or "",
                status="Active",
            )
            db.add(customer)
            db.flush()
            customer_map[row["id"]] = customer.id
            customer_by_name[customer.name.strip().lower()] = customer.id

        plot_map = {}
        for row in _row_dicts(src, "plots"):
            client_name = (row.get("client_name") or "").strip()
            status = (row.get("status") or "Available").title()
            if status in {"Sold/Booked", "Booked/Sold"}:
                status = "Booked"
            raw_value = float(row.get("list_price") or 0)
            plot = Plot(
                plot_no=str(row.get("plot_no") or row["id"]),
                block=row.get("block") or "",
                category=row.get("category") or "Residential",
                size_marla=float(row.get("size_marla") or 0),
                status=status,
                list_price=raw_value,
                sale_price=raw_value if status not in {"Available", "Reserved"} else 0,
                chz_no=row.get("chz_no") or "",
                customer_id=customer_by_name.get(client_name.lower()),
                received=float(row.get("received") or 0),
                outstanding=float(row.get("outstanding") or 0),
                payment_status=row.get("payment_status") or ("Not Sold" if status == "Available" else "Due"),
                remarks=row.get("remarks") or "",
            )
            db.add(plot)
            db.flush()
            plot_map[row["id"]] = plot.id

        booking_map = {}
        for row in _row_dicts(src, "bookings"):
            customer_id = customer_map.get(row.get("customer_id"))
            plot_id = plot_map.get(row.get("plot_id"))
            if not customer_id or not plot_id:
                continue
            value = float(row.get("sale_price") or 0)
            booking = Booking(
                booking_no=row.get("booking_no") or f"BKG-{row['id']:05d}",
                booking_date=parse_date(row.get("booking_date")),
                customer_id=customer_id,
                plot_id=plot_id,
                sale_price=value,
                discount=0,
                net_sale_value=value,
                payment_plan=row.get("payment_plan") or "Full Paid",
                dealer_name=row.get("dealer_name") or "",
                status="Posted" if (row.get("status") or "").lower() not in {"cancelled", "canceled"} else "Cancelled",
            )
            db.add(booking)
            db.flush()
            booking_map[row["id"]] = booking.id
            plot = db.get(Plot, plot_id)
            plot.customer_id = customer_id
            plot.sale_price = value or float(plot.sale_price or 0)

        receipt_map = {}
        for row in _row_dicts(src, "receipts"):
            booking_id = booking_map.get(row.get("booking_id"))
            booking = db.get(Booking, booking_id) if booking_id else None
            if not booking:
                continue
            receipt = Receipt(
                receipt_no=row.get("receipt_no") or f"RCPT-{row['id']:05d}",
                receipt_date=parse_date(row.get("receipt_date")),
                booking_id=booking.id,
                customer_id=booking.customer_id,
                amount=float(row.get("amount") or 0),
                mode=row.get("mode") or "Cash",
                reference=row.get("reference") or "",
                narration=row.get("narration") or "",
            )
            db.add(receipt)
            db.flush()
            receipt_map[row["id"]] = receipt.id

        for row in _row_dicts(src, "installments"):
            booking_id = booking_map.get(row.get("booking_id"))
            if not booking_id:
                continue
            db.add(Installment(
                booking_id=booking_id,
                due_no=int(row.get("due_no") or row["id"]),
                due_date=parse_date(row.get("due_date")),
                due_type=row.get("due_type") or "Installment",
                amount=float(row.get("amount") or 0),
                paid=float(row.get("paid") or 0),
                status=row.get("status") or "Due",
            ))

        voucher_map = {}
        for row in _row_dicts(src, "vouchers"):
            number = row.get("voucher_no") or f"MIG-{row['id']:05d}"
            existing = db.scalar(select(Voucher).where(Voucher.voucher_no == number))
            if existing:
                voucher_map[row["id"]] = existing.id
                continue
            voucher = Voucher(
                voucher_no=number,
                voucher_date=parse_date(row.get("voucher_date")),
                voucher_type=row.get("voucher_type") or "Journal",
                party=row.get("party") or "",
                narration=row.get("narration") or "",
                status=row.get("status") or "Posted",
                source_module="V7 Migration",
                source_reference=number,
                created_by=row.get("created_by") or "Migration",
                posted_by="Migration",
                posted_at=datetime.utcnow(),
            )
            db.add(voucher)
            db.flush()
            voucher_map[row["id"]] = voucher.id

        for row in _row_dicts(src, "voucher_lines"):
            voucher_id = voucher_map.get(row.get("voucher_id"))
            if not voucher_id:
                continue
            name = (row.get("account") or "").strip()
            account = account_by_name.get(name)
            if not account:
                next_code_no += 1
                account = Account(code=str(next_code_no), name=name or f"Migrated Account {next_code_no}", type="Asset", statement="Balance Sheet", active=True)
                db.add(account)
                db.flush()
                account_by_name[account.name] = account
            db.add(VoucherLine(
                voucher_id=voucher_id,
                account_id=account.id,
                debit=float(row.get("debit") or 0),
                credit=float(row.get("credit") or 0),
                party="",
                plot_no="",
                memo="Migrated from V7",
            ))

        return {
            "migrated": True,
            "customers": len(customer_map),
            "plots": len(plot_map),
            "bookings": len(booking_map),
            "receipts": len(receipt_map),
            "vouchers": len(voucher_map),
        }
    finally:
        src.close()


def seed_users(db):
    users = [
        ("admin", "System Administrator", "Admin", DEFAULT_ADMIN_PASSWORD, None),
        ("finance", "Finance Manager", "Finance", "Finance@123", None),
        ("sales", "Sales Manager", "Sales", "Sales@123", None),
        ("crm", "CRM Officer", "CRM", "CRM@123", None),
        ("site", "Development Manager", "Development", "Site@123", None),
    ]
    first_customer = db.scalar(select(Customer).order_by(Customer.id))
    if first_customer:
        users.append(("customer", first_customer.name, "Customer", "Customer@123", first_customer.id))
    for username, full_name, role, password, customer_id in users:
        if not db.scalar(select(User).where(User.username == username)):
            db.add(User(username=username, full_name=full_name, role=role, password_hash=hash_password(password), customer_id=customer_id, active=True))


def seed_development(db):
    if db.scalar(select(func.count()).select_from(DevelopmentProject)):
        return
    db.add_all([
        DevelopmentProject(code="DEV-001", name="Main Boulevard & Internal Roads", category="Roads", budget=45_000_000, committed_cost=18_000_000, actual_cost=12_500_000, progress_percent=32, status="In Progress", remarks="Sub-base and drainage coordination"),
        DevelopmentProject(code="DEV-002", name="Sewerage & Storm Water Network", category="Utilities", budget=18_000_000, committed_cost=8_500_000, actual_cost=5_100_000, progress_percent=38, status="In Progress"),
        DevelopmentProject(code="DEV-003", name="Electrification", category="Utilities", budget=22_000_000, committed_cost=0, actual_cost=0, progress_percent=5, status="Planned"),
        DevelopmentProject(code="DEV-004", name="Horticulture & Green Belts", category="Landscape", budget=7_500_000, committed_cost=1_800_000, actual_cost=750_000, progress_percent=18, status="In Progress"),
    ])



def seed_operations(db):
    if not db.scalar(select(func.count()).select_from(Party)):
        imported = False
        if SOURCE_DB.exists():
            src = sqlite3.connect(SOURCE_DB); src.row_factory = sqlite3.Row
            try:
                for row in _row_dicts(src, "parties"):
                    db.add(Party(
                        code=row.get("party_code") or f"PTY-{row['id']:05d}",
                        name=row.get("party_name") or f"Party {row['id']}",
                        party_type=row.get("party_type") or "Vendor",
                        mobile=row.get("mobile") or "",
                        opening_balance=float(row.get("opening_balance") or 0),
                        balance_side="Debit" if str(row.get("dr_cr") or "").lower().startswith("d") else "Credit",
                        active=bool(row.get("active", 1)),
                        remarks=row.get("remarks") or "",
                    ))
                    imported = True
            finally:
                src.close()
        if not imported:
            db.add_all([
                Party(code="DIR-SALMAN", name="Salman Waheed", party_type="Director", active=True),
                Party(code="DIR-HUMAYUN", name="Humayun Munir Khan", party_type="Director", active=True),
            ])
    if not db.scalar(select(func.count()).select_from(Employee)):
        db.add_all([
            Employee(employee_no="EMP-001", name="Accounts Officer", department="Finance", designation="Accountant", salary=35000, status="Active"),
            Employee(employee_no="EMP-002", name="Site Engineer", department="Development", designation="Civil Site Engineer", salary=35000, status="Active"),
            Employee(employee_no="EMP-003", name="Data Entry Officer", department="Administration", designation="Data Entry Operator", salary=35000, status="Active"),
        ])
    if not db.scalar(select(func.count()).select_from(ComplianceItem)):
        db.add_all([
            ComplianceItem(reference_no="RUDA-PENALTY-2026", authority="RUDA", subject="Penalty and compliance record", status="Closed", responsible_person="Management", remarks="Maintain pay order and correspondence in document register."),
            ComplianceItem(reference_no="RUDA-SCRUTINY", authority="RUDA", subject="Project scrutiny and technical approvals", status="In Progress", responsible_person="Compliance Focal Person"),
            ComplianceItem(reference_no="RUDA-HORTICULTURE", authority="RUDA", subject="Horticulture work permission", status="Open", responsible_person="Development Manager"),
        ])

def seed_settings(db):
    defaults = {
        "company_name": "Crescent Horizon Developers (Pvt.) Limited",
        "project_name": "Horizon Homes",
        "currency": "PKR",
        "residential_rate_per_marla": "1650000",
        "commercial_default_price": "9050000",
        "dealer_commission_percent": "2",
        "director_commission_percent": "0.5",
        "whatsapp_enabled": "0",
        "whatsapp_api_version": "v23.0",
        "whatsapp_phone_number_id": "",
        "whatsapp_access_token": "",
        "whatsapp_default_country_code": "92",
        "whatsapp_language_code": "en_US",
        "whatsapp_booking_template": "horizon_booking_confirmation",
        "whatsapp_due_template": "horizon_payment_due",
        "whatsapp_auto_booking": "0",
        "biometric_transfer_mode": "Both Parties",
    }
    for key, value in defaults.items():
        if not db.get(Setting, key):
            db.add(Setting(key=key, value=value))


def initialize_database():
    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        ensure_default_accounts(db)
        customer_count = db.scalar(select(func.count()).select_from(Customer)) or 0
        migration = migrate_v7(db) if customer_count == 0 else {"migrated": False, "reason": "Database already initialized"}
        seed_users(db)
        seed_development(db)
        seed_operations(db)
        seed_settings(db)
        seed_project_profile(db)
        seed_default_payment_plan(db)
        ensure_director_account_cleanup(db)
        if not db.scalar(select(Notification).where(Notification.title == "Welcome to Horizon ERP V10")):
            db.add(Notification(role="Admin", title="Welcome to Horizon ERP V10", message="Review users, change default passwords, and verify migrated balances before production use.", link="#settings"))
        db.commit()
        return migration
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
