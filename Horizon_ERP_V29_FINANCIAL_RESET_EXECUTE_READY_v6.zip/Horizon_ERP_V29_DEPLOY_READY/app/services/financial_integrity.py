from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import (
    Account, Booking, Commission, MigrationBatch, MigrationRow, Payroll, Receipt, Reservation, Voucher, VoucherLine,
)
from .accounting import balance_sheet, profit_loss, reverse_voucher, trial_balance
from .common import audit


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _voucher_lines_payload(db: Session, voucher_id: int) -> list[dict]:
    rows = db.execute(
        select(VoucherLine, Account.name)
        .join(Account, Account.id == VoucherLine.account_id)
        .where(VoucherLine.voucher_id == voucher_id)
        .order_by(Account.name, VoucherLine.debit, VoucherLine.credit, VoucherLine.id)
    ).all()
    return [
        {
            "account": _norm(name),
            "debit": round(float(line.debit or 0), 2),
            "credit": round(float(line.credit or 0), 2),
            "party": _norm(line.party),
            "plot_no": _norm(line.plot_no),
            "memo": _norm(line.memo),
        }
        for line, name in rows
    ]


def voucher_signature(db: Session, voucher: Voucher) -> str:
    """Conservative exact-duplicate fingerprint.

    It intentionally includes date, voucher type, party, narration and every account line.
    Different narrations or plot/party references are *not* auto-classified as duplicates.
    """
    payload = {
        "date": voucher.voucher_date.isoformat() if voucher.voucher_date else "",
        "type": _norm(voucher.voucher_type),
        "party": _norm(voucher.party),
        "narration": _norm(voucher.narration),
        "lines": _voucher_lines_payload(db, voucher.id),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _voucher_amount(db: Session, voucher_id: int) -> float:
    return float(db.scalar(select(func.coalesce(func.sum(VoucherLine.debit), 0)).where(VoucherLine.voucher_id == voucher_id)) or 0)


def _linked_source(db: Session, voucher_id: int) -> tuple[str, str] | None:
    voucher = db.get(Voucher, voucher_id)
    booking = db.scalar(select(Booking).where(Booking.posted_voucher_id == voucher_id))
    if booking:
        return ("Booking", booking.booking_no)
    receipt = db.scalar(select(Receipt).where(Receipt.posted_voucher_id == voucher_id))
    if receipt:
        return ("Receipt", receipt.receipt_no)
    payroll = db.scalar(select(Payroll).where(Payroll.paid_voucher_id == voucher_id))
    if payroll:
        return ("Payroll", f"{payroll.payroll_month} / record {payroll.id}")
    commission = db.scalar(select(Commission).where(Commission.posted_voucher_id == voucher_id))
    if commission:
        return ("Commission", commission.commission_no)
    # Some historical/source-created records do not carry a direct FK to the voucher.
    # Protect them by source module/reference as well so financial reversal cannot silently
    # leave operational balances unchanged.
    if voucher:
        ref = str(voucher.source_reference or "").strip()
        module = str(voucher.source_module or "").strip()
        if module in {"Booking", "Sale Amendment"} and ref:
            b = db.scalar(select(Booking).where(Booking.booking_no == ref))
            if b:
                return (module, ref)
        if module == "Receipt" and ref:
            r = db.scalar(select(Receipt).where(Receipt.receipt_no == ref))
            if r:
                return ("Receipt", ref)
        if module == "Reservation Conversion" and ref:
            r = db.scalar(select(Reservation).where(Reservation.reservation_no == ref))
            if r:
                return ("Reservation", ref)
        if module == "Commission" and ref:
            c = db.scalar(select(Commission).where(Commission.commission_no == ref))
            if c:
                return ("Commission", ref)
    return None


def duplicate_groups(db: Session) -> list[dict]:
    vouchers = db.scalars(
        select(Voucher)
        .where(Voucher.status == "Posted")
        .order_by(Voucher.voucher_date, Voucher.id)
    ).all()
    buckets: dict[str, list[Voucher]] = defaultdict(list)
    for voucher in vouchers:
        # Reversal vouchers are corrections, not duplicate candidates.
        if voucher.source_module == "Voucher Reversal":
            continue
        buckets[voucher_signature(db, voucher)].append(voucher)

    result: list[dict] = []
    for signature, group in buckets.items():
        if len(group) < 2:
            continue
        keep = group[0]
        rows = []
        for voucher in group:
            linked = _linked_source(db, voucher.id)
            rows.append({
                "id": voucher.id,
                "voucher_no": voucher.voucher_no,
                "voucher_date": voucher.voucher_date.isoformat(),
                "voucher_type": voucher.voucher_type,
                "party": voucher.party,
                "narration": voucher.narration,
                "amount": _voucher_amount(db, voucher.id),
                "source_module": voucher.source_module,
                "source_reference": voucher.source_reference,
                "linked_source": linked[0] if linked else "",
                "linked_reference": linked[1] if linked else "",
                "recommended_keep": voucher.id == keep.id,
                "can_auto_reverse": (not linked) and voucher.id != keep.id,
            })
        result.append({
            "signature": signature,
            "count": len(group),
            "amount_each": _voucher_amount(db, keep.id),
            "recommended_keep_id": keep.id,
            "recommended_keep_no": keep.voucher_no,
            "items": rows,
        })
    result.sort(key=lambda g: (-g["count"], g["recommended_keep_no"]))
    return result


def financial_integrity_summary(db: Session) -> dict:
    tb = trial_balance(db)
    pl = profit_loss(db)
    bs = balance_sheet(db)
    groups = duplicate_groups(db)
    duplicate_rows = sum(max(0, g["count"] - 1) for g in groups)
    duplicate_value = sum(float(g["amount_each"]) * max(0, g["count"] - 1) for g in groups)
    return {
        "trial_balance_debit": round(sum(float(x["debit"]) for x in tb), 2),
        "trial_balance_credit": round(sum(float(x["credit"]) for x in tb), 2),
        "trial_balance_difference": round(sum(float(x["debit"]) - float(x["credit"]) for x in tb), 2),
        "income": round(float(pl["total_income"]), 2),
        "expense": round(float(pl["total_expense"]), 2),
        "net_profit": round(float(pl["net_profit"]), 2),
        "assets": round(float(bs["totals"]["Asset"]), 2),
        "liabilities": round(float(bs["totals"]["Liability"]), 2),
        "equity": round(float(bs["totals"]["Equity"]), 2),
        "balance_sheet_difference": round(float(bs["totals"]["Difference"]), 2),
        "duplicate_groups": len(groups),
        "duplicate_rows": duplicate_rows,
        "duplicate_value": round(duplicate_value, 2),
        "status": "OK" if abs(sum(float(x["debit"]) - float(x["credit"]) for x in tb)) < 0.01 and abs(float(bs["totals"]["Difference"])) < 0.01 else "REVIEW",
    }


def _refresh_migration_batches(db: Session, rows: list[MigrationRow]) -> None:
    batch_ids = {row.batch_id for row in rows if row.batch_id}
    for batch_id in batch_ids:
        batch = db.get(MigrationBatch, batch_id)
        if not batch:
            continue
        all_rows = db.scalars(select(MigrationRow).where(MigrationRow.batch_id == batch_id)).all()
        batch.matched_count = sum(r.reconciliation_status == "Matched" for r in all_rows)
        batch.duplicate_count = sum(r.reconciliation_status == "Duplicate in ERP" for r in all_rows)
        batch.mismatch_count = sum(r.reconciliation_status not in {"Matched", "Duplicate in ERP"} for r in all_rows)
        batch.imported_count = sum(bool(r.posted) for r in all_rows)
        batch.skipped_count = batch.matched_count
        batch.status = "Completed" if batch.mismatch_count == 0 and batch.duplicate_count == 0 else "Requires Review"


def reverse_duplicate_voucher(
    db: Session,
    *,
    keep_voucher_id: int,
    duplicate_voucher_id: int,
    reason: str,
    user_name: str,
    ip_address: str = "",
) -> Voucher:
    if keep_voucher_id == duplicate_voucher_id:
        raise ValueError("The voucher to keep and voucher to remove cannot be the same")
    keep = db.get(Voucher, keep_voucher_id)
    duplicate = db.get(Voucher, duplicate_voucher_id)
    if not keep or not duplicate:
        raise ValueError("Voucher not found")
    if keep.status != "Posted" or duplicate.status != "Posted":
        raise ValueError("Both vouchers must currently be Posted")
    if voucher_signature(db, keep) != voucher_signature(db, duplicate):
        raise ValueError("These vouchers are not exact duplicates. Use normal reversal/repost review instead of duplicate removal.")
    linked = _linked_source(db, duplicate.id)
    if linked:
        raise ValueError(
            f"{duplicate.voucher_no} is linked to {linked[0]} {linked[1]}. "
            "It cannot be removed from the duplicate screen because that would leave operational data inconsistent. "
            "Correct/cancel the source transaction first; the ERP will then reverse its accounting safely."
        )
    reversal = reverse_voucher(
        db, duplicate.id,
        f"Exact duplicate of {keep.voucher_no}. {reason}".strip(),
        user_name, ip_address,
    )
    # Re-open any migration row linked to the removed duplicate so reconciliation reflects the correction.
    migration_rows = db.scalars(select(MigrationRow).where(MigrationRow.erp_voucher_id == duplicate.id)).all()
    for row in migration_rows:
        row.reconciliation_status = "Requires Review"
        row.mismatch_details = f"ERP voucher {duplicate.voucher_no} reversed as duplicate of {keep.voucher_no}"
        row.posted = False
        row.erp_voucher_id = None
    _refresh_migration_batches(db, migration_rows)
    audit(db, user_name, "REMOVE_DUPLICATE_FINANCIAL_ENTRY", "Finance Integrity", duplicate.id, {
        "keep_voucher": keep.voucher_no,
        "duplicate_voucher": duplicate.voucher_no,
        "reversal_voucher": reversal.voucher_no,
        "reason": reason,
    }, ip_address)
    return reversal


def remove_or_reverse_voucher(db: Session, voucher_id: int, reason: str, user_name: str, ip_address: str = "") -> dict:
    voucher = db.get(Voucher, voucher_id)
    if not voucher:
        raise ValueError("Voucher not found")
    if voucher.status == "Draft":
        lines = db.scalars(select(VoucherLine).where(VoucherLine.voucher_id == voucher.id)).all()
        audit(db, user_name, "DELETE_DRAFT_VOUCHER", "Finance Integrity", voucher.id, {
            "voucher_no": voucher.voucher_no, "reason": reason, "line_count": len(lines)
        }, ip_address)
        for line in lines:
            db.delete(line)
        db.delete(voucher)
        return {"action": "deleted_draft", "voucher_no": voucher.voucher_no}
    if voucher.status == "Reversed":
        raise ValueError("Voucher is already reversed")
    if voucher.status != "Posted":
        raise ValueError(f"Unsupported voucher status: {voucher.status}")
    linked = _linked_source(db, voucher.id)
    if linked:
        raise ValueError(
            f"{voucher.voucher_no} is linked to {linked[0]} {linked[1]}. "
            "Direct financial deletion is blocked to protect plot/customer/payroll/commission totals. "
            "Correct or cancel the source transaction instead."
        )
    reversal = reverse_voucher(db, voucher.id, reason, user_name, ip_address)
    migration_rows = db.scalars(select(MigrationRow).where(MigrationRow.erp_voucher_id == voucher.id)).all()
    for row in migration_rows:
        row.reconciliation_status = "Requires Review"
        row.mismatch_details = f"ERP voucher {voucher.voucher_no} reversed/removed: {reason}"
        row.posted = False
        row.erp_voucher_id = None
    _refresh_migration_batches(db, migration_rows)
    return {"action": "reversed", "voucher_no": voucher.voucher_no, "reversal_voucher_no": reversal.voucher_no}
