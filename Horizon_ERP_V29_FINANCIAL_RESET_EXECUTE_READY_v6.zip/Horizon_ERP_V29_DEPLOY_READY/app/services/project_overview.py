from __future__ import annotations

import json
import math
import zipfile
from io import BytesIO
import xml.etree.ElementTree as ET

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import ProjectProfile

EARTH_RADIUS_M = 6378137.0
SQM_PER_SQFT = 0.09290304


def normalize_coordinates(coords):
    cleaned = []
    for item in coords or []:
        if isinstance(item, dict):
            lon, lat = item.get("lon"), item.get("lat")
        else:
            lon, lat = item[0], item[1]
        lon, lat = float(lon), float(lat)
        if not (-180 <= lon <= 180 and -90 <= lat <= 90):
            raise ValueError("Boundary coordinates contain an invalid longitude or latitude")
        point = [round(lon, 12), round(lat, 12)]
        if not cleaned or point != cleaned[-1]:
            cleaned.append(point)
    if len(cleaned) > 1 and cleaned[0] == cleaned[-1]:
        cleaned.pop()
    if len(cleaned) < 3:
        raise ValueError("At least three boundary points are required")
    return cleaned


def polygon_area_sqm(coords):
    points = normalize_coordinates(coords)
    lat0 = math.radians(sum(p[1] for p in points) / len(points))
    lon0 = math.radians(sum(p[0] for p in points) / len(points))
    projected = []
    for lon, lat in points:
        lon_r, lat_r = math.radians(lon), math.radians(lat)
        x = EARTH_RADIUS_M * (lon_r - lon0) * math.cos(lat0)
        y = EARTH_RADIUS_M * (lat_r - lat0)
        projected.append((x, y))
    area2 = 0.0
    for i, (x1, y1) in enumerate(projected):
        x2, y2 = projected[(i + 1) % len(projected)]
        area2 += x1 * y2 - x2 * y1
    return abs(area2) / 2.0


def area_metrics(coords, marla_sqft=225.0):
    sqm = polygon_area_sqm(coords)
    sqm_per_marla = float(marla_sqft) * SQM_PER_SQFT
    marla = sqm / sqm_per_marla if sqm_per_marla else 0.0
    return {"sqm": sqm, "marla": marla, "kanal": marla / 20.0}


def parse_kmz_bytes(raw: bytes):
    try:
        with zipfile.ZipFile(BytesIO(raw)) as zf:
            kml_name = next((n for n in zf.namelist() if n.lower().endswith(".kml")), None)
            if not kml_name:
                raise ValueError("KMZ does not contain a KML file")
            root = ET.fromstring(zf.read(kml_name))
    except zipfile.BadZipFile as exc:
        raise ValueError("The uploaded file is not a valid KMZ archive") from exc
    ns = {"kml": "http://www.opengis.net/kml/2.2"}
    coordinate_nodes = root.findall(".//kml:Polygon//kml:outerBoundaryIs//kml:LinearRing//kml:coordinates", ns)
    if not coordinate_nodes:
        raise ValueError("No polygon boundary was found in the KMZ file")
    best = []
    for node in coordinate_nodes:
        points = []
        for token in (node.text or "").replace("\n", " ").split():
            parts = token.split(",")
            if len(parts) >= 2:
                try:
                    points.append([float(parts[0]), float(parts[1])])
                except ValueError:
                    pass
        if len(points) > len(best):
            best = points
    return normalize_coordinates(best)


def seed_project_profile(db: Session):
    existing = db.scalar(select(ProjectProfile).where(ProjectProfile.code == "HH-001"))
    if existing:
        return existing
    original_coords = [
        [74.43901960377436, 31.6006932308241],
        [74.43930466048469, 31.59970090595058],
        [74.44027454741972, 31.59990423392809],
        [74.44069617743162, 31.59992033368644],
        [74.44057997353278, 31.60017001233573],
        [74.4402957753351, 31.60016181304518],
        [74.44030021160773, 31.60055997945447],
        [74.44023230196626, 31.60056372316424],
        [74.44023089206351, 31.60064181828215],
        [74.44022987363411, 31.60072878757325],
    ]
    metrics = area_metrics(original_coords, 225)
    landowners = [
        "Ghulam Mesam", "Ghulam Aqeel", "Ghulam Imran", "Kaneez Rubab", "Ghulam Sakina", "Ghulam Fiza"
    ]
    project = ProjectProfile(
        code="HH-001",
        name="Horizon Homes",
        developer="Crescent Horizon Developers (Pvt.) Limited",
        status="Active",
        mouza="Hando / Hando Gujar",
        deed_location="Mouza Hando, Tehsil Cantt., District Lahore",
        layout_location="Mouza Hando Gujar, Theri Road near G.T. Road, Munawan, Tehsil Shalamar, District Lahore",
        khasra_numbers="1076, 1077, 1079, 1091, 1092, 1093, 1094, 1095",
        khewat_numbers="61, 64, 65",
        khatooni_numbers="106, 111, 112",
        landowners_json=json.dumps(landowners),
        legal_area_marla=566.0,
        layout_area_marla=566.0,
        official_area_marla=566.0,
        marla_sqft=225.0,
        kmz_area_sqm=metrics["sqm"],
        kmz_area_marla=metrics["marla"],
        residential_area_marla=16.27 * 20,
        commercial_area_marla=0.55 * 20,
        public_building_area_marla=1.37 * 20,
        roads_parking_area_marla=10.11 * 20,
        land_rate_per_marla=725000,
        land_consideration=410350000,
        landowner_profit_share=40.0,
        developer_profit_share=60.0,
        original_boundary_json=json.dumps(original_coords),
        boundary_json=json.dumps(original_coords),
        source_kmz_name="horizon_homes_28_30k.kmz",
        notes=(
            "Legal area and land consideration are sourced from the March 2026 deed. "
            "Planning land-use areas are sourced from the FINAL SUBMISSION layout. "
            "KMZ area is calculated from the polygon coordinates using the layout plan's 225 sq ft marla standard."
        ),
    )
    db.add(project)
    db.flush()
    return project
