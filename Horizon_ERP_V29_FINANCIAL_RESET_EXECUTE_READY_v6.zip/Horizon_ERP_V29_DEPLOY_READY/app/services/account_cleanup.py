from __future__ import annotations

import json
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Account, AccountAlias, VoucherLine
from .common import audit

DIRECTOR_ALIAS_MAP = {
    "Humayun Director Current A/C": "Director Current Account - Humayun",
    "DIRECTOR CURRENT ACCOUNT- HUMAYUN": "Director Current Account - Humayun",
    "Director Current A/C - Humayun": "Director Current Account - Humayun",
    "Salman Director Current A/C": "Director Current Account - Salman",
    "DIRECTOR CURRENT ACCOUNT- SALMAN": "Director Current Account - Salman",
    "Director Current A/C - Salman": "Director Current Account - Salman",
}


def merge_account(
    db: Session,
    alias: Account,
    master: Account,
    user_name: str = "System",
    reason: str = "Duplicate account consolidation",
    ip_address: str = "",
) -> dict:
    if alias.id == master.id:
        raise ValueError("Alias and master account cannot be the same")
    if alias.type != master.type:
        raise ValueError("Alias and master account must have the same account type")

    existing = db.scalar(select(AccountAlias).where(AccountAlias.alias_account_id == alias.id))
    if existing and existing.active:
        return {"ok": True, "already_mapped": True, "mapping_id": existing.id, "moved_lines": len(json.loads(existing.moved_line_ids or "[]"))}

    lines = db.scalars(select(VoucherLine).where(VoucherLine.account_id == alias.id)).all()
    moved_ids = [line.id for line in lines]
    for line in lines:
        line.account_id = master.id

    alias.active = False
    if existing:
        existing.master_account_id = master.id
        existing.original_name = alias.name
        existing.reason = reason
        existing.moved_line_ids = json.dumps(moved_ids)
        existing.mapped_by = user_name
        existing.mapped_at = datetime.utcnow()
        existing.active = True
        mapping = existing
    else:
        mapping = AccountAlias(
            alias_account_id=alias.id,
            master_account_id=master.id,
            original_name=alias.name,
            reason=reason,
            moved_line_ids=json.dumps(moved_ids),
            mapped_by=user_name,
            active=True,
        )
        db.add(mapping)
        db.flush()

    audit(
        db,
        user_name,
        "ACCOUNT_MERGE",
        "Chart of Accounts",
        master.id,
        {
            "alias_account_id": alias.id,
            "alias_name": alias.name,
            "master_account_id": master.id,
            "master_name": master.name,
            "moved_voucher_lines": len(moved_ids),
            "reason": reason,
        },
        ip_address,
    )
    return {"ok": True, "mapping_id": mapping.id, "moved_lines": len(moved_ids)}


def restore_account_mapping(db: Session, mapping: AccountAlias, user_name: str, ip_address: str = "") -> dict:
    if not mapping.active:
        raise ValueError("Mapping is already inactive")
    alias = db.get(Account, mapping.alias_account_id)
    master = db.get(Account, mapping.master_account_id)
    if not alias or not master:
        raise ValueError("Mapped account no longer exists")
    ids = json.loads(mapping.moved_line_ids or "[]")
    restored = 0
    if ids:
        lines = db.scalars(select(VoucherLine).where(VoucherLine.id.in_(ids))).all()
        for line in lines:
            if line.account_id == master.id:
                line.account_id = alias.id
                restored += 1
    alias.active = True
    mapping.active = False
    audit(
        db,
        user_name,
        "ACCOUNT_MERGE_RESTORE",
        "Chart of Accounts",
        alias.id,
        {"alias": alias.name, "master": master.name, "restored_voucher_lines": restored},
        ip_address,
    )
    return {"ok": True, "restored_lines": restored}


def ensure_director_account_cleanup(db: Session) -> list[dict]:
    """Permanently consolidate obsolete director-current account names.

    Voucher history is retained by moving every voucher line to the standardized
    Director Current Account. The obsolete account record itself is deleted so it
    cannot appear in account selectors, ledgers or reports. Cash Held, Director
    Receivable and Loan Payable accounts are intentionally excluded.
    """
    results = []
    for alias_name, master_name in DIRECTOR_ALIAS_MAP.items():
        alias = db.scalar(select(Account).where(Account.name == alias_name))
        master = db.scalar(select(Account).where(Account.name == master_name))
        if not alias or not master or alias.id == master.id:
            continue

        lines = db.scalars(select(VoucherLine).where(VoucherLine.account_id == alias.id)).all()
        moved_ids = [line.id for line in lines]
        for line in lines:
            line.account_id = master.id

        # Remove any old reversible alias mapping: these names are permanently retired.
        mappings = db.scalars(select(AccountAlias).where(AccountAlias.alias_account_id == alias.id)).all()
        for mapping in mappings:
            db.delete(mapping)

        alias_id = alias.id
        db.delete(alias)
        audit(
            db,
            "System Migration V28",
            "ACCOUNT_PERMANENT_CONSOLIDATION",
            "Chart of Accounts",
            master.id,
            {
                "deleted_duplicate_account_id": alias_id,
                "deleted_duplicate_account": alias_name,
                "master_account_id": master.id,
                "master_account": master_name,
                "moved_voucher_lines": len(moved_ids),
                "reason": "Permanent director-current account standardization requested by management.",
            },
        )
        results.append({"alias": alias_name, "master": master_name, "moved_lines": len(moved_ids), "deleted": True})
    return results
