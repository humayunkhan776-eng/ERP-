from __future__ import annotations

from calendar import monthrange
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import (
    Booking, BookingPaymentPlan, Customer, Installment, PaymentAllocation, PaymentPlanTemplate, Plot, PlotStatusHistory,
    Receipt, Reservation, Voucher
)
from .accounting import create_voucher
from .common import as_float, audit, next_number, to_date


def add_months(source: date, months: int) -> date:
    month = source.month - 1 + months
    year = source.year + month // 12
    month = month % 12 + 1
    return date(year, month, min(source.day, monthrange(year, month)[1]))


def change_plot_status(db: Session, plot: Plot, new_status: str, user_name: str, remarks: str = "") -> None:
    old = plot.status
    if old == new_status:
        return
    plot.status = new_status
    plot.version += 1
    db.add(PlotStatusHistory(plot_id=plot.id, old_status=old, new_status=new_status, changed_by=user_name, remarks=remarks))


def reserve_plot(db: Session, payload: dict, user_name: str, ip_address: str = "") -> Reservation:
    plot = db.get(Plot, int(payload["plot_id"]))
    customer = db.get(Customer, int(payload["customer_id"]))
    if not plot or not customer:
        raise ValueError("Plot or customer not found")
    if plot.status not in {"Available", "Released"}:
        raise ValueError(f"Plot {plot.plot_no} is currently {plot.status} and cannot be reserved")
    amount = round(as_float(payload.get("amount")), 2)
    if amount < 0:
        raise ValueError("Reservation amount cannot be negative")
    reservation = Reservation(
        reservation_no=next_number(db, Reservation, Reservation.reservation_no, "RSV"),
        reservation_date=to_date(payload.get("reservation_date") or date.today(), "reservation_date"),
        expiry_date=to_date(payload["expiry_date"], "expiry_date") if payload.get("expiry_date") else None,
        plot_id=plot.id,
        customer_id=customer.id,
        amount=amount,
        refundable=bool(payload.get("refundable", True)),
        payment_mode=str(payload.get("payment_mode") or "Cash"),
        reference=str(payload.get("reference") or ""),
        dealer_name=str(payload.get("dealer_name") or ""),
        status="Active",
        remarks=str(payload.get("remarks") or ""),
    )
    db.add(reservation)
    db.flush()
    plot.customer_id = customer.id
    change_plot_status(db, plot, "Reserved", user_name, f"Reservation {reservation.reservation_no}")
    if amount > 0:
        cash_account = "Bank Account" if reservation.payment_mode.lower() in {"bank", "cheque", "online", "transfer"} else "Cash in Hand"
        create_voucher(
            db,
            voucher_date=reservation.reservation_date,
            voucher_type="Receipt",
            party=customer.name,
            narration=f"Refundable reservation deposit received for Plot {plot.plot_no}",
            lines=[
                {"account": cash_account, "debit": amount, "credit": 0, "party": customer.name, "plot_no": plot.plot_no},
                {"account": "Customer Reservation Deposits", "debit": 0, "credit": amount, "party": customer.name, "plot_no": plot.plot_no},
            ],
            user_name=user_name,
            source_module="Reservation",
            source_reference=reservation.reservation_no,
            status="Posted",
            ip_address=ip_address,
        )
    audit(db, user_name, "RESERVE_PLOT", "Plot Management", reservation.id, {"plot": plot.plot_no, "customer": customer.name, "amount": amount}, ip_address)
    return reservation


def release_reservation(db: Session, reservation_id: int, reason: str, user_name: str, ip_address: str = "") -> Reservation:
    reservation = db.get(Reservation, reservation_id)
    if not reservation or reservation.status != "Active":
        raise ValueError("Active reservation not found")
    plot = db.get(Plot, reservation.plot_id)
    customer = db.get(Customer, reservation.customer_id)
    amount = float(reservation.amount or 0)
    if amount > 0:
        cash_account = "Bank Account" if reservation.payment_mode.lower() in {"bank", "cheque", "online", "transfer"} else "Cash in Hand"
        create_voucher(
            db,
            voucher_date=date.today(),
            voucher_type="Payment",
            party=customer.name if customer else "",
            narration=f"Refund of reservation deposit {reservation.reservation_no}: {reason}",
            lines=[
                {"account": "Customer Reservation Deposits", "debit": amount, "credit": 0, "party": customer.name if customer else "", "plot_no": plot.plot_no},
                {"account": cash_account, "debit": 0, "credit": amount, "party": customer.name if customer else "", "plot_no": plot.plot_no},
            ],
            user_name=user_name,
            source_module="Reservation Refund",
            source_reference=reservation.reservation_no,
            status="Posted",
            ip_address=ip_address,
        )
    reservation.status = "Released"
    reservation.remarks = (reservation.remarks + "\n" if reservation.remarks else "") + f"Released: {reason}"
    plot.customer_id = None
    change_plot_status(db, plot, "Available", user_name, f"Reservation released: {reason}")
    audit(db, user_name, "RELEASE_RESERVATION", "Plot Management", reservation.id, reason, ip_address)
    return reservation


def generate_installment_schedule(db: Session, booking: Booking, start_date: date) -> None:
    existing_ids = db.scalars(select(Installment.id).where(Installment.booking_id == booking.id)).all()
    if existing_ids:
        db.query(PaymentAllocation).filter(PaymentAllocation.installment_id.in_(existing_ids)).delete(synchronize_session=False)
        db.query(Installment).filter(Installment.id.in_(existing_ids)).delete(synchronize_session=False)
    total = round(float(booking.net_sale_value), 2)
    if booking.payment_plan == "Full Paid":
        db.add(Installment(booking_id=booking.id, due_no=1, due_date=start_date, due_type="Full Payment", amount=total, paid=0, status="Due"))
        return
    if booking.payment_plan == "14-Month Installment" and abs(total - 4_950_000) < 1:
        schedule = [
            (1, start_date, "Down Payment", 650_000),
            (2, add_months(start_date, 1), "Confirmation", 650_000),
        ]
        for i in range(14):
            schedule.append((3 + i, add_months(start_date, 2 + i), "Monthly Installment", 117_857.14))
        schedule.extend([
            (17, add_months(start_date, 6), "Bulk Payment 1", 500_000),
            (18, add_months(start_date, 11), "Bulk Payment 2", 500_000),
            (19, add_months(start_date, 16), "Possession", 1_000_000),
        ])
        # Correct rounding in final monthly installment.
        scheduled = sum(x[3] for x in schedule)
        diff = round(total - scheduled, 2)
        if diff:
            number, due_date, due_type, amount = schedule[15]
            schedule[15] = (number, due_date, due_type, round(amount + diff, 2))
    else:
        # Generic 14-month schedule: 20% down payment and equal monthly balance.
        down = round(total * 0.20, 2)
        balance = total - down
        monthly = round(balance / 14, 2)
        schedule = [(1, start_date, "Down Payment", down)]
        for i in range(14):
            amount = monthly if i < 13 else round(balance - monthly * 13, 2)
            schedule.append((2 + i, add_months(start_date, 1 + i), "Monthly Installment", amount))
    for due_no, due_date, due_type, amount in schedule:
        db.add(Installment(booking_id=booking.id, due_no=due_no, due_date=due_date, due_type=due_type, amount=amount, paid=0, status="Due"))


def create_booking(db: Session, payload: dict, user_name: str, ip_address: str = "") -> Booking:
    plot = db.get(Plot, int(payload["plot_id"]))
    customer = db.get(Customer, int(payload["customer_id"]))
    if not plot or not customer:
        raise ValueError("Plot or customer not found")
    if plot.status not in {"Available", "Reserved"}:
        raise ValueError(f"Plot {plot.plot_no} is currently {plot.status}")
    reservation = None
    if payload.get("reservation_id"):
        reservation = db.get(Reservation, int(payload["reservation_id"]))
        if not reservation or reservation.status != "Active" or reservation.plot_id != plot.id or reservation.customer_id != customer.id:
            raise ValueError("Valid active reservation was not found")
    elif plot.status == "Reserved":
        reservation = db.scalar(select(Reservation).where(Reservation.plot_id == plot.id, Reservation.status == "Active"))
        if not reservation or reservation.customer_id != customer.id:
            raise ValueError("This plot is reserved for another customer")

    sale_price = round(as_float(payload.get("sale_price")), 2)
    discount = round(as_float(payload.get("discount")), 2)
    if sale_price <= 0 or discount < 0 or discount >= sale_price:
        raise ValueError("Enter a valid sale price and discount")
    net = round(sale_price - discount, 2)
    booking = Booking(
        booking_no=next_number(db, Booking, Booking.booking_no, "BKG"),
        booking_date=to_date(payload.get("booking_date") or date.today(), "booking_date"),
        customer_id=customer.id,
        plot_id=plot.id,
        sale_price=sale_price,
        discount=discount,
        net_sale_value=net,
        payment_plan=str(payload.get("payment_plan") or "Full Paid"),
        dealer_name=str(payload.get("dealer_name") or ""),
        status="Posted",
        reservation_id=reservation.id if reservation else None,
    )
    db.add(booking)
    db.flush()
    sales_account = "Commercial Plot Sales" if plot.category.lower() == "commercial" else "Residential Plot Sales"
    voucher = create_voucher(
        db,
        voucher_date=booking.booking_date,
        voucher_type="Journal",
        party=customer.name,
        narration=f"Plot sale booked: Plot {plot.plot_no}, {booking.booking_no}",
        lines=[
            {"account": "Customer Receivable", "debit": net, "credit": 0, "party": customer.name, "plot_no": plot.plot_no},
            {"account": sales_account, "debit": 0, "credit": net, "party": customer.name, "plot_no": plot.plot_no},
        ],
        user_name=user_name,
        source_module="Booking",
        source_reference=booking.booking_no,
        status="Posted",
        ip_address=ip_address,
    )
    booking.posted_voucher_id = voucher.id
    plot.customer_id = customer.id
    plot.sale_price = net
    plot.outstanding = net - float(plot.received or 0)
    plot.payment_status = "Due" if plot.outstanding > 0 else "Paid"
    change_plot_status(db, plot, "Booked", user_name, booking.booking_no)
    if reservation:
        reservation.status = "Converted"
        deposit = float(reservation.amount or 0)
        if deposit > 0:
            create_voucher(
                db,
                voucher_date=booking.booking_date,
                voucher_type="Adjustment",
                party=customer.name,
                narration=f"Reservation deposit adjusted into booking {booking.booking_no}",
                lines=[
                    {"account": "Customer Reservation Deposits", "debit": deposit, "credit": 0, "party": customer.name, "plot_no": plot.plot_no},
                    {"account": "Customer Receivable", "debit": 0, "credit": deposit, "party": customer.name, "plot_no": plot.plot_no},
                ],
                user_name=user_name,
                source_module="Reservation Conversion",
                source_reference=reservation.reservation_no,
                status="Posted",
                ip_address=ip_address,
            )
            plot.received = float(plot.received or 0) + deposit
            plot.outstanding = max(0, net - float(plot.received))
    plan_template_id = int(payload.get("plan_template_id") or 0)
    if plan_template_id:
        from .payment_plans import apply_template_to_booking
        apply_template_to_booking(db, booking, plan_template_id, user_name, ip_address, reapply_receipts=False)
    else:
        generate_installment_schedule(db, booking, booking.booking_date)
    if reservation and float(reservation.amount or 0) > 0:
        allocate_amount(db, booking.id, None, float(reservation.amount))
    audit(db, user_name, "CREATE_BOOKING", "Sales", booking.id, {"plot": plot.plot_no, "customer": customer.name, "net_sale": net}, ip_address)
    return booking


def allocate_amount(db: Session, booking_id: int, receipt_id: int | None, amount: float) -> float:
    remaining = round(amount, 2)
    installments = db.scalars(select(Installment).where(Installment.booking_id == booking_id).order_by(Installment.due_date, Installment.due_no)).all()
    for installment in installments:
        if remaining <= 0:
            break
        due = round(float(installment.amount) - float(installment.paid), 2)
        if due <= 0:
            continue
        applied = min(due, remaining)
        installment.paid = round(float(installment.paid) + applied, 2)
        installment.status = "Paid" if float(installment.paid) >= float(installment.amount) - 0.01 else "Partial"
        if receipt_id:
            db.add(PaymentAllocation(receipt_id=receipt_id, installment_id=installment.id, amount=applied))
        remaining = round(remaining - applied, 2)
    return remaining


def create_receipt(db: Session, payload: dict, user_name: str, ip_address: str = "") -> Receipt:
    booking = db.get(Booking, int(payload["booking_id"]))
    if not booking or booking.status not in {"Posted", "Active"}:
        raise ValueError("Active booking not found")
    customer = db.get(Customer, booking.customer_id)
    plot = db.get(Plot, booking.plot_id)
    amount = round(as_float(payload.get("amount")), 2)
    if amount <= 0:
        raise ValueError("Receipt amount must be greater than zero")
    if amount > float(plot.outstanding or 0) + 0.01:
        raise ValueError("Receipt exceeds the outstanding balance")
    mode = str(payload.get("mode") or "Cash")
    receipt = Receipt(
        receipt_no=next_number(db, Receipt, Receipt.receipt_no, "RCPT"),
        receipt_date=to_date(payload.get("receipt_date") or date.today(), "receipt_date"),
        booking_id=booking.id,
        customer_id=customer.id,
        amount=amount,
        mode=mode,
        reference=str(payload.get("reference") or ""),
        narration=str(payload.get("narration") or f"Receipt against {booking.booking_no}"),
    )
    db.add(receipt)
    db.flush()
    cash_account = "Bank Account" if mode.lower() in {"bank", "cheque", "online", "transfer"} else "Cash in Hand"
    voucher = create_voucher(
        db,
        voucher_date=receipt.receipt_date,
        voucher_type="Receipt",
        party=customer.name,
        narration=f"Payment received against Plot {plot.plot_no}, {booking.booking_no}",
        lines=[
            {"account": cash_account, "debit": amount, "credit": 0, "party": customer.name, "plot_no": plot.plot_no},
            {"account": "Customer Receivable", "debit": 0, "credit": amount, "party": customer.name, "plot_no": plot.plot_no},
        ],
        user_name=user_name,
        source_module="Receipt",
        source_reference=receipt.receipt_no,
        status="Posted",
        ip_address=ip_address,
    )
    receipt.posted_voucher_id = voucher.id
    allocate_amount(db, booking.id, receipt.id, amount)
    plot.received = round(float(plot.received or 0) + amount, 2)
    plot.outstanding = max(0, round(float(plot.sale_price or booking.net_sale_value) - float(plot.received), 2))
    plot.payment_status = "Paid" if plot.outstanding <= 0.01 else "Partial"
    if plot.payment_status == "Paid":
        change_plot_status(db, plot, "Sold", user_name, f"Fully paid through {receipt.receipt_no}")
    audit(db, user_name, "CREATE_RECEIPT", "Collections", receipt.id, {"receipt": receipt.receipt_no, "amount": amount, "plot": plot.plot_no}, ip_address)
    return receipt


def amend_sale_value(db: Session, booking_id: int, new_net_value: float, reason: str, user_name: str, ip_address: str = "") -> Booking:
    booking = db.get(Booking, booking_id)
    if not booking or booking.status not in {"Posted", "Active"}:
        raise ValueError("Active booking not found")
    plot = db.get(Plot, booking.plot_id)
    customer = db.get(Customer, booking.customer_id)
    old = round(float(booking.net_sale_value), 2)
    new = round(as_float(new_net_value), 2)
    if new <= 0 or abs(new - old) < 0.01:
        raise ValueError("New sale value must be positive and different from the current value")
    if new < float(plot.received or 0):
        raise ValueError("New sale value cannot be less than the amount already received")
    delta = round(new - old, 2)
    sales_account = "Commercial Plot Sales" if plot.category.lower() == "commercial" else "Residential Plot Sales"
    if delta > 0:
        lines = [
            {"account": "Customer Receivable", "debit": delta, "credit": 0, "party": customer.name, "plot_no": plot.plot_no},
            {"account": sales_account, "debit": 0, "credit": delta, "party": customer.name, "plot_no": plot.plot_no},
        ]
    else:
        lines = [
            {"account": sales_account, "debit": -delta, "credit": 0, "party": customer.name, "plot_no": plot.plot_no},
            {"account": "Customer Receivable", "debit": 0, "credit": -delta, "party": customer.name, "plot_no": plot.plot_no},
        ]
    create_voucher(
        db,
        voucher_date=date.today(),
        voucher_type="Adjustment",
        party=customer.name,
        narration=f"Sale value amendment for {booking.booking_no}: {reason}",
        lines=lines,
        user_name=user_name,
        source_module="Sale Amendment",
        source_reference=booking.booking_no,
        status="Posted",
        ip_address=ip_address,
    )
    booking.sale_price = new
    booking.discount = 0
    booking.net_sale_value = new
    booking.version += 1
    plot.sale_price = new
    plot.outstanding = round(new - float(plot.received or 0), 2)
    plot.payment_status = "Paid" if plot.outstanding <= 0 else "Partial" if float(plot.received or 0) > 0 else "Due"
    generate_installment_schedule(db, booking, booking.booking_date)
    if float(plot.received or 0) > 0:
        allocate_amount(db, booking.id, None, float(plot.received))
    audit(db, user_name, "AMEND_SALE_VALUE", "Sales", booking.id, {"old": old, "new": new, "reason": reason}, ip_address)
    return booking

def update_booking_details(db: Session, booking_id: int, payload: dict, user_name: str, ip_address: str = "") -> Booking:
    """Audit-safe edit for booking date, dealer and payment plan.

    Customer, plot and posted sale values remain protected. A corrected booking date
    automatically regenerates the payment schedule from the corrected date and reapplies
    the reservation deposit plus all posted receipts in chronological order. The original
    accounting voucher date is intentionally preserved; an accounting-period correction
    must use the Finance reversal/repost workflow.
    """
    booking = db.get(Booking, booking_id)
    if not booking or booking.status not in {"Posted", "Active", "Booked"}:
        raise ValueError("Active posted booking not found")
    expected_version = int(payload.get("version") or booking.version)
    if expected_version != booking.version:
        raise ValueError("Record changed by another user. Refresh and try again.")

    current_assignment = db.scalar(select(BookingPaymentPlan).where(BookingPaymentPlan.booking_id == booking.id))
    current_template_id = current_assignment.template_id if current_assignment else 0
    old = {
        "booking_date": booking.booking_date.isoformat() if booking.booking_date else "",
        "dealer_name": booking.dealer_name or "",
        "payment_plan": booking.payment_plan or "",
        "plan_template_id": current_template_id,
    }

    # Booking-date correction control.
    new_booking_date = to_date(payload.get("booking_date") or booking.booking_date, "booking_date")
    date_changed = new_booking_date != booking.booking_date
    date_change_reason = str(payload.get("date_change_reason") or "").strip()
    if date_changed:
        if not date_change_reason:
            raise ValueError("Enter a reason / approval reference for the booking-date correction")
        if new_booking_date > date.today():
            raise ValueError("Booking date cannot be in the future")
        if booking.reservation_id:
            reservation = db.get(Reservation, booking.reservation_id)
            if reservation and reservation.reservation_date and new_booking_date < reservation.reservation_date:
                raise ValueError(f"Booking date cannot be before reservation date {reservation.reservation_date.isoformat()}")
        earliest_receipt = db.scalar(select(Receipt).where(Receipt.booking_id == booking.id).order_by(Receipt.receipt_date.asc(), Receipt.id.asc()))
        if earliest_receipt and earliest_receipt.receipt_date and new_booking_date > earliest_receipt.receipt_date:
            raise ValueError(f"Booking date cannot be after existing receipt {earliest_receipt.receipt_no} dated {earliest_receipt.receipt_date.isoformat()}")
        booking.booking_date = new_booking_date

    new_dealer = str(payload.get("dealer_name", booking.dealer_name) or "").strip()
    new_plan = str(payload.get("payment_plan", booking.payment_plan) or booking.payment_plan).strip()
    template_id = int(payload.get("plan_template_id") or 0)
    if not template_id and new_plan not in {"Full Paid", "14-Month Installment"}:
        raise ValueError("Choose a built-in plan or an uploaded payment-plan template")

    changed = date_changed
    if new_dealer != (booking.dealer_name or ""):
        booking.dealer_name = new_dealer
        changed = True

    # Payment plan and schedule. A date correction always rebuilds the schedule so
    # confirmation/installment/bulk/possession due dates stay synchronized.
    if template_id:
        if template_id != current_template_id or date_changed:
            from .payment_plans import apply_template_to_booking
            apply_template_to_booking(db, booking, template_id, user_name, ip_address, reapply_receipts=True)
            new_plan = booking.payment_plan
            changed = True
    elif new_plan != booking.payment_plan or current_assignment or date_changed:
        if current_assignment:
            db.delete(current_assignment)
        booking.payment_plan = new_plan
        generate_installment_schedule(db, booking, booking.booking_date)
        db.flush()
        if booking.reservation_id:
            reservation = db.get(Reservation, booking.reservation_id)
            if reservation and float(reservation.amount or 0) > 0:
                allocate_amount(db, booking.id, None, float(reservation.amount))
        receipts = db.scalars(select(Receipt).where(Receipt.booking_id == booking.id).order_by(Receipt.receipt_date, Receipt.id)).all()
        for receipt in receipts:
            allocate_amount(db, booking.id, receipt.id, float(receipt.amount or 0))
        changed = True

    if not changed:
        raise ValueError("No booking detail was changed")

    booking.version += 1
    audit(db, user_name, "EDIT_BOOKING_DETAILS", "Sales", booking.id, {
        "booking_no": booking.booking_no,
        "old": old,
        "new": {
            "booking_date": booking.booking_date.isoformat() if booking.booking_date else "",
            "dealer_name": booking.dealer_name or "",
            "payment_plan": booking.payment_plan or "",
            "plan_template_id": template_id or 0,
        },
        "booking_date_changed": date_changed,
        "date_change_reason": date_change_reason if date_changed else "",
        "schedule_regenerated": bool(date_changed),
        "accounting_voucher_date_changed": False,
        "locked_fields": ["customer", "plot", "sale_price", "discount", "net_sale_value"],
    }, ip_address)
    return booking
