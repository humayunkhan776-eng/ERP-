from __future__ import annotations

from datetime import date
from io import BytesIO, StringIO
import csv

from openpyxl import Workbook, load_workbook
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Booking, BookingPaymentPlan, Installment, PaymentAllocation, PaymentPlanTemplate, PaymentPlanTemplateLine, Receipt, Reservation
from .common import as_float, audit
from .erp import add_months, allocate_amount

VALID_AMOUNT_TYPES = {"Fixed", "Percent", "Balance"}


def template_schedule(db: Session, booking: Booking, template: PaymentPlanTemplate, start_date: date) -> list[tuple[int, date, str, float]]:
    lines = db.scalars(select(PaymentPlanTemplateLine).where(PaymentPlanTemplateLine.template_id == template.id).order_by(PaymentPlanTemplateLine.due_no, PaymentPlanTemplateLine.id)).all()
    if not lines:
        raise ValueError("Selected payment-plan template has no schedule lines")
    total = round(float(booking.net_sale_value or 0), 2)
    if total <= 0:
        raise ValueError("Booking net sale value must be greater than zero")
    balance_lines = [x for x in lines if x.amount_type == "Balance"]
    if len(balance_lines) > 1:
        raise ValueError("A payment plan can contain only one Balance line")
    computed: list[list] = []
    allocated = 0.0
    for line in lines:
        if line.amount_type == "Fixed":
            amount = round(float(line.amount_value or 0), 2)
        elif line.amount_type == "Percent":
            amount = round(total * float(line.amount_value or 0) / 100.0, 2)
        elif line.amount_type == "Balance":
            amount = None
        else:
            raise ValueError(f"Unsupported amount type: {line.amount_type}")
        if amount is not None:
            if amount < 0:
                raise ValueError("Payment-plan line amount cannot be negative")
            allocated = round(allocated + amount, 2)
        computed.append([line.due_no, add_months(start_date, int(line.offset_months or 0)), line.due_type, amount])
    if balance_lines:
        remaining = round(total - allocated, 2)
        if remaining < -0.01:
            raise ValueError(f"Template fixed/percent lines exceed booking value by Rs {abs(remaining):,.2f}")
        for row in computed:
            if row[3] is None:
                row[3] = max(0.0, remaining)
    else:
        difference = round(total - allocated, 2)
        if abs(difference) > 0.01:
            raise ValueError(f"Template schedule totals Rs {allocated:,.2f}, but booking value is Rs {total:,.2f}. Add a Balance line or correct the template.")
        # absorb tiny rounding difference in final line
        if computed and abs(difference) > 0:
            computed[-1][3] = round(float(computed[-1][3] or 0) + difference, 2)
    return [(int(a), b, str(c), round(float(d or 0), 2)) for a,b,c,d in computed]


def apply_template_to_booking(db: Session, booking: Booking, template_id: int, user_name: str, ip_address: str = "", reapply_receipts: bool = True) -> BookingPaymentPlan:
    template = db.get(PaymentPlanTemplate, int(template_id))
    if not template or not template.active:
        raise ValueError("Active payment-plan template not found")
    schedule = template_schedule(db, booking, template, booking.booking_date)
    assignment = db.scalar(select(BookingPaymentPlan).where(BookingPaymentPlan.booking_id == booking.id))
    if assignment:
        assignment.template_id = template.id
        assignment.plan_code_snapshot = template.code
        assignment.plan_name_snapshot = template.name
        assignment.assigned_by = user_name
    else:
        assignment = BookingPaymentPlan(booking_id=booking.id, template_id=template.id, plan_code_snapshot=template.code, plan_name_snapshot=template.name, assigned_by=user_name)
        db.add(assignment)
    booking.payment_plan = template.name
    existing_ids = db.scalars(select(Installment.id).where(Installment.booking_id == booking.id)).all()
    if existing_ids:
        db.query(PaymentAllocation).filter(PaymentAllocation.installment_id.in_(existing_ids)).delete(synchronize_session=False)
        db.query(Installment).filter(Installment.id.in_(existing_ids)).delete(synchronize_session=False)
    db.flush()
    for due_no, due_date, due_type, amount in schedule:
        db.add(Installment(booking_id=booking.id, due_no=due_no, due_date=due_date, due_type=due_type, amount=amount, paid=0, status="Due"))
    db.flush()
    if reapply_receipts:
        if booking.reservation_id:
            reservation = db.get(Reservation, booking.reservation_id)
            if reservation and float(reservation.amount or 0) > 0:
                allocate_amount(db, booking.id, None, float(reservation.amount))
        receipts = db.scalars(select(Receipt).where(Receipt.booking_id == booking.id).order_by(Receipt.receipt_date, Receipt.id)).all()
        for receipt in receipts:
            allocate_amount(db, booking.id, receipt.id, float(receipt.amount or 0))
    audit(db, user_name, "APPLY_PAYMENT_PLAN", "Payment Plans", booking.id, {"booking": booking.booking_no, "plan_code": template.code, "plan_name": template.name}, ip_address)
    return assignment


def seed_default_payment_plan(db: Session) -> None:
    if db.scalar(select(PaymentPlanTemplate).where(PaymentPlanTemplate.code == "HH-3M-14M")):
        return
    plan = PaymentPlanTemplate(code="HH-3M-14M", name="3 Marla - 14 Month Standard", category="Residential", size_marla=3.0, description="Horizon Homes standard 3 Marla payment plan. Fixed-value schedule for Rs 4,950,000.", active=True, source_filename="System Seed")
    db.add(plan); db.flush()
    rows = [
        (1,"Down Payment",0,"Fixed",650000),
        (2,"Confirmation",1,"Fixed",650000),
    ]
    for i in range(14):
        rows.append((3+i,"Monthly Installment",2+i,"Fixed",117857.18 if i == 13 else 117857.14))
    rows += [(17,"Bulk Payment 1",6,"Fixed",500000),(18,"Bulk Payment 2",11,"Fixed",500000),(19,"Possession",16,"Fixed",1000000)]
    for due_no,due_type,offset,amount_type,value in rows:
        db.add(PaymentPlanTemplateLine(template_id=plan.id,due_no=due_no,due_type=due_type,offset_months=offset,amount_type=amount_type,amount_value=value,remarks=""))


def build_upload_template() -> bytes:
    wb = Workbook(); ws = wb.active; ws.title = "Payment Plans"
    headers = ["Plan Code","Plan Name","Category","Size Marla","Description","Active","Due No","Due Type","Offset Months","Amount Type","Amount Value","Remarks"]
    ws.append(headers)
    sample = [
        ["CUSTOM-3M-01","Custom 3 Marla Plan","Residential",3,"Example: percentages plus final balance","Yes",1,"Booking / Down Payment",0,"Percent",20,""],
        ["CUSTOM-3M-01","Custom 3 Marla Plan","Residential",3,"Example: percentages plus final balance","Yes",2,"Confirmation",1,"Percent",10,""],
        ["CUSTOM-3M-01","Custom 3 Marla Plan","Residential",3,"Example: percentages plus final balance","Yes",3,"Installment 1",2,"Percent",5,""],
        ["CUSTOM-3M-01","Custom 3 Marla Plan","Residential",3,"Example: percentages plus final balance","Yes",4,"Final / Possession",14,"Balance",0,"Remaining balance auto-adjusts"],
        ["CUSTOM-COM-01","Custom Commercial Plan","Commercial",0,"Second plan in same upload","Yes",1,"Down Payment",0,"Percent",30,""],
        ["CUSTOM-COM-01","Custom Commercial Plan","Commercial",0,"Second plan in same upload","Yes",2,"After 3 Months",3,"Percent",30,""],
        ["CUSTOM-COM-01","Custom Commercial Plan","Commercial",0,"Second plan in same upload","Yes",3,"Possession",6,"Balance",0,""],
    ]
    for row in sample: ws.append(row)
    ws.freeze_panes="A2"; ws.auto_filter.ref=f"A1:L{ws.max_row}"
    widths=[18,30,16,12,42,10,10,28,16,16,16,30]
    for i,w in enumerate(widths,1): ws.column_dimensions[chr(64+i)].width=w
    help_ws=wb.create_sheet("Instructions")
    instructions=[
        ["HORIZON ERP PAYMENT PLAN UPLOAD TEMPLATE"],
        ["Use one row per scheduled payment. Multiple Plan Codes can be uploaded in one file."],
        ["Amount Type", "Fixed = exact rupees; Percent = percentage of booking net sale value; Balance = all remaining amount (maximum one Balance line per plan)."],
        ["Offset Months", "0 = booking date, 1 = one month after booking, etc."],
        ["Due No", "Must be unique within each Plan Code."],
        ["Plan Code", "Must be unique. A plan already used by a booking cannot be overwritten; upload it under a new Plan Code."],
        ["Active", "Yes/No."],
        ["Validation", "At booking time the calculated schedule must equal the booking net sale value. A Balance line is recommended for flexible prices."],
    ]
    for row in instructions: help_ws.append(row)
    help_ws.column_dimensions['A'].width=24; help_ws.column_dimensions['B'].width=110
    bio=BytesIO(); wb.save(bio); return bio.getvalue()


def _truthy(value) -> bool:
    return str(value or "").strip().lower() in {"1","yes","y","true","active"}


def parse_upload(data: bytes, filename: str) -> dict[str, dict]:
    ext = (filename.rsplit('.',1)[-1] if '.' in filename else '').lower()
    rows=[]
    if ext == 'xlsx':
        wb=load_workbook(BytesIO(data),data_only=True); ws=wb["Payment Plans"] if "Payment Plans" in wb.sheetnames else wb.active
        headers=[str(c.value or '').strip() for c in ws[1]]
        for values in ws.iter_rows(min_row=2,values_only=True):
            if not any(v not in (None,'') for v in values): continue
            rows.append(dict(zip(headers,values)))
    elif ext == 'csv':
        text=data.decode('utf-8-sig'); rows=list(csv.DictReader(StringIO(text)))
    else:
        raise ValueError("Upload an .xlsx or .csv payment-plan file")
    required={"Plan Code","Plan Name","Due No","Due Type","Offset Months","Amount Type","Amount Value"}
    if not rows: raise ValueError("Payment-plan file contains no data rows")
    missing=required-set(rows[0].keys())
    if missing: raise ValueError("Missing template columns: "+", ".join(sorted(missing)))
    plans={}
    for idx,row in enumerate(rows,start=2):
        code=str(row.get("Plan Code") or '').strip(); name=str(row.get("Plan Name") or '').strip()
        if not code or not name: raise ValueError(f"Row {idx}: Plan Code and Plan Name are required")
        try: due_no=int(row.get("Due No")); offset=int(row.get("Offset Months") or 0)
        except Exception as exc: raise ValueError(f"Row {idx}: Due No and Offset Months must be whole numbers") from exc
        amount_type=str(row.get("Amount Type") or '').strip().title()
        if amount_type not in VALID_AMOUNT_TYPES: raise ValueError(f"Row {idx}: Amount Type must be Fixed, Percent, or Balance")
        value=round(as_float(row.get("Amount Value")),4)
        if due_no<1 or offset<0 or value<0: raise ValueError(f"Row {idx}: invalid due number, offset, or amount value")
        p=plans.setdefault(code,{"code":code,"name":name,"category":str(row.get("Category") or "All").strip() or "All","size_marla":as_float(row.get("Size Marla")),"description":str(row.get("Description") or '').strip(),"active":_truthy(row.get("Active") if row.get("Active") not in (None,'') else 'Yes'),"lines":[]})
        if p['name']!=name: raise ValueError(f"Row {idx}: Plan Name is inconsistent for Plan Code {code}")
        if any(x['due_no']==due_no for x in p['lines']): raise ValueError(f"Plan {code}: duplicate Due No {due_no}")
        p['lines'].append({"due_no":due_no,"due_type":str(row.get("Due Type") or '').strip(),"offset_months":offset,"amount_type":amount_type,"amount_value":value,"remarks":str(row.get("Remarks") or '').strip()})
    for code,p in plans.items():
        if not all(x['due_type'] for x in p['lines']): raise ValueError(f"Plan {code}: Due Type is required on every line")
        if sum(1 for x in p['lines'] if x['amount_type']=='Balance')>1: raise ValueError(f"Plan {code}: only one Balance line is allowed")
    return plans


def import_plans(db: Session, data: bytes, filename: str, user_name: str, ip_address: str = "") -> dict:
    plans=parse_upload(data,filename); created=0; updated=0
    for code,p in plans.items():
        existing=db.scalar(select(PaymentPlanTemplate).where(PaymentPlanTemplate.code==code))
        if existing:
            used=db.scalar(select(func.count()).select_from(BookingPaymentPlan).where(BookingPaymentPlan.template_id==existing.id)) or 0
            if used:
                raise ValueError(f"Plan {code} is already assigned to {used} booking(s). Use a new Plan Code to preserve historical schedules.")
            db.query(PaymentPlanTemplateLine).filter(PaymentPlanTemplateLine.template_id==existing.id).delete(synchronize_session=False)
            plan=existing; updated+=1
        else:
            plan=PaymentPlanTemplate(code=code,name=p['name']); db.add(plan); db.flush(); created+=1
        plan.name=p['name']; plan.category=p['category']; plan.size_marla=p['size_marla']; plan.description=p['description']; plan.active=p['active']; plan.source_filename=filename; plan.version=(plan.version or 0)+1 if existing else 1
        for x in sorted(p['lines'],key=lambda z:z['due_no']): db.add(PaymentPlanTemplateLine(template_id=plan.id,**x))
        audit(db,user_name,"IMPORT_PAYMENT_PLAN","Payment Plans",plan.id,{"code":code,"file":filename,"lines":len(p['lines'])},ip_address)
    return {"plans":len(plans),"created":created,"updated":updated}
