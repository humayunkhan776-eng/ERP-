from __future__ import annotations

from datetime import date, datetime
from typing import Iterable

from sqlalchemy import case, func, select
from sqlalchemy.orm import Session

from ..models import Account, Voucher, VoucherLine
from .common import as_float, audit, next_number, to_date


def to_date_value(value):
    return to_date(value)

DEFAULT_ACCOUNTS = [
    ("1000", "Cash in Hand", "Asset", "Balance Sheet"),
    ("1010", "Bank Account", "Asset", "Balance Sheet"),
    ("1100", "Customer Receivable", "Asset", "Balance Sheet"),
    ("1200", "Land Inventory", "Asset", "Balance Sheet"),
    ("1210", "Development Work in Progress", "Asset", "Balance Sheet"),
    ("2000", "Accounts Payable", "Liability", "Balance Sheet"),
    ("2010", "Customer Reservation Deposits", "Liability", "Balance Sheet"),
    ("2100", "Director Current Account - Salman", "Liability", "Balance Sheet"),
    ("2110", "Director Current Account - Humayun", "Liability", "Balance Sheet"),
    ("3000", "Share Capital", "Equity", "Balance Sheet"),
    ("4000", "Residential Plot Sales", "Income", "Profit & Loss"),
    ("4010", "Commercial Plot Sales", "Income", "Profit & Loss"),
    ("5000", "Cost of Plot Sales", "Expense", "Profit & Loss"),
    ("6100", "Administrative Expenses", "Expense", "Profit & Loss"),
    ("6110", "Salary & Wages Expense", "Expense", "Profit & Loss"),
    ("2020", "Staff Deductions Payable", "Liability", "Balance Sheet"),
    ("6200", "Sales Commission Expense", "Expense", "Profit & Loss"),
    ("6300", "RUDA & Government Charges", "Expense", "Profit & Loss"),
    ("6310", "RUDA Penalty Expense", "Expense", "Profit & Loss"),
    ("6400", "Development Expense", "Expense", "Profit & Loss"),
]


def ensure_default_accounts(db: Session) -> None:
    existing = {row[0] for row in db.execute(select(Account.name)).all()}
    for code, name, kind, statement in DEFAULT_ACCOUNTS:
        if name not in existing:
            db.add(Account(code=code, name=name, type=kind, statement=statement, active=True))
    db.flush()


def account_by_name(db: Session, name: str) -> Account:
    account = db.scalar(select(Account).where(Account.name == name, Account.active.is_(True)))
    if not account:
        raise ValueError(f"Account not found or inactive: {name}")
    return account


def create_voucher(
    db: Session,
    *,
    voucher_date,
    voucher_type: str,
    party: str,
    narration: str,
    lines: Iterable[dict],
    user_name: str,
    source_module: str = "Manual",
    source_reference: str = "",
    status: str = "Posted",
    voucher_no: str | None = None,
    ip_address: str = "",
) -> Voucher:
    ensure_default_accounts(db)
    parsed_lines = []
    total_debit = total_credit = 0.0
    for line in lines:
        debit = round(as_float(line.get("debit")), 2)
        credit = round(as_float(line.get("credit")), 2)
        if debit < 0 or credit < 0 or (debit and credit):
            raise ValueError("Each voucher line must contain either a debit or a credit, not both")
        if not debit and not credit:
            continue
        account = account_by_name(db, str(line.get("account", "")).strip())
        parsed_lines.append((account, debit, credit, line))
        total_debit += debit
        total_credit += credit
    if len(parsed_lines) < 2:
        raise ValueError("A voucher requires at least two non-zero lines")
    if round(total_debit - total_credit, 2) != 0:
        raise ValueError(f"Voucher is not balanced. Debit {total_debit:,.2f}, Credit {total_credit:,.2f}")
    if total_debit <= 0:
        raise ValueError("Voucher amount must be greater than zero")

    prefix_map = {"Receipt": "RV", "Payment": "PV", "Journal": "JV", "Contra": "CV", "Adjustment": "AV"}
    voucher_no = voucher_no or next_number(db, Voucher, Voucher.voucher_no, prefix_map.get(voucher_type, "JV"))
    voucher = Voucher(
        voucher_no=voucher_no,
        voucher_date=to_date(voucher_date, "voucher_date"),
        voucher_type=voucher_type,
        party=party or "",
        narration=narration or "",
        status=status,
        source_module=source_module,
        source_reference=source_reference or "",
        created_by=user_name,
        posted_by=user_name if status == "Posted" else "",
        posted_at=datetime.utcnow() if status == "Posted" else None,
    )
    db.add(voucher)
    db.flush()
    for account, debit, credit, line in parsed_lines:
        db.add(
            VoucherLine(
                voucher_id=voucher.id,
                account_id=account.id,
                debit=debit,
                credit=credit,
                party=str(line.get("party") or party or ""),
                plot_no=str(line.get("plot_no") or ""),
                memo=str(line.get("memo") or narration or ""),
            )
        )
    audit(
        db, user_name, "CREATE_VOUCHER", "Finance", voucher.id,
        {"voucher_no": voucher_no, "status": status, "debit": total_debit, "source": source_module}, ip_address,
    )
    return voucher


def reverse_voucher(db: Session, voucher_id: int, reason: str, user_name: str, ip_address: str = "") -> Voucher:
    original = db.get(Voucher, voucher_id)
    if not original:
        raise ValueError("Voucher not found")
    if original.status != "Posted":
        raise ValueError("Only posted vouchers can be reversed")
    if original.reversed_voucher_id:
        raise ValueError("Voucher has already been reversed")
    lines = db.scalars(select(VoucherLine).where(VoucherLine.voucher_id == original.id)).all()
    account_ids = {line.account_id for line in lines}
    accounts = {a.id: a for a in db.scalars(select(Account).where(Account.id.in_(account_ids))).all()}
    reversal = create_voucher(
        db,
        voucher_date=date.today(),
        voucher_type="Adjustment",
        party=original.party,
        narration=f"Reversal of {original.voucher_no}: {reason}",
        lines=[{
            "account": accounts[line.account_id].name,
            "debit": float(line.credit),
            "credit": float(line.debit),
            "party": line.party,
            "plot_no": line.plot_no,
            "memo": f"Reversal of {original.voucher_no}",
        } for line in lines],
        user_name=user_name,
        source_module="Voucher Reversal",
        source_reference=original.voucher_no,
        status="Posted",
        ip_address=ip_address,
    )
    original.status = "Reversed"
    original.reversed_voucher_id = reversal.id
    audit(db, user_name, "REVERSE_VOUCHER", "Finance", original.id, {"reason": reason, "reversal": reversal.voucher_no}, ip_address)
    return reversal


def trial_balance(db: Session, from_date=None, to_date=None) -> list[dict]:
    filters = [Voucher.status.in_(["Posted", "Reversed"])]
    if from_date:
        filters.append(Voucher.voucher_date >= to_date_value(from_date))
    if to_date:
        filters.append(Voucher.voucher_date <= to_date_value(to_date))
    posted_totals = (
        select(
            VoucherLine.account_id.label("account_id"),
            func.sum(VoucherLine.debit).label("debit"),
            func.sum(VoucherLine.credit).label("credit"),
        )
        .join(Voucher, Voucher.id == VoucherLine.voucher_id)
        .where(*filters)
        .group_by(VoucherLine.account_id)
        .subquery()
    )
    rows = db.execute(
        select(
            Account.code, Account.name, Account.type,
            func.coalesce(posted_totals.c.debit, 0).label("debit"),
            func.coalesce(posted_totals.c.credit, 0).label("credit"),
        )
        .outerjoin(posted_totals, posted_totals.c.account_id == Account.id)
        .where(Account.active.is_(True))
        .order_by(Account.code)
    ).all()
    result=[]
    for row in rows:
        debit, credit=float(row.debit or 0), float(row.credit or 0)
        result.append({"code":row.code,"account":row.name,"type":row.type,"debit":debit,"credit":credit,"balance":debit-credit})
    return result


def profit_loss(db: Session, from_date=None, to_date=None) -> dict:
    tb = trial_balance(db, from_date, to_date)
    income=[]; expenses=[]
    for row in tb:
        if row["type"] == "Income":
            income.append({**row, "amount": row["credit"] - row["debit"]})
        elif row["type"] == "Expense":
            expenses.append({**row, "amount": row["debit"] - row["credit"]})
    total_income=sum(r["amount"] for r in income); total_expense=sum(r["amount"] for r in expenses)
    return {"income":income,"expenses":expenses,"total_income":total_income,"total_expense":total_expense,"net_profit":total_income-total_expense}


def balance_sheet(db: Session, from_date=None, to_date=None) -> dict:
    # A balance sheet is a point-in-time report. If a To date is supplied,
    # accumulate all posted entries up to that date. From date is ignored for
    # balances so opening balances are not accidentally removed.
    tb = trial_balance(db, None, to_date)
    groups={"Asset":[],"Liability":[],"Equity":[]}
    for row in tb:
        if row["type"] in groups:
            amount = row["balance"] if row["type"] == "Asset" else -row["balance"]
            groups[row["type"]].append({**row,"amount":amount})
    pl = profit_loss(db, None, to_date)
    current_earnings=float(pl["net_profit"] or 0)
    if abs(current_earnings) > 0.005:
        groups["Equity"].append({"code":"CURRENT-EARNINGS","account":"Current Period Profit / (Loss)","type":"Equity","debit":0.0,"credit":0.0,"balance":-current_earnings,"amount":current_earnings})
    totals={key:sum(item["amount"] for item in value) for key,value in groups.items()}
    totals["LiabilitiesAndEquity"]=totals["Liability"]+totals["Equity"]
    totals["Difference"]=totals["Asset"]-totals["LiabilitiesAndEquity"]
    return {"groups":groups,"totals":totals}

