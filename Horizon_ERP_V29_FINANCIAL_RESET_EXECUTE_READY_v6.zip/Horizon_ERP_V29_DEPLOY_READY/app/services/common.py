from __future__ import annotations

import json
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import AuditLog


def as_float(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    return float(value)


def to_date(value: Any, field: str = "date") -> date:
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    try:
        return date.fromisoformat(str(value))
    except Exception as exc:
        raise ValueError(f"{field} must be in YYYY-MM-DD format") from exc


def serialize_value(value: Any) -> Any:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    return value


def model_dict(obj, fields: list[str]) -> dict[str, Any]:
    return {field: serialize_value(getattr(obj, field)) for field in fields}


def audit(
    db: Session,
    user_name: str,
    action: str,
    module: str,
    record_id: Any = "",
    details: Any = "",
    ip_address: str = "",
) -> None:
    if not isinstance(details, str):
        details = json.dumps(details, default=str, ensure_ascii=False)
    db.add(
        AuditLog(
            user_name=user_name,
            action=action,
            module=module,
            record_id=str(record_id or ""),
            details=details,
            ip_address=ip_address,
        )
    )


def next_number(db: Session, model, column, prefix: str) -> str:
    # Sequential inside database transaction. Suitable for this single-company ERP.
    count = db.scalar(select(func.count()).select_from(model)) or 0
    candidate = f"{prefix}-{count + 1:05d}"
    while db.scalar(select(model).where(column == candidate)) is not None:
        count += 1
        candidate = f"{prefix}-{count + 1:05d}"
    return candidate
