from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from datetime import datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Setting, WhatsAppMessageLog


def _setting(db: Session, key: str, default: str = "") -> str:
    row = db.get(Setting, key)
    return (row.value if row else default) or default


def get_whatsapp_config(db: Session) -> dict[str, Any]:
    token = os.getenv("WHATSAPP_ACCESS_TOKEN") or _setting(db, "whatsapp_access_token")
    phone_number_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or _setting(db, "whatsapp_phone_number_id")
    return {
        "enabled": _setting(db, "whatsapp_enabled", "0") == "1",
        "api_version": _setting(db, "whatsapp_api_version", "v23.0"),
        "phone_number_id": phone_number_id,
        "access_token": token,
        "token_source": "Environment" if os.getenv("WHATSAPP_ACCESS_TOKEN") else ("ERP Settings" if token else "Not configured"),
        "phone_id_source": "Environment" if os.getenv("WHATSAPP_PHONE_NUMBER_ID") else ("ERP Settings" if phone_number_id else "Not configured"),
        "default_country_code": _setting(db, "whatsapp_default_country_code", "92"),
        "language_code": _setting(db, "whatsapp_language_code", "en_US"),
        "booking_template": _setting(db, "whatsapp_booking_template", "horizon_booking_confirmation"),
        "due_template": _setting(db, "whatsapp_due_template", "horizon_payment_due"),
        "auto_booking": _setting(db, "whatsapp_auto_booking", "0") == "1",
    }


def public_whatsapp_config(db: Session) -> dict[str, Any]:
    cfg = get_whatsapp_config(db)
    token = cfg.pop("access_token", "")
    cfg["token_configured"] = bool(token)
    return cfg


def save_whatsapp_config(db: Session, payload: dict[str, Any]) -> None:
    mapping = {
        "enabled": "whatsapp_enabled",
        "api_version": "whatsapp_api_version",
        "phone_number_id": "whatsapp_phone_number_id",
        "default_country_code": "whatsapp_default_country_code",
        "language_code": "whatsapp_language_code",
        "booking_template": "whatsapp_booking_template",
        "due_template": "whatsapp_due_template",
        "auto_booking": "whatsapp_auto_booking",
    }
    for field, key in mapping.items():
        if field not in payload:
            continue
        value = payload[field]
        if isinstance(value, bool):
            value = "1" if value else "0"
        value = str(value or "").strip()
        row = db.get(Setting, key)
        if row:
            row.value = value
        else:
            db.add(Setting(key=key, value=value))
    # Never overwrite a saved token with a blank field. Environment variable still takes priority.
    if str(payload.get("access_token") or "").strip():
        key = "whatsapp_access_token"
        value = str(payload["access_token"]).strip()
        row = db.get(Setting, key)
        if row:
            row.value = value
        else:
            db.add(Setting(key=key, value=value))


def normalize_mobile(value: str, default_country_code: str = "92") -> str:
    raw = re.sub(r"[^0-9+]", "", str(value or "").strip())
    if raw.startswith("+"):
        digits = raw[1:]
    elif raw.startswith("00"):
        digits = raw[2:]
    else:
        digits = re.sub(r"\D", "", raw)
        if digits.startswith("0"):
            digits = default_country_code + digits[1:]
        elif not digits.startswith(default_country_code) and len(digits) <= 11:
            digits = default_country_code + digits
    if len(digits) < 10 or len(digits) > 15:
        raise ValueError("Customer mobile number is invalid for WhatsApp. Use international format, e.g. +923001234567.")
    return digits


def fmt_money(value: Any) -> str:
    try:
        return f"Rs {float(value or 0):,.0f}"
    except Exception:
        return f"Rs {value}"


def _jsonable(value: Any):
    if isinstance(value, (datetime,)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    return value


def send_template_message(
    db: Session,
    *,
    mobile: str,
    template_name: str,
    parameters: list[str],
    message_type: str,
    sent_by: str,
    customer_id: int | None = None,
    booking_id: int | None = None,
    installment_id: int | None = None,
) -> WhatsAppMessageLog:
    cfg = get_whatsapp_config(db)
    if not cfg["enabled"]:
        raise ValueError("WhatsApp API integration is disabled. Enable it in Settings & Deployment → WhatsApp API.")
    if not cfg["phone_number_id"]:
        raise ValueError("WhatsApp Phone Number ID is not configured.")
    if not cfg["access_token"]:
        raise ValueError("WhatsApp access token is not configured. Set WHATSAPP_ACCESS_TOKEN or save a token in ERP settings.")
    if not template_name:
        raise ValueError("WhatsApp template name is not configured.")

    to = normalize_mobile(mobile, cfg["default_country_code"])
    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "template",
        "template": {
            "name": template_name,
            "language": {"code": cfg["language_code"]},
            "components": [
                {
                    "type": "body",
                    "parameters": [{"type": "text", "text": str(x)} for x in parameters],
                }
            ],
        },
    }
    log = WhatsAppMessageLog(
        message_type=message_type,
        customer_id=customer_id,
        booking_id=booking_id,
        installment_id=installment_id,
        mobile=to,
        template_name=template_name,
        request_payload=json.dumps(payload, default=_jsonable, ensure_ascii=False),
        status="Sending",
        sent_by=sent_by,
    )
    db.add(log)
    db.flush()

    url = f"https://graph.facebook.com/{cfg['api_version'].strip('/')}/{cfg['phone_number_id']}/messages"
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {cfg['access_token']}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            body = json.loads(response.read().decode("utf-8") or "{}")
        message_id = ""
        messages = body.get("messages") or []
        if messages:
            message_id = str(messages[0].get("id") or "")
        log.provider_message_id = message_id
        log.status = "Sent"
        log.sent_at = datetime.utcnow()
        log.error_message = ""
        return log
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        try:
            parsed = json.loads(detail)
            detail = parsed.get("error", {}).get("message") or detail
        except Exception:
            pass
        log.status = "Failed"
        log.error_message = f"HTTP {exc.code}: {detail}"[:4000]
        raise ValueError(f"WhatsApp API rejected the message: {detail}") from exc
    except urllib.error.URLError as exc:
        log.status = "Failed"
        log.error_message = f"Network error: {exc.reason}"[:4000]
        raise ValueError(f"Could not connect to WhatsApp API: {exc.reason}") from exc
    except Exception as exc:
        log.status = "Failed"
        log.error_message = str(exc)[:4000]
        raise


def make_wa_link(mobile: str, text: str, default_country_code: str = "92") -> str:
    from urllib.parse import quote

    to = normalize_mobile(mobile, default_country_code)
    return f"https://wa.me/{to}?text={quote(text)}"
